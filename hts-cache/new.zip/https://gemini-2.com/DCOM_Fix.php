<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>WORKAROUND</title>
<style type="text/css">
*{ -moz-box-shadow: none !important; -webkit-box-shadow: none !important; }

*{ -moz-box-shadow: none !important; -webkit-box-shadow: none !important; }

.postcontent {
	word-wrap: break-word;
}


blockquote
{
	overflow:hidden;
}


body a {
	color:#004499;
	text-decoration:none;
}
blockquote .size_fullsize
{
	max-width:100%;
	width: auto !important;
}

img {
	border:0;
}
img {
	border:0;
}
fieldset,img{border:0;}
.lastedited {
	font-style:italic;
	padding-top: 1em;
	color: #3e3e3e;
	font-size: 11px;
/*	clear:both; */
}

.time {
	color:#3e3e3e;
}

.auto-style1 {
	margin: 0;
	padding: 0;
}
</style>
</head>

<body>

<div class="auto-style1">
	<div id="post_message_67734" class="auto-style1">
		<blockquote class="auto-style1">
			<div id="pagetitle" class="pagetitle">
				<h1>Thread: <span class="threadtitle">
				<a href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems" title="Reload this Page">
				ALERT: Windows 10 Update KB4056892 Reported Problems</a></span>
				</h1>
			</div>
			<!-- Start Forum tcat Heading ForumThemes --> 
			<div class="tcatBar">
				<div class="tcatLeft">
					<div class="tcatRight foruminfo L1 collapse">
						<div id="thread_controls" class="tcat_threadlist_controls ">
							<div>
								<ul id="postlist_popups" class="postlist_popups popupgroup">
									<li id="threadtools" class="popupmenu">
									<h6>
									<a id="yui-gen5" class="popupctrl" href="javascript://">
									Thread Tools</a></h6>
									<ul id="yui-gen4" class="popupbody">
										<li>
										<a accesskey="3" href="http://forums.dc3.com/printthread.php?t=11182&amp;pp=10&amp;page=1" rel="nofollow">
										Show Printable Version</a></li>
										<li></li>
									</ul>
									</li>
									<li id="displaymodes" class="popupmenu">
									<h6>
									<a id="yui-gen7" class="popupctrl" href="javascript://">
									Display</a></h6>
									<ul id="yui-gen6" class="popupbody">
										<li>
										<a href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67734&amp;mode=linear#post67734">
										Switch to Linear Mode</a></li>
										<li>
										<a href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;mode=hybrid">
										Switch to Hybrid Mode</a></li>
										<li><label>Threaded Mode</label></li>
									</ul>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- End Forum tcat Heading ForumThemes --> 
			<div id="postlist" class="postlist restrain">
<SCRIPT type="text/javascript">
<!--
var imgdir_statusicon = "images/styles/RoyalFlush/statusicon";
var imgdir_misc = "images/styles/RoyalFlush/misc";
var cleargifurl = "clear.gif";
var guestphrase = "Guest";
var morephrase = "More replies below current depth...";
var highlightwords = "";
//-->
</SCRIPT>
 
<SCRIPT src="http://forums.dc3.com/clientscript/vbulletin_thrdpostlist.js?v=424" type="text/javascript"></SCRIPT>
 
<SCRIPT type="text/javascript">
<!--
// initialize some variables
var curpostid = 67734;
var quickreply = false;

// cached posts (no page reload required to view)
pd[67716] = '\r\n<li class="postbit postbitim postcontainer old" id="post_67716">\r\n	<div class="postdetails_noavatar">\r\n		<div class="posthead">\r\n                        \r\n                                <span class="postdate old">\r\n                                        \r\n                                                <span class="date">Yesterday,&nbsp;<span class="time">18:06</span></span>\r\n                                        \r\n                                </span>\r\n                                <span class="nodecontrols">\r\n                                        \r\n                                                <a name="post67716" href="showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67716#post67716" class="postcounter">#1</a><a id="postcount67716" name="1"></a>\r\n                                        \r\n                                        \r\n                                        \r\n                                </span>\r\n                        \r\n		</div>\r\n\r\n		<div class="userinfo">\r\n			<div class="contact">\r\n				\r\n					<a class="postuseravatarlink" href="member.php?1-Bob-Denny" title="Bob Denny is offline">\r\n						\r\n							<img src="image.php?u=1&amp;dateline=1326825398" alt="Bob Denny\'s Avatar" />\r\n						\r\n					</a>\r\n				\r\n				<div class="username_container">\r\n					\r\n						<div class="popupmenu memberaction">\r\n	<a class="username offline popupctrl" href="member.php?1-Bob-Denny" title="Bob Denny is offline"><strong>Bob Denny</strong></a>\r\n	<ul class="popupbody popuphover memberaction_body">\r\n		<li class="left">\r\n			<a href="member.php?1-Bob-Denny" class="siteicon_profile">\r\n				View Profile\r\n			</a>\r\n		</li>\r\n		\r\n		<li class="right">\r\n			<a href="search.php?do=finduser&amp;userid=1&amp;contenttype=vBForum_Post&amp;showposts=1" class="siteicon_forum" rel="nofollow">\r\n				View Forum Posts\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		<li class="left">\r\n			<a href="http://dc3.com/" class="siteicon_homepage">\r\n				Visit Homepage\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n\r\n		\r\n\r\n		\r\n		\r\n	</ul>\r\n</div>\r\n						<img class="inlineimg onlinestatus" src="images/styles/RoyalFlush/statusicon/user-offline.png" alt="Bob Denny is offline" border="0" />\r\n\r\n					\r\n					<span class="usertitle">\r\n						Developer\r\n					</span>\r\n					\r\n\r\n                                        \r\n					\r\n					\r\n						<div class="imlinks">\r\n							    \r\n						</div>\r\n					\r\n				</div>\r\n			</div>\r\n			\r\n				<div class="userinfo_extra">\r\n					<dl class="userstats">\r\n						<dt>Join Date</dt> <dd>Oct 2005</dd>\r\n						<dt>Location</dt> <dd>Mesa, AZ</dd>\r\n						\r\n						<dt>Posts</dt> <dd>22,196</dd>	\r\n						\r\n					</dl>\r\n					\r\n					\r\n				</div>\r\n			\r\n		</div>\r\n	</div>\r\n\r\n	<div class="postbody">\r\n		\r\n		<div class="postrow">\r\n		\r\n		<h2 class="posttitle icon">\r\n			<img src="images/icons/icon1.png" alt="Default" /> ALERT: Windows 10 Update KB4056892 Reported Problems\r\n		</h2>\r\n		\r\n				\r\n				\r\n		<div class="content">\r\n			<div id="post_message_67716">\r\n				<blockquote class="postcontent restore">\r\n					Microsoft has released <a href="https://support.microsoft.com/en-us/help/4056892/windows-10-update-kb4056892" target="_blank">Windows 10 Update KB4056892 (OS Build 16299.192)</a> which <i>may</i> be in response to the recently discovered CPU vulnerabilities as described in this article: <a href="https://www.welivesecurity.com/2018/01/05/meltdown-spectre-cpu-vulnerabilities/" target="_blank">Meltdown and Spectre CPU Vulnerabilities: What You Need to Know</a>. We have received some reports of this update <i>possibly </i>causing ACP and other client programs to fail when trying to connect to <i>some </i>ASCOM-compatible devices including TheSky X acting as a telescope controller. <br />\n<br />\nIf you want to see or participate in the discussion here, <u>you will need to have current Support and Upgrades</u>, as the discussion is running in the premium ACP Observatory Control support section:<br />\n<br />\n<font size="4"><a href="http://forums.dc3.com/showthread.php?11179-Windows-Update-KB4057892-Possible-Problems-With-ASCOM-Connections" target="_blank">Windows Update KB4056892 - Possible Problems With ASCOM Connections</a></font><br />\n<br />\nAt this point we don\'t have any solid evidence or cause-effect information. The update just came out a couple of days ago (04-Jan-2018). We posted this alert to let you know that we are aware of possible issues. It is possible, based on reading some of today\'s news traffic, that this was a rushed-out update with some known problems (see the KB article linked above).\r\n				</blockquote>\r\n			</div>\r\n\r\n			\r\n\r\n\r\n		</div>\r\n			\r\n			<!-' + '- edit note -' + '->\r\n			<blockquote class="postcontent lastedited">\r\n				\r\n					Last edited by Bob Denny; Yesterday at <span class="time">19:32</span>.\r\n				\r\n				\r\n					<span class="reason">Reason:</span> Updates progressing again\r\n				\r\n			</blockquote>\r\n			<!-' + '- / edit note -' + '->\r\n			\r\n				\r\n			\r\n			\r\n				<blockquote class="signature restore"><div class="signaturecontainer"><div style="margin-left:40px">-' + '- Bob</div></div></blockquote>\r\n			\r\n			\r\n		</div>\r\n	</div>\r\n	<div class="postfoot">\r\n		<div class="textcontrols floatcontainer">\r\n			<span class="postcontrols">\r\n				<img style="display:none" id="progress_67716" src="images/styles/RoyalFlush/misc/progress.gif" alt="" />\r\n				\r\n				\r\n				\r\n				\r\n			</span>\r\n			<span class="postlinking">\r\n				\r\n					\r\n				\r\n				\r\n\r\n				 \r\n				\r\n\r\n					\r\n\r\n					\r\n					 \r\n\r\n					\r\n					\r\n					\r\n					\r\n					\r\n			</span>\r\n		</div>\r\n	</div>\r\n	<hr />\r\n</li>\r\n';
pd[67732] = '\r\n<li class="postbit postbitim postcontainer old" id="post_67732">\r\n	<div class="postdetails_noavatar">\r\n		<div class="posthead">\r\n                        \r\n                                <span class="postdate old">\r\n                                        \r\n                                                <span class="date">Yesterday,&nbsp;<span class="time">23:30</span></span>\r\n                                        \r\n                                </span>\r\n                                <span class="nodecontrols">\r\n                                        \r\n                                                <a name="post67732" href="showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67732#post67732" class="postcounter">#2</a><a id="postcount67732" name="2"></a>\r\n                                        \r\n                                        \r\n                                        \r\n                                </span>\r\n                        \r\n		</div>\r\n\r\n		<div class="userinfo">\r\n			<div class="contact">\r\n				\r\n					<a class="postuseravatarlink" href="member.php?1-Bob-Denny" title="Bob Denny is offline">\r\n						\r\n							<img src="image.php?u=1&amp;dateline=1326825398" alt="Bob Denny\'s Avatar" />\r\n						\r\n					</a>\r\n				\r\n				<div class="username_container">\r\n					\r\n						<div class="popupmenu memberaction">\r\n	<a class="username offline popupctrl" href="member.php?1-Bob-Denny" title="Bob Denny is offline"><strong>Bob Denny</strong></a>\r\n	<ul class="popupbody popuphover memberaction_body">\r\n		<li class="left">\r\n			<a href="member.php?1-Bob-Denny" class="siteicon_profile">\r\n				View Profile\r\n			</a>\r\n		</li>\r\n		\r\n		<li class="right">\r\n			<a href="search.php?do=finduser&amp;userid=1&amp;contenttype=vBForum_Post&amp;showposts=1" class="siteicon_forum" rel="nofollow">\r\n				View Forum Posts\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		<li class="left">\r\n			<a href="http://dc3.com/" class="siteicon_homepage">\r\n				Visit Homepage\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n\r\n		\r\n\r\n		\r\n		\r\n	</ul>\r\n</div>\r\n						<img class="inlineimg onlinestatus" src="images/styles/RoyalFlush/statusicon/user-offline.png" alt="Bob Denny is offline" border="0" />\r\n\r\n					\r\n					<span class="usertitle">\r\n						Developer\r\n					</span>\r\n					\r\n\r\n                                        \r\n					\r\n					\r\n						<div class="imlinks">\r\n							    \r\n						</div>\r\n					\r\n				</div>\r\n			</div>\r\n			\r\n				<div class="userinfo_extra">\r\n					<dl class="userstats">\r\n						<dt>Join Date</dt> <dd>Oct 2005</dd>\r\n						<dt>Location</dt> <dd>Mesa, AZ</dd>\r\n						\r\n						<dt>Posts</dt> <dd>22,196</dd>	\r\n						\r\n					</dl>\r\n					\r\n					\r\n				</div>\r\n			\r\n		</div>\r\n	</div>\r\n\r\n	<div class="postbody">\r\n		\r\n		<div class="postrow">\r\n		\r\n		<h2 class="posttitle icon">\r\n			<img src="images/icons/icon1.png" alt="Default" /> \r\n		</h2>\r\n		\r\n				\r\n				\r\n		<div class="content">\r\n			<div id="post_message_67732">\r\n				<blockquote class="postcontent restore">\r\n					I have confirmed this to be a general problem introduced by KB4056892! I started with a clean Windows 10 system with only ASCOM Platform 6.3. I tested POTH connecting to the ASCOM Telescope Simulator for .NET and the old ASCOM Telescope Simulator (VB6 Based). No problems. Then I manually installed KB4056892. After that here are the results:<br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9322&amp;d=1515281328" border="0" alt="Name:  Snap1.jpg\r\nViews: 153\r\nSize:  155.9 KB" class="thumbnail" /></div><br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9323&amp;d=1515281367" border="0" alt="Name:  Snap2.jpg\r\nViews: 65\r\nSize:  148.9 KB" class="thumbnail" /></div><br />\n<br />\nRowland Archer nailed it in the ACP Forum discussion thread by posting the &quot;known issue&quot;<br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9324&amp;d=1515281422" border="0" alt="Name:  Snap3.jpg\r\nViews: 66\r\nSize:  68.0 KB" class="thumbnail" /></div><br />\n<br />\nThis is it. See the next post for how to solve it.\r\n				</blockquote>\r\n			</div>\r\n\r\n			\r\n\r\n\r\n		</div>\r\n			\r\n				\r\n			\r\n			\r\n				<blockquote class="signature restore"><div class="signaturecontainer"><div style="margin-left:40px">-' + '- Bob</div></div></blockquote>\r\n			\r\n			\r\n		</div>\r\n	</div>\r\n	<div class="postfoot">\r\n		<div class="textcontrols floatcontainer">\r\n			<span class="postcontrols">\r\n				<img style="display:none" id="progress_67732" src="images/styles/RoyalFlush/misc/progress.gif" alt="" />\r\n				\r\n				\r\n				\r\n				\r\n			</span>\r\n			<span class="postlinking">\r\n				\r\n					\r\n				\r\n				\r\n\r\n				 \r\n				\r\n\r\n					\r\n\r\n					\r\n					 \r\n\r\n					\r\n					\r\n					\r\n					\r\n					\r\n			</span>\r\n		</div>\r\n	</div>\r\n	<hr />\r\n</li>\r\n';
pd[67734] = '\r\n<li class="postbit postbitim postcontainer old" id="post_67734">\r\n	<div class="postdetails_noavatar">\r\n		<div class="posthead">\r\n                        \r\n                                <span class="postdate old">\r\n                                        \r\n                                                <span class="date">Today,&nbsp;<span class="time">00:08</span></span>\r\n                                        \r\n                                </span>\r\n                                <span class="nodecontrols">\r\n                                        \r\n                                                <a name="post67734" href="showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67734#post67734" class="postcounter">#3</a><a id="postcount67734" name="3"></a>\r\n                                        \r\n                                        \r\n                                        \r\n                                </span>\r\n                        \r\n		</div>\r\n\r\n		<div class="userinfo">\r\n			<div class="contact">\r\n				\r\n					<a class="postuseravatarlink" href="member.php?1-Bob-Denny" title="Bob Denny is offline">\r\n						\r\n							<img src="image.php?u=1&amp;dateline=1326825398" alt="Bob Denny\'s Avatar" />\r\n						\r\n					</a>\r\n				\r\n				<div class="username_container">\r\n					\r\n						<div class="popupmenu memberaction">\r\n	<a class="username offline popupctrl" href="member.php?1-Bob-Denny" title="Bob Denny is offline"><strong>Bob Denny</strong></a>\r\n	<ul class="popupbody popuphover memberaction_body">\r\n		<li class="left">\r\n			<a href="member.php?1-Bob-Denny" class="siteicon_profile">\r\n				View Profile\r\n			</a>\r\n		</li>\r\n		\r\n		<li class="right">\r\n			<a href="search.php?do=finduser&amp;userid=1&amp;contenttype=vBForum_Post&amp;showposts=1" class="siteicon_forum" rel="nofollow">\r\n				View Forum Posts\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		<li class="left">\r\n			<a href="http://dc3.com/" class="siteicon_homepage">\r\n				Visit Homepage\r\n			</a>\r\n		</li>\r\n		\r\n		\r\n		\r\n\r\n		\r\n\r\n		\r\n		\r\n	</ul>\r\n</div>\r\n						<img class="inlineimg onlinestatus" src="images/styles/RoyalFlush/statusicon/user-offline.png" alt="Bob Denny is offline" border="0" />\r\n\r\n					\r\n					<span class="usertitle">\r\n						Developer\r\n					</span>\r\n					\r\n\r\n                                        \r\n					\r\n					\r\n						<div class="imlinks">\r\n							    \r\n						</div>\r\n					\r\n				</div>\r\n			</div>\r\n			\r\n				<div class="userinfo_extra">\r\n					<dl class="userstats">\r\n						<dt>Join Date</dt> <dd>Oct 2005</dd>\r\n						<dt>Location</dt> <dd>Mesa, AZ</dd>\r\n						\r\n						<dt>Posts</dt> <dd>22,196</dd>	\r\n						\r\n					</dl>\r\n					\r\n					\r\n				</div>\r\n			\r\n		</div>\r\n	</div>\r\n\r\n	<div class="postbody">\r\n		\r\n		<div class="postrow">\r\n		\r\n		<h2 class="posttitle icon">\r\n			<img src="images/icons/icon1.png" alt="Default" /> \r\n		</h2>\r\n		\r\n				\r\n				\r\n		<div class="content">\r\n			<div id="post_message_67734">\r\n				<blockquote class="postcontent restore">\r\n					<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9327&amp;d=1515283023" border="0" alt="Name:  Snap6.jpg\r\nViews: 370\r\nSize:  7.9 KB" class="align_right" /></div>WORKAROUND: As the Microsoft supplied workaround in the <a href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67732#post67732" target="_blank">previous post</a> says, the components need to have their call level changed to &quot;Call&quot;. Thank goodness, this can be done using the DCOMCNFG tool, an MMC snap in. The tricky part is going to be identifying the various ASCOM and application servers you need to adjust!!<br />\n<br />\n<font color="#b22222"><font size="3">Note that neither ASCOM nor its client apps use Distributed COM (DCOM). The names are historical only.<br />\n</font></font><br />\n1. Type DCOMCNFG into the Windows Search box (lower left corner of your screen). You may have to wait a while while it installs the Component Services snap-in the first time you do this. Be patient.<br />\n<br />\n2. Eventually you should see the Component Services window. Expand the tree to see DCOM Config<br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9325&amp;d=1515282278" border="0" alt="Name:  Snap4.jpg\r\nViews: 374\r\nSize:  50.6 KB" class="thumbnail" /></div><br />\n<br />\n3. Now for the tricky part. Under the DCOM Config &quot;folder&quot; is a long list of components, most of which belong to Windows itself and to the many apps that make use of this Windows feature (COM). Your task is to locate those which you need for your astronomy uses. This will include drivers for devices and anything that may be used by another app. POTH is an example, it is used by other programs because it looks like a telescope, dome, and focuser to its clients. If in doubt just change its authentication level, it\'s harmless. Use the ASCOM Profile Explorer to find the System name for the devices you see in the Chooser. Then find it by system name in DCOMCNFG. Here is the entry for the &quot;Telescope Simulator for .NET&quot; in the ASCOM Profile Explorer<br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9326&amp;d=1515282881" border="0" alt="Name:  Snap7.jpg\r\nViews: 374\r\nSize:  90.0 KB" class="thumbnail" /></div><br />\n<br />\nNote that it\'s system name is ASCOM.Simulator.Telescope. <br />\n<br />\n4. Now find this in DCOMCNFG\'s list of components. Right click, Properties, then change None to Call in Authentication Level. Then click OK:<br />\n<br />\n<div class="size_fullsize"><img src="http://forums.dc3.com/attachment.php?attachmentid=9328&amp;d=1515283134" border="0" alt="Name:  Snap5.jpg\r\nViews: 373\r\nSize:  151.4 KB" class="thumbnail" /></div><br />\n<br />\nContinue finding things in the ASCOM Profile Explorer and DCOMCONFG, setting the Authentication level to Call. If you encounter a non-ASCOM component that stopped working after KB4075892, and you know it has a scripting or programming API then find it in DCOMCNFG and change its Authentication Level to Call as well. This includes ACP itself which is listed ACP Observatory Control Software.\r\n				</blockquote>\r\n			</div>\r\n\r\n			\r\n\r\n\r\n		</div>\r\n			\r\n			<!-' + '- edit note -' + '->\r\n			<blockquote class="postcontent lastedited">\r\n				\r\n					Last edited by Bob Denny; Today at <span class="time">02:54</span>.\r\n				\r\n				\r\n			</blockquote>\r\n			<!-' + '- / edit note -' + '->\r\n			\r\n				\r\n			\r\n			\r\n				<blockquote class="signature restore"><div class="signaturecontainer"><div style="margin-left:40px">-' + '- Bob</div></div></blockquote>\r\n			\r\n			\r\n		</div>\r\n	</div>\r\n	<div class="postfoot">\r\n		<div class="textcontrols floatcontainer">\r\n			<span class="postcontrols">\r\n				<img style="display:none" id="progress_67734" src="images/styles/RoyalFlush/misc/progress.gif" alt="" />\r\n				\r\n				\r\n				\r\n				\r\n			</span>\r\n			<span class="postlinking">\r\n				\r\n					\r\n				\r\n				\r\n\r\n				 \r\n				\r\n\r\n					\r\n\r\n					\r\n					 \r\n\r\n					\r\n					\r\n					\r\n					\r\n					\r\n			</span>\r\n		</div>\r\n	</div>\r\n	<hr />\r\n</li>\r\n';

// next/previous post info
pn[67716] = "67734,67732";
pn[0] = ",67716";
pn[67732] = "67716,67734";
pn[67734] = "67732,67716";

// cached usernames
pu[0] = guestphrase;
pu[1] = "Bob Denny";

// -->
</SCRIPT>
 			   <div id="threaded_view">
				   <h4>Threaded View</h4>
				   <div id="posttree">
<SCRIPT type="text/javascript">
		<!--
			writeLink(67716, 0, 0, 1, "", "ALERT: Windows 10 Update KB4056892 Reported...", "Yesterday", "18:06", 0, "showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&p=67716#post67716");
  writeLink(67732, 0, 0, 1, "T", "<i>I have confirmed this to be a general problem...</i>", "Yesterday", "23:30", 0, "showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&p=67732#post67732");
  writeLink(67734, 0, 0, 1, "L", "<i>9327WORKAROUND: As the Microsoft supplied...</i>", "Today", "00:08", 0, "showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&p=67734#post67734");

		//-->
		</SCRIPT>
					   <div id="div67716" class="postoff">
						   <img alt="" height="20" src="DCOM_Fix/clear.gif" width="0" /><img alt="" src="DCOM_Fix/post_old.png" />
						   <b>Bob Denny</b>
						   <a id="link67716" href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67716#post67716" onclick="return showPost(67716)">
						   ALERT: Windows 10 Update KB4056892 Reported...</a> 
						   Yesterday, <span class="time">18:06</span></div>
					   <div id="div67732" class="postoff">
						   <img alt="" src="DCOM_Fix/tree_t.gif" /><img alt="" src="DCOM_Fix/post_old.png" />
						   <b>Bob Denny</b>
						   <a id="link67732" href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67732#post67732" onclick="return showPost(67732)">
						   <i>I have confirmed this to be a general problem...</i></a> 
						   Yesterday, <span class="time">23:30</span></div>
					   <div id="div67734" class="poston">
						   <img alt="" src="DCOM_Fix/tree_ltr.gif" /><img alt="" src="DCOM_Fix/post_old.png" />
						   <b>Bob Denny</b>
						   <a id="link67734" href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67734#post67734" onclick="return showPost(67734)">
						   <i>9327WORKAROUND: As the Microsoft supplied...</i></a> 
						   Today, <span class="time">00:08</span></div>
				   </div>
				</div>
				<div align="center">
					<a href="javascript:showPrevNextPost(0)">Previous Post</a>
					<a href="javascript:showPrevNextPost(0)">
					<img alt="Previous Post" border="0" class="inlineimg" src="DCOM_Fix/sortdesc.png" title="Previous Post" /></a> 
					&nbsp; <a href="javascript:showPrevNextPost(1)">
					<img alt="Next Post" border="0" class="inlineimg" src="DCOM_Fix/sortasc.png" title="Next Post" /></a>
					<a href="javascript:showPrevNextPost(1)">Next Post</a> </div>
				<div class="forumbitBody">
					<ol id="posts" class="posts" start="1">
						<li id="post_67734" class="postbit postbitim postcontainer old">
						<div class="postdetails_noavatar">
							<div class="posthead">
								<span class="postdate old"><span class="date">
								Today,&nbsp;<span class="time">00:08</span></span>
								</span><span class="nodecontrols">
								<a class="postcounter" href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67734#post67734" name="post67734">
								#3</a><a id="postcount67734" name="3"></a>
								</span></div>
							<div class="userinfo">
								<div class="contact">
									<a class="postuseravatarlink" href="http://forums.dc3.com/member.php?1-Bob-Denny" title="Bob Denny is offline">
									<img alt="Bob Denny's Avatar" src="http://forums.dc3.com/image.php?u=1&amp;dateline=1326825398" title="Bob Denny's Avatar" />
									</a>
									<div class="username_container">
										<div id="yui-gen8" class="popupmenu memberaction">
											<a id="yui-gen10" class="username offline popupctrl" href="http://forums.dc3.com/member.php?1-Bob-Denny" title="Bob Denny is offline">
											<strong>Bob Denny</strong></a>
											<ul id="yui-gen9" class="popupbody memberaction_body">
												<li class="left">
												<a class="siteicon_profile" href="http://forums.dc3.com/member.php?1-Bob-Denny">
												View Profile </a></li>
												<li class="right">
												<a class="siteicon_forum" href="http://forums.dc3.com/search.php?do=finduser&amp;userid=1&amp;contenttype=vBForum_Post&amp;showposts=1" rel="nofollow">
												View Forum Posts </a></li>
												<li class="left">
												<a class="siteicon_homepage" href="http://dc3.com/">
												Visit Homepage </a></li>
											</ul>
										</div>
										<img alt="Bob Denny is offline" border="0" class="inlineimg onlinestatus" src="DCOM_Fix/user-offline.png" title="Bob Denny is offline" />
										<span class="usertitle">Developer </span>
										<div class="imlinks">
										</div>
									</div>
								</div>
								<div class="userinfo_extra">
									<dl class="userstats">
										<dt>Join Date</dt>
										<dd>Oct 2005</dd>
										<dt>Location</dt>
										<dd>Mesa, AZ</dd>
										<dt>Posts</dt>
										<dd>22,196</dd>
									</dl>
								</div>
							</div>
						</div>
						<div class="postbody">
							<div class="postrow">
								<h2 class="posttitle icon">
								<img alt="Default" src="DCOM_Fix/icon1.png" title="Default" />
								</h2>
								<div class="content">
									<div id="post_message_67735">
										<blockquote class="postcontent restore">
											<div class="size_fullsize">
												<img alt="Name:  Snap6.jpg" border="0" class="align_right" src="http://forums.dc3.com/attachment.php?attachmentid=9327&amp;d=1515283023" style="float: right" title="Name:  Snap6.jpg
Views: 370
Size:  7.9 KB" /></div>
										</blockquote>
									</div>
								</div>
							</div>
						</div>
						</li>
					</ol>
				</div>
			</div>
			WORKAROUND: As the Microsoft supplied workaround in the
			<a href="http://forums.dc3.com/showthread.php?11182-ALERT-Windows-10-Update-KB4056892-Reported-Problems&amp;p=67732#post67732" target="_blank">
			previous post</a> says, the components need to have their call level 
			changed to "Call". Thank goodness, this can be done using the 
			DCOMCNFG tool, an MMC snap in. The tricky part is going to be 
			identifying the various ASCOM and application servers you need to 
			adjust!!<br />
			<br />
			<font color="#b22222" size="3">Note that neither ASCOM nor its 
			client apps use Distributed COM (DCOM). The names are historical 
			only.<br />
			</font><br />
			1. Type DCOMCNFG into the Windows Search box (lower left corner of 
			your screen). You may have to wait a while while it installs the 
			Component Services snap-in the first time you do this. Be patient.<br />
			<br />
			2. Eventually you should see the Component Services window. Expand 
			the tree to see DCOM Config<br />
			<br />
			<div class="auto-style1">
				<img alt="Name:  Snap4.jpg
Views: 359
Size:  50.6 KB" border="0" class="thumbnail" src="http://forums.dc3.com/attachment.php?s=72826c30634cc59eec524207ab2b2a03&amp;attachmentid=9325&amp;d=1515282278" title="Name:  Snap4.jpg
Views: 359
Size:  50.6 KB" /></div>
			<br />
			<br />
			3. Now for the tricky part. Under the DCOM Config "folder" is a long 
			list of components, most of which belong to Windows itself and to 
			the many apps that make use of this Windows feature (COM). Your task 
			is to locate those which you need for your astronomy uses. This will 
			include drivers for devices and anything that may be used by another 
			app. POTH is an example, it is used by other programs because it 
			looks like a telescope, dome, and focuser to its clients. If in 
			doubt just change its authentication level, it's harmless. Use the 
			ASCOM Profile Explorer to find the System name for the devices you 
			see in the Chooser. Then find it by system name in DCOMCNFG. Here is 
			the entry for the "Telescope Simulator for .NET" in the ASCOM 
			Profile Explorer<br />
			<br />
			<div class="auto-style1">
				<img alt="Name:  Snap7.jpg
Views: 359
Size:  90.0 KB" border="0" class="thumbnail" src="http://forums.dc3.com/attachment.php?s=72826c30634cc59eec524207ab2b2a03&amp;attachmentid=9326&amp;d=1515282881" title="Name:  Snap7.jpg
Views: 359
Size:  90.0 KB" /></div>
			<br />
			<br />
			Note that it's system name is ASCOM.Simulator.Telescope. <br />
			<br />
			4. Now find this in DCOMCNFG's list of components. Right click, 
			Properties, then change None to Call in Authentication Level. Then 
			click OK:<br />
			<br />
			<div class="auto-style1">
				<img alt="Name:  Snap5.jpg
Views: 358
Size:  151.4 KB" border="0" class="thumbnail" src="http://forums.dc3.com/attachment.php?s=72826c30634cc59eec524207ab2b2a03&amp;attachmentid=9328&amp;d=1515283134" title="Name:  Snap5.jpg
Views: 358
Size:  151.4 KB" /></div>
			<br />
			<br />
			Continue finding things in the ASCOM Profile Explorer and DCOMCONFG, 
			setting the Authentication level to Call. If you encounter a 
			non-ASCOM component that stopped working after KB4075892, and you 
			know it has a scripting or programming API then find it in DCOMCNFG 
			and change its Authentication Level to Call as well. This includes 
			ACP itself which is listed ACP Observatory Control Software.
		</blockquote>
	</div>
</div>
<!-- edit note -->			 
<blockquote class="auto-style1">
	Last edited by Bob Denny; Today at <span class="time">02:54</span>.
</blockquote>

</body>

</html>
