<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Gemini-2</title>
<link href="http://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css" />


<!DOCTYPE html 
      PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<link rel="stylesheet" href="https://gemini-2.com/ajxmenu.css" type="text/css">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta content="en-us" http-equiv="Content-Language" />
<title>Gemini 2 Mount Controller</title>

<link href="https://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css">
<style type="text/css">
a {
	color: #FF0000;
}
</style>


</head>
<body>
<table align="center" style="width: 900px">
	<tr><td align="center">
	<span class="h1">
		Gemini-2 and Gemini-1 Telescope Mount Controllers</span> <br />
		<span class="h2">Website and Tutorials </span>
		</td>
	</tr>
</table>


<table align="center" style="width: 900px">
	<tr>
		<td align="center">
<form action="https://www.google.com/search" method="get"> <div style="border:1px solid black;padding:4px;width:20em;"> <table align="center" border="0" cellpadding="0"> 
<tbody> 
<tr><td> <input maxlength="255" name="q" size="25" type="text" value="" /> <input type="submit" value="Google Search" /></td></tr> 
<tr><td align="center" style="font-size:75%"> <input checked="" name="sitesearch" type="checkbox" value="gemini-2.com" />
 only search Gemini-2.com<br /> </td></tr></tbody></table> </div> </form>
		
		</td>
	</tr>
</table>
<!--
<table align="center" style="width: 900px">
	<tr>
		<td class="style7" >
		There is a new <a href="http://wiki.gemini-2.com" target="_blank">Question and Answer Wiki</a> section where you can ask searchable questions.  		
		</td>
	</tr>
</table>
-->

<table align="center" style="width: 900px">
	<tr>
		<td align="center">
		</td>
	</tr>
</table>

<div class="AJXMenueDFaTFD"><!-- AJXFILE:ajxmenu.css -->
<ul>
 <li class="tfirst"><!--[if IE]><!--><a class="ajxsub" href="index.php" target="_self"><!--<![endif]-->Home/Start&nbsp;Here
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/Getting_started.php" target="_blank">1 - New Users Start Here</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/front_panel_pinouts.php" target="_blank"><!--<![endif]-->2.- Front Panel Pinouts
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Orginal Gemini-2 Version</a></li>
     <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">New Gemini-2 Mini</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/definitions.php" target="_blank">3 - Definitions</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->4.- Tutorials
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/quickstart/index.php" target="_blank">4.1 Quick Start &amp; Screen Alignment</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">4.2  Hand Controller</a></li>
     <li class="slast"><a href="https://gemini-2.com/alt-alignment.php" target="_blank" title="Manual method for adding a star to models.">4.3  Add a star to a model</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->5 - Videos
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_Videos.php" target="_blank">5a - Videos by Scott Losmandy on YouTube</a></li>
     <li class="slast"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">5b - Gemini.com  Videos</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->6 - Connecting Gemini-2 to Computer
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/connecting_Gemini_to_computers.php" target="_blank">6a- Connecting Gemini-2 to a computer</a></li>
     <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">6b-Using ASCOM with windows</a></li>
     <li class="slast"><a href="https://gemini-2.com/faqGII.php#Q3" target="_blank">6c - Multiple Gemini-2 on network</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/G2_Verse_G1-Modeling.php" target="_blank">7 - G2 Verse G1 modeling</a></li>
   <li><a href="https://gemini-2.com/web/index.php" target="_blank">8 - Web Interface Pages</a></li>
   <li><a href="https://gemini-2.com/limits.php" target="_blank">9 - Setting Limits - Very Important</a></li>
   <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">10 - Installing Gemini.net ASCOM driver</a></li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank">11 - FAQ about Gemini-2</a></li>
   <li><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">12 - Firmware versions and updating.</a></li>
   <li><a href="https://gemini-2.com/Simple_Rules_Gemini_Uses.php" target="_blank">13 - Rules that Gemini-2 follows:</a></li>
   <li class="slast"><a href="https://www.gemini-2.com/credits.php" target="_blank">13 - A little history</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini-2"><!--<![endif]-->Gemini&nbsp;2&nbsp;&nbsp;&nbsp;&nbsp;
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting Tips</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Start here for Gemini 2"><!--<![endif]-->Using the Gemini 2 controller
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/definitions.php" target="_blank">Definitions</a></li>
     <li><a href="https://gemini-2.com/alignment_procedure.php" target="_blank">Initial Alignment and Startup</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">Navigating Hand Controller Menus</a></li>
     <li><a href="https://gemini-2.com/web/index.php" target="_blank">Navigating the Internal Web Pages</a></li>
     <li><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Semi-Automatic Alignment Method</a></li>
     <li><a href="https://gemini-2.com/limits.php" target="_blank">Setting Limit switch drawing</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/E026.php" target="_blank" title="Will help you polar align the mount">Polar Axis Assist</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Connect G2 to Ethernet"><!--<![endif]-->Connectiong to Ethernet Port
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/ConnectingtoG2.php" target="_blank" title="connecting to web interface">Connecting to Ethernet Port</a></li>
     <li><a href="https://gemini-2.com/crossovernetwork.php" target="_blank" title="G2 directly to Computer">Configuring Win 10, Win7 &amp; XP for Static IP</a></li>
     <li><a href="https://gemini-2.com/Enabling_netbios.php" target="_blank">Enabling NetBios on Windows Networks</a></li>
     <li><a href="https://gemini-2.com/travel_routers.php" target="_blank">Adding WiFi to Gemini-2</a></li>
     <li><a href="https://gemini-2.com/ethernet_connections.php" target="_blank">Ethernet Connection methods/drawings</a></li>
     <li><a href="https://gemini-2.com/configuringEthernetASCOMdriver.php" target="_blank">Configuring The ASCOM Driver's Ethernet connection</a></li>
     <li class="slast"><a href="https://gemini-2.com/network-places.php" target="_blank">Adding the Gemini-2 to FTP network places</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank" title="5 ways to update firmware"><!--<![endif]-->Updating Gemini FIrmware
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">How to tell firmware versions</a></li>
     <li><a href="https://gemini-2.com/updatefirmwaremethods.php" target="_blank">Update Gemini Firmware Methods     </a></li>
     <li><a href="https://gemini-2.com/gfu.php" target="_blank">Using the Gemini Firmware Updater Program</a></li>
     <li><a href="https://gemini-2.com/Removing_SDCards.php" target="_blank">Removing and Replacing micro-SDcards</a></li>
     <li class="slast"><a href="https://gemini-2.com/copycatalogs.php" target="_blank">Adding Catalogs to the Handcontroller</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank" title="For Gemini 2">Frequently Asked Questions</a></li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#" title="Wiring"><!--<![endif]-->Gemini-2 Documentation
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">Movies produced for this site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Front Panel Pinouts and Connection Function Discriptions
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Original Gemini-2</a></li>
       <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">Gemini-2 Mini</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Cable Wiring
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/cable_wiring.php" target="_blank" title="Both G1 and G2">Serial Port Wiring</a></li>
       <li><a href="https://gemini-2.com/serial_port_modes.php" target="_blank" title="G2 only">Serial Port Modes</a></li>
       <li><a href="https://gemini-2.com/Losmandy_Serial_Cable.php" target="_blank" title="Inside of Losmandy Serial Cable">Losmandy Serial Cable </a></li>
       <li><a href="https://gemini-2.com/handcontroller-cable-ends.php" target="_blank">Hand Controller Cable</a></li>
       <li class="slast"><a href="https://gemini-2.com/hand_controller_extender.php" target="_blank">Hand controler Extender Addon</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">Losmandy Motors</a></li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
     <li><a href="https://gemini-2.com/Gemini2_features.php" target="_blank">Gemini-2 Features</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Gemini-2 and ASCOM Driver Errors</a></li>
     <li class="slast"><a href="https://gemini-2.com/Cksum.php" target="_blank" title="Courtesy of Paul Kanevsky">Gemini Command Checksum Calculator</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/hc/index.php" target="_blank"><!--<![endif]-->G-2&nbsp;HC&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/hc/E019A.php" target="_blank">Site</a></li>
   <li><a href="https://gemini-2.com/hc/E023A.php" target="_blank">Time</a></li>
   <li><a href="https://gemini-2.com/hc/En-networkmenu_A.php" target="_blank">Network</a></li>
   <li class="slast"><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Modeling</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/web/index.php" target="_blank" title="Web Tutorial"><!--<![endif]-->G-2&nbsp;Web&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/web/web-site-time.php" target="_blank" title="Web Site Time">Site Time</a></li>
   <li><a href="https://gemini-2.com/web/web-network.php" target="_blank" title="Web Network">Network</a></li>
   <li><a href="https://gemini-2.com/web/web-battery-ports.php" target="_blank" title="battery">Battery Voltage</a></li>
   <li class="slast"><a href="https://gemini-2.com/web/web-firmware-sram.php" target="_blank" title="Firmware Sram">Firmware SRAM</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini 1"><!--<![endif]-->Gemini&nbsp;1
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/faqG1.php" target="_blank">FAQ</a></li>
   <li><a href="https://gemini-2.com/G1drivers.php" target="_blank">G1 Driver/Manuals</a></li>
   <li><a href="https://gemini-2.com/pcb-pictures.php" target="_blank">Gemini 1 Versions</a></li>
   <li><a href="https://gemini-2.com/G1-repairers.php" target="_blank">Gemini Repair Facilities/People</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Changing batteries
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">Changing CR2354</a></li>
     <li class="slast"><a href="https://gemini-2.com/videos/changing_CR2032_battery.mp4" target="_blank">Changing CR2032</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/cable_wiring.php" target="_blank">RS-232 Cable wiring</a></li>
   <li><a href="https://gemini-2.com/G1_EPROM.php" target="_blank">Eprom Programming Sources and Source Code</a></li>
   <li><a href="https://gemini-2.com/usbtoserial.php" target="_blank" title="USB to Serial Converter recomendations">USB to Serial Port converter Recommendations</a></li>
   <li><a href="http://www.docgoerlich.de/L4Features.html" target="_blank">Level 4  Features</a></li>
   <li><a href="https://gemini-2.com/Gemini-1%20mods.php" target="_blank">Recommend Mod to extend battery life</a></li>
   <li class="slast"><a href="https://gemini-2.com/2nd_Communication_Port_Cable.php" target="_blank">2nd Communication Port Cable for Gemini 1</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Windows Only"><!--<![endif]-->ASCOM/USB/GPS
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="Installing_ASCOM.php" target="_blank">Installing ASCOM</a></li>
     <li><a href="Gemini2_drivers/GeminiTelescopeInstaller(1.0.72.0).exe" target="_blank" title="Version (1.0.72.0) supports G11T &amp; G811 + all others">ASCOM-Gemini.net Installer (Version 1.0.72.0)</a></li>
     <li><a href="configuringASCOMfirsttime.php" target="_blank">Setting up ASCOM for first time</a></li>
     <li><a href="Gemini2_drivers/Gemini_Telescope_Net_Installation_and_Operation.pdf" target="_blank">Gemini ASCOM Driver manual</a></li>
     <li><a href="configuringEthernetASCOMdriver.php" target="_blank">Setup ASCOM Ethernet Interface</a></li>
     <li><a href="DCOM-FIX-EXPLAIN.php" target="_blank">DCOM_Fix</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Menu
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/select_Ascom_options.php" target="_blank">How to select the different ASCOM menus</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMSetuppage.php" target="_blank" title="Configure Telescope">Configure Telescope Menu</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMAdvancedSetuppage.php" target="_blank" title="Advanced Gemini Setting">Advanced Gemini Setting</a></li>
       <li class="slast"><a href="https://gemini-2.com/Ascom_park_menu.php" target="_blank">The Park Menu</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/theSkyX_to_Gemini.php" target="_blank">Installing Gemini.net into TheSkyX</a></li>
     <li><a href="https://gemini-2.com/getting-GPS-into-ASCOMdriver.php" target="_blank">Get GPS data into Gemini.net Driver</a></li>
     <li><a href="https://gemini-2.com/scripting_examples.php" target="_blank">Example VB scripts</a></li>
     <li class="slast"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.0.pdf" target="_blank">UPD Protol Specifications</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->USB Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/L5-USB/USB_Drivers_for_Level_5_Firmware_after_June-4-2013.zip" target="_blank">Level 5 USB Drivers for Firmware dated Jun 4 2013 and later.</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->For Firmware previous to Jun 4, 2013 USB drivers 
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_32bit_USB_driver.zip" target="_blank">USB - Windows 32 Bit-PreLevel 5</a></li>
       <li><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_64bit_USB_driver.zip" target="_blank">USB Windows 64 Bit -Pre Level5</a></li>
       <li class="slast"><a href="https://gemini-2.com/installing_usb_drivers.php" target="_blank">USB Driver installion Instructions</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/featureport-serialport.php" target="_blank">USB cable for Feature Port</a></li>
     <li class="slast"><a href="https://gemini-2.com/usb-ethernet.php" target="_blank">Alternative to USB Drivers</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Help&nbsp;Topics
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://wiki.gemini-2.com" target="_blank">Gemini 1 &amp; 2 Question and Answer WIKI</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Mount and Misc Manuals"><!--<![endif]-->Manuals
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gemini Programming
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.2.pdf" target="_blank">UDP Protocol's</a></li>
       <li><a href="https://gemini-2.com/web/L5V2_1serial.html" target="_blank">Serial Command Description</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/CGICodes/CGIcodes.pdf" target="_blank">CGI codes</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Losmandy Mounts
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/losmandygoto/Gemini-II_Quick_Start_Guide_2_23b.pdf" target="_blank">Losmandy Gemini 2 Quick Start Guide</a></li>
       <li><a href="http://www.losmandy.com/pdf/gm-8-manual.pdf" target="_blank">Losmandy G8</a></li>
       <li><a href="http://www.losmandy.com/g-11-manual.html" target="_blank">Losmandy G11</a></li>
       <li><a href="http://www.losmandy.com/pdf/titan-instructions.pdf" target="_blank">Losmandy Titan</a></li>
       <li><a href="http://www.losmandy.com/pdf/polar-finder.pdf" target="_blank">Using Losmandy Polar Finder</a></li>
       <li><a href="http://www.gemini-2.com/downloads/pdf/GeminiL4UserManual.pdf" target="_blank">G1 Level 4 Manual</a></li>
       <li><a href="http://losmandy.com/gemini_servo_motor_install.html" target="_blank">Servo Mounting Instructions</a></li>
       <li class="slast"><a href="http://helixgate.net/G11opw.html" target="_blank" title="This is from Helixgate.net by Michael A. Siniscalchi">Assembling  One Piece Worm</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mountain Instruments
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.mi250.com/downloads/MI250%20Go-To%20Manual%202007.pdf" target="_blank">MI-250 Old - 2007 </a></li>
       <li class="slast"><a href="https://www.mi250.com/downloads/MI250%20Manual%202009.pdf" target="_blank">MI-250 New - 2009</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Guiding
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD1
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.rosecityastronomers.org/resources/pdf/GuideToGuiding.pdf" target="_blank">PHD Guiding manual</a></li>
         <li class="slast"><a href="http://www.stark-labs.com/phdguiding.html" target="_blank">PHD Guiding Software</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://openphdguiding.org/" target="_blank">PHD2 Software</a></li>
         <li><a href="http://openphdguiding.org/man/index.html" target="_blank">PHD2 On-Line Manual</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Tools.htm#Guiding_Assistant" target="_blank">Guiding Assistant</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Trouble_shooting.htm" target="_blank">Trouble Shooting</a></li>
         <li class="slast"><a href="https://openphdguiding.org/man-dev/Tools.htm#Star_cross_tool" target="_blank">Star-Cross Tool</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS</a></li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">ID Losmandy motor types</a></li>
     <li class="slast"><a href="http://screenshots.portforward.com/" target="_blank" title="Screeshots of most routers">Router Screen Shots</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Trouble Shooting
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting tips</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Problems</a></li>
     <li class="slast"><a href="https://gemini-2.com/handcontroller_errors.php" target="_blank">Trouble Shooting the touch screen.</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Time Zone Tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/hc/time_zone_offset_chart.php" target="_blank">Time Zone Offset Table for USA</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/timezonefacts.php" target="_blank">Time Zone Facts</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Tips from other sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank"><!--<![endif]-->G11/Gemini Tips from Mark Crossley
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.wilmslowastro.com/index.htm" target="_blank">Mark Crossley Home page</a></li>
       <li class="slast"><a href="https://www.google.com/search?q=methods+of+doing+polar+alignment+with+EQ+scopes&sourceid=ie7&rls=com.microsoft:en-US:IE-Address&ie=&oe=" target="_blank">Precision Polar Alignment -Astro-Tom.com</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://frazmtn.com/~bwallis/GEMINI_II_docx.pdf" target="_blank">Field Manual from Brad Wallis</a></li>
     <li><a href="http://www.company7.com/library/losmandy/notes.html" target="_blank">Gemini 1 info from Company 7</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://www.michaelherman.net/#!losmandy-g11-mount" target="_blank"><!--<![endif]-->Michael Herman G11 Tips
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/Michael_Herman/RA_Extension_Spacer.pdf" target="_blank">Installing the Partridge RA Extension.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Improving_OPW.pdf" target="_blank">Improving G11 OPW.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Making_7lb_counterweight.pdf" target="_blank">7 LB Counter Weight.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Polar_Scope_Improvements.pdf" target="_blank">New Rericle in the G11 Polar scope.pdf</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/Michael_Herman/Leveling_Handles.pdf" target="_blank">Leveling handles for Clutch Knobs</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank" title="Posted here till I can find the correct link for it">Titan Tips by Bob Allevo</a></li>
     <li><a href="https://gemini-2.com/downloads/Losmandy_Titan_Reassembly.pdf" target="_blank">Titan Reassembly courtesy of Ed Wily</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=gi3-VeQn7K0" target="_blank">Cable Management U-tube</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.sharpcap.co.uk/sharpcap/polar-alignment" target="_blank" title="Polar Alignment">Polar Alignment using SharpCap</a></li>
     <li><a href="http://astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Precision Polar Alignment-Astro-Tom</a></li>
     <li><a href="http://www.astro-baby.com/simplepolar/simple_polar_alignment.htm" target="_blank">Simple Polar Alignment</a></li>
     <li><a href="http://www.themcdonalds.net/richard/index.php?title=Polar_Alignment_of_your_Equatorial_Mount" target="_blank">Polar Alignment of your Equatorial Mount</a></li>
     <li><a href="http://astropixels.com/main/polaralignment.html" target="_blank">Polar Alignment using Drift Method</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=ArU5vC1o1Jk" target="_blank">PHD2 Drift Tool Tutorial</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gearboxs and Mods
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_New_Gearbox.php" target="_blank">Losmandy's New Gearbox</a></li>
     <li><a href="https://gemini-2.com/Gearbox_mod.php" target="_blank">Repairing the gearbox used on MI-250 and G11</a></li>
     <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mclennan Gearbox upgrade
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.horizontalheavens.com/mclennan_gearbox_upgrade.htm" target="_blank">Mclennan Gearbox upgrade by Horizontal Heavens</a></li>
       <li><a href="https://gemini-2.com/Mclennan_Gearboxes.php" target="_blank">Mclennan Gearbox upgrade by Hilmi Al-Kindy</a></li>
       <li class="slast"><a href="http://www.wilmslowastro.com/tips/mclennan_gbox.html" target="_blank">Replacomg the Losmandy Gearbox by Wilmslow Astro on MI-250</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Balancing your mount
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.wilmslowastro.com/tips/g11gemini.htm#balancing" target="_blank" title="Balancing your Mount">Balancing You Mount  by wilmslowastro.com</a></li>
     <li class="slast"><a href="http://starizona.com/acb/ccd/settingupbal.aspx" target="_blank">Balancing your mount by Starizona</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Useful Programs
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment methods
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->2 Star Alignment
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.alignmaster.de" target="_blank">Using 2 Stars with AlignMaster</a></li>
         <li class="slast"><a href="http://www.sharpcap.co.uk/sharpcap" target="_blank">SharpCap for use with Alignmaster</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Polar Alignment from Astro-Tom</a></li>
       <li><a href="http://www.celestialwonders.com/articles/polaralignment/" target="_blank">Polar Alignment Star offset method</a></li>
       <li><a href="http://celestialwonders.com/articles/polaralignment/polaralignmentsurvey.html" target="_blank">Survey of Polar Alignment Methods</a></li>
       <li><a href="http://canburytech.net/DriftAlign/" target="_blank">Understanding Drift Alignment</a></li>
       <li><a href="http://eqalign.net/e_index.html" target="_blank">EQAling</a></li>
       <li><a href="http://www.petesastrophotography.com/" target="_blank">Polar Alignment by Paul Kennett</a></li>
       <li><a href="http://www.andysshotglass.com/DriftAlignment.html" target="_blank">Polar Alignment by Andy's Shot Glass</a></li>
       <li class="slast"><a href="http://www.astrosurf.com/re/polar.html" target="_blank">Polar Alignment by Astrosurf</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Observatory programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.stellarium.org/" target="_blank">Stellarium</a></li>
       <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gude Programs
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst slast"><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank">MetaGude</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.bytearts.com/stellarium/" target="_blank" title="Make Stellarium ASCOM compatible for Windows">StellariumScope</a></li>
       <li><a href="http://www.ap-i.net/skychart/" target="_blank">SkyChart / Cartes du Ciel</a></li>
       <li><a href="http://zytratechnologies.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank">Setting up Stellarium</a></li>
       <li><a href="http://sourceforge.net/p/astrotortilla/home/Home/" target="_blank">AstroTortilla Astrophotography assistant</a></li>
       <li class="slast"><a href="http://lightvortexastronomy.blogspot.com/2013/08/tutorial-imaging-setting-up-and-using.html" target="_blank">Plate Solving with Astrotortilla</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Misc Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://darkhorizons.emissionline.com/GMB/gmb.htm" target="_blank">Gemini Model Builder</a></li>
       <li><a href="http://www.nirsoft.net/utils/usb_devices_view.html" target="_blank">View USB Port assignments </a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip FIle archiver use to zip and unzip all files on this site</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Disk and Partition Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.sdcard.org/downloads/formatter_4/" target="_blank">Micro SDcard Formatter</a></li>
       <li><a href="http://www.partitionwizard.com/" target="_blank">MiniTool Partition Wizard</a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs for Windows
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://filezilla-project.org/download.php?type=client" target="_blank">FileZilla</a></li>
       <li><a href="http://www.wsftple.com/download.aspx" target="_blank">WS_FTP LE (V12)</a></li>
       <li><a href="http://www.oldversion.com/WS_FTP_Limited_Edition.html" target="_blank">WS_FTP V6</a></li>
       <li class="slast"><a href="http://winscp.net/eng/index.php" target="_blank">WinSCP</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs For Mac
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.kekaosx.com/en/" target="_blank">Keka (7zip ported to OS X)</a></li>
       <li><a href="http://www.apple.com/downloads/macosx/internet_utilities/classicftpformac.html" target="_blank">Classic FTP</a></li>
       <li><a href="http://fetchsoftworks.com/">Fetch FTP</a></li>
       <li><a href="http://www.macorchard.com/filetransfer/" target="_blank">List of Many Mac FTP</a></li>
       <li class="slast"><a href="http://blog.hostilefork.com/trashes-fseventsd-and-spotlight-v100/" target="_blank">Hidden Files A MAC puts on the SDcard</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->GPS Related programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/GPSrelated/redirect.zip" target="_blank">GPS_Port_Director (No install necessary)</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/GPSrelated/VisualGPSInstall.zip" target="_blank">Visual GPS Installer</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Network Scanners
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.softperfect.com/products/networkscanner/" target="_blank">Softperfect Network Scanner</a></li>
       <li><a href="http://www.radmin.com/products/ipscanner/" target="_blank">Advanced IP Scaner</a></li>
       <li class="slast"><a href="http://free-ip-scanner.eusing-software.qarchive.org/" target="_blank">Free IP Scanner</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li class="slast"><a href="downloads/USV_View/usbdeview.zip" target="_blank">USB View - USB port scanner</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Power Controllers
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.digital-loggers.com/ac.html" target="_blank">AC Controlled Relay</a></li>
     <li><a href="http://www.digital-loggers.com/lpc7.html" target="_blank">Web Power Switch</a></li>
     <li class="slast"><a href="http://www.digital-loggers.com/EPCR5.html" target="_blank">Ethernet Power Controller 5</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li class="tlast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Favorites
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->User Groups
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://groups.io/g/Gemini-II/" target="_blank">Gemini-II at groups.io</a></li>
     <li><a href="https://groups.io/g/Gemini_users/" target="_blank">Gemini User Group at Groups.io</a></li>
     <li><a href="https://groups.io/g/Losmandy_users/" target="_blank">Losmandy User Group at Groups.io</a></li>
     <li><a href="http://groups.yahoo.com/neo/groups/Titan_Mount/info" target="_blank">Titian User Group</a></li>
     <li><a href="https://groups.io/g/MI-250/" target="_blank">MI-250 Users Group</a></li>
     <li><a href="https://groups.io/g/Gemini_ASCOM_Driver/" target="_blank">Gemini Ascom Driver Group at Groups.io</a></li>
     <li class="slast"><a href="http://groups.yahoo.com/neo/groups/ASCOM-Talk/info" target="_blank">Ascom Talk Group</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Web Sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.docgoerlich.de/Gemini.html" target="_blank">René Görlich's Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://losmandy.com" target="_blank"><!--<![endif]-->Losmand Links -Web Site
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/eq-mounts.html" target="_blank">Equatorial Mounts</a></li>
       <li><a href="http://www.losmandy.com/secondary.html" target="_blank">D Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/v-series.html" target="_blank">Y Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/losmandygoto/gemini2.html" target="_blank">Gemini 2 Goto Syste,</a></li>
       <li><a href="http://www.losmandy.com/starlapse.html" target="_blank">StarLapse System</a></li>
       <li><a href="http://www.losmandy.com/access.html" target="_blank">Telescope Accessories</a></li>
       <li><a href="http://www.losmandy.com/replacement.html" target="_blank">Replacement parts</a></li>
       <li><a href="http://www.losmandy.com/distributors.html" target="_blank">Dealers</a></li>
       <li><a href="http://www.losmandy.com/pricelist.html" target="_blank">Price List</a></li>
       <li><a href="http://www.losmandy.com/support.html" target="_blank">Technical Support</a></li>
       <li><a href="http://store.losmandy.com/">Ordering inside USA</a></li>
       <li><a href="https://secure28.securewebsession.com/losmandy.com/order.shtml" target="_blank">Ording International or custom parts</a></li>
       <li><a href="http://www.losmandy.com/whatsnew.html" target="_blank">Whats New</a></li>
       <li class="slast"><a href="https://www.valvoline.com/en-ecuador/our-products/grease/durablend-synthetic-blend-grease" target="_blank">Recommend Grease by Losmandy</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://www.mi250.com/" target="_blank">MI-250 Web Site</a></li>
     <li><a href="https://www.arizonaskys.com" target="_blank">ArizonaSkys (my obsevatory web site - under construction</a></li>
     <li><a href="http://www.ascom-standards.org/index.htm" target="_blank">Ascom Standards Org</a></li>
     <li><a href="https://www.nightskiesnetwork.ca/" target="_blank" title=" worldwide astronomy broadcast site">Night Skys Network</a></li>
     <li><a href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank">Wilmslow Astro G11 tips</a></li>
     <li><a href="http://astronomy.tools" target="_blank">Astronomy Tools - Calculators - FOV - Star Charts</a></li>
     <li><a href="http://www.skippysky.com.au/" target="_blank">SkippySky Astro-Weather Forcast</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Tuning the G11
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.astromaster.org/esperienze_file/G11maintenance_e.htm" target="_blank">Maintain and tune a G11 mount</a></li>
       <li class="slast"><a href="http://www.astro.uni-bonn.de/~mischa/mounts/g11_tuning.html" target="_blank">Tuning a G11- for 2000 or older mounts</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://garriou.didier.free.fr/astro/gemini_anglais.html" target="_blank">Didier Garriou Gemini Catalogs building site</a></li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank">Titan Tips by Bob Allevo</a></li>
     <li><a href="http://www.stargps.ca/" target="_blank">Star GPS Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://openphdguiding.org/" target="_blank">PHD2 Home</a></li>
       <li><a href="https://code.google.com/p/open-phd-guiding/wiki/DriftAlignmentWithPHD2" target="_blank">Open-phd-guiding</a></li>
       <li><a href="https://groups.google.com/forum/#!forum/open-phd-guiding" target="_blank">Discussion Group </a></li>
       <li class="slast"><a href="https://www.youtube.com/watch?v=LXFGRta98rs" target="_blank">Introduction to optimal auto - guiding: How to get the most from your set - up</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://www.sharpcap.co.uk/" target="_blank">SharpCap</a></li>
     <li class="slast"><a href="https://sites.google.com/site/astropipp/" target="_blank">Planetary Imaging Software</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/all-links.php" target="_blank">300+ Astronomy Links</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
</ul>
 <br >
</div>

</body>






<style type="text/css">
.auto-style1 {
	text-decoration: underline;
}
</style>




</head>

<body style="color: #FFFFFF; background-color: #000000">

<table style="width: 900px" align="center">
	<tr>
		<td class="h2"><br />
		Connecting to Web interface of Gemini 2
		</td>
	</tr>
	<tr>
		<td class="style6"><br />
		This guide will help you connect using the Ethernet connection to your Gemini 2.&nbsp;
		<span class="style2"><strong>NOTE: "PORT E" AT THE TOP IS NOT AN 
		ETHERNET PORT. DO NOT CONNECT AN ETHERNET CABLE INTO IT. Also make 
		sure you do not plug the Ethenet cable into Port F. </strong></span></td>
	</tr>
	<tr>
		<td class="style6">
		Advantages of using Ethernet over other connections interfaces.
		<ol>
			<li>Makes the web interface of the Gemini-2 accessable. This can 
			only be accessed through the Ethernet port, using a web browser.&nbsp; 
			Almost all web browsers including ones in cell phones and tablets 
			are supported.&nbsp;&nbsp; </li>
			<ul>
				<li>Use with wireless router to provide wireless control via 
				Smart Phones/Tablets</li>
				<li>Selection all of the targets in all the catalogs.</li>
				<li>Upload individual files to the SDcard, such as updates 
				to the main Processor, or updates to the hand controller.&nbsp; 
				Can also upload catalogs to the hand controller or main unit.</li>
				<li>See the status of all ports, battery, and power 
				connections.</li>
				<li>See how the servo 
				motors are preforming.</li>

			<li>Totally control the Gemini-2 with the Web
			interface if you want.  </li>
				<li>It provides for slewing to targets, </li>
				<li>Building a model, </li>
				<li>Moving the telescope,
				</li>
				<li>Setting almost all setting.  </li>
				<li>Watching what the ports, and power levels are doing.&nbsp; </li>
			<li>Longer wire lengths than USB or serial without special made cables.
			</li>
			<li>Faster than USB or serial.</li>
			<li>Can be made wireless. </li>
			<li>Can use File Transfer Protocal (FTP) into the micro-SDcard 
			contents, to save models, PEC and other setting to a computer and restore them.
			</li>
			<li>Ethernet cable can be less expensive.
			</li>
			<li>Much more reliable.
			</li>
			<li>Less cables to the Gemini-2.
			</li>
			<li>Access the Gemini-2 from any computer on your network. </li>
			<li>Able to Update Firmware via an FTP connection, or the NEW Gemini 
			Firmware Updater Program.</li>
			</ul>
		</ol>
		<p>&nbsp;</p>
		<ol start="2">
			<li>Can control the mount using the Gemini.net ASCOM driver.<ul>
				<li>Mount Control</li>
				<li>Guiding through the same connection - called pulse guiding</li>
			</ul>
			</li>
			<li>Provides some ground loop isolation</li>
			<li>Not restricted to short distant, as USB is.</li>
			<li>If a wireless adapter such as a&nbsp; Netgear WNCE2001 or D-Link 
			DAP-1350&nbsp; AP is used then wireless Wifi connection to the mount.</li>
		</ol>
		
		</td>
	</tr>
	<tr class="style6">
		<td class="style3"><br />
		Connecting to a Network:
		</td>
	</tr>
	<tr>
		<td class="style6">
			Gemini 2 firmware can be updated using a built-in web interface.  In order to use the web 
			interface, you will need to make a network connection between Gemini and your computer.  
			Note: the Ethernet Port on the Gemini-2 is a dual speed port 
			(10/100mbits).&nbsp; This means it is either 10Mbits per second or 100 Mbits per 
			second which is determined by the device you are connecting too.&nbsp; 
			Because of this, connecting to a computer or device that has the 
			same speed liminations can be problematic. Most devices that only 
			have this speed range cannot detect what wiring an Ethernet cable 
			has.&nbsp; So if you are trying to connect the Gemini-2 to a 
			computer/laptop, that only has a 10/100 Mbits connection, the 
			connection is more than likely to fail.&nbsp; To prevent this, It takes 
			either an auto detecting Ethernet port or a 3 speed port such as&nbsp;a 
			10/100/1000 Mhz port to detect what kind of cable is being used.&nbsp; Most 
			modern routers are now what is called Gibit Routers (10/100/1000) 
			speed or auto detecting and can detect the cable type. Many of the Newer Win10 laptops 
			are also. The Gemini-2 cannot determine 
			the cable type.&nbsp; But this only has to be done on 
			one end of the cable by one GBit Device, I.E. a Gibit Computer, Router or 
			Switch.&nbsp; If your Computer, Router, or Switch is not a Gibit 
			model or auto detecting, you might have to use what is called a
			<a href="https://en.wikipedia.org/wiki/Ethernet_crossover_cable" target="_blank">
			cross-over</a> cable, to allow the Gemini-2 and computer to see each 
			other.<br />
			<br />
			Now we will discuss networking methods for devices to get each 
			others ID or IP address.<br />
			
			<ol><li>			
			Using a router. This is called <a href="#Network_with_DHCP:">
			Network with DHCP</a>.&nbsp; I find this the easiest method.&nbsp; 
			The router can assign the Gemini-2 an IP address, as long as the 
			base subnet address of the router is in the
				http://192.168.x.xxx range.&nbsp; If it is not, then you will have to 
				manually change the Gemini-2 IP address to match the routers 
				base Default Gateway address.&nbsp;&nbsp; Examples would be change 
				the gemini-2 Default Gateway address to http://192.168.0.1, 
				which it normally defaults to.&nbsp; Some routers such as 
				Netgear brands use http://192.168.1.1 for there Default Gateway 
				so you would put the Default Gateway to 192.168.1.1.&nbsp; With 
				these setting then the router can assign an empty DHCP IP 
				address to the Gemini-2. <span class="auto-style1"><em>On any local network, no two devices 
				can have the same IP address. All devices on a network must have 
				it's own unique IP address.</em></span>&nbsp; Also note that although the Hand controller can show the
				IP address, the address shown is that of the main Gemini 2 unit.  The hand controller does not have
				it's own Ethernet connection or IP address.&nbsp; Please note: 
				Some browsers try to connect using a secure connection,&nbsp; 
				https://&nbsp; This will not work with the Gemini-2.&nbsp; It 
				has to start with http://<br /><br /></li>
			<li><a href="#The_Direct_Method">The Direct method</a>. This 
				method uses a Ethernet cable directly between you computer and 
				the Gemini-2.&nbsp;&nbsp; If your computer has a 10/100 Mbit 
				Port, then you will have to use a Crossover cable.&nbsp; If your 
				computer has a 10/100/1000Mhz port then you can use either a 
				crossover or a standard patch cable.&nbsp; A 10/100/1000Mhz Switch or hub might also be 
				inserted into this method, and then standard patch cables can be 
				used.&nbsp; Note: A hub does not provide any method of changing IP addresses.&nbsp; 
			I would like to recommend a
			<a href="http://plugable.com/products/usb2-e1000" target="_blank">
			USB to Gigabit Ethernet adapter</a> instead of a cross-over cable if 
			your computer does not have a 10/100/1000 bit Ethernet port, and you 
			do not want to use an external hub.&nbsp; 
			This will give your computer two hardware Ethernet ports, assuming 
			your computer already has one.<br /><br />
			</li>
				<li>Here is a <a href="ethernet_connections.php">drawing of 
				these methods</a>, the top 2 illustrations are the direct method and the 
				bottom is the Router method. Now if the router or switch is 
				10/100/1000 (Gigabit) then either type of cable can be used.<br /><br /></li>
				<li>To test where a connections is working use a web browser and 
				enter the web interface by using 
				<a href="http://gemini/" target="_blank">http://gemini/</a> or 
				<a href="http://192.168.0.111" target="_blank">http://192.168.0.111</a> or http://your gemini2's IP address,
				into the address bar of the web browser.&nbsp; A login box will should 
				show up 
				as shown <a href="/web/index.php" target="_blank">here</a>.&nbsp; 
				Please note: Some browsers try to connect using a secure 
				connection,&nbsp; https://&nbsp; This will not work with the 
				Gemini-2.&nbsp; It has to start with http://<br /> Here is a video showing the 
		process of accessing the
		<a href="http://gemini-2.com/videos/MP4/get_into_web_interface.mp4" target="_blank">web 
		interface</a>.</li></ol>

		</td>
	</tr>
</table>

<hr class="Red" noshade="noshade" style="width: 800px; height: 4px" />


<table style="width: 900px" align="center">
	<tr>
		<td class="style6">	
			<a name="Network_with_DHCP:">Network with DHCP:</a>
		</td>
	</tr>
	<tr>
		<td class="style6">
			Supports (typical configuration for most home networks with a router):  If you are connecting 
			Gemini to an existing network through a switch, hub, router or wireless adapter, and 
			there is a DHCP server on the network, use this procedure.  Gemini will be assigned an 
			IP address by the DHCP server.  It is important that your computer also be set to either 
			use DHCP to get an IP address, or use a static IP address on the same subnet.
		</td>
	</tr>
	<tr>
		<td class="style6">
			<ol>
				<li>Connect the Gemini 2 unit to the existing network through a hub, switch, router or wireless 
					adapter.
				</li>
				<li>Power Gemini on.  It is important that you do this only after you’ve connected 
					the network cable so that it can communicate with the DHCP server.
				</li>
				<li>Make sure your computer is set to receive an IP address from DHCP.  Each 
					operating system does this in a different way, so refer to your OS documentation.
				</li>
				<li>Gemini uses <a href="Enabling_netbios.php" target="_blank">NetBIOS name resolution</a> 
				so that you don’t need to type the IP address into your browser. 
				Enter <a href="http://gemini">http://gemini</a>  in your browser to access the 
					web server.  The username is “admin” and the default password is blank. 
				If you can connect to the Gemini-2 using an IP address in your 
				computer's Web Browser, but not using <a href="http://gemini">
				http://gemini</a> then you can almost bet that the NetBios 
				resolution is turned off for your computer. See below for how to 
				turn it on.</li>
				<li>You may optionally configure your DHCP server to assign a specific 
					address to Gemini so that you can always access it using the same IP address.  
					See the documentation for your DHCP server for details how to do this.  
					Note: your DCHP server is often built into your internet router.
				</li>
			</ol>

		</td>
	</tr>
</table>

<hr class="Red" noshade="noshade" style="width: 800px; height: 4px" />

<table style="width: 900px" align="center">
	<tr>
		<td class="style6">
			<a name="The_Direct_Method">The Direct Method</a>:<br />
			This is most easily done using a cross-over Ethernet cable directly 
			between Gemini’s Ethernet connector and your computer’s network 
			connector.&nbsp;&nbsp; If your computer has a 10/100/1000Mhz port then you can 
			use either a crossover or a standard patch cable. Alternatively, you 
			can use a Gibit Ethernet hub/switch (not&nbsp; a router) and 
			standard cables between Gemini and the hub/switch and between your computer 
			and the hub.<br />
			<br />
			IP Address: In order to successfully communicate with your computer 
			over the network, the Gemini 2 unit must have an IP address on the same subnet as the computer.  
			There are several ways to do this depending on how you connect Gemini to a network.  
			The following sections describe these methods.
			<br />
			<br />
			If 
			you use a direct Ethernet cable to directly connect your computer to Gemini, you’ll 
			need to assign both the computer’s Ethernet port and Gemini-2 to IP addresses on the same 
			subnet by hand.  This assumes that your computer is not running a DHCP server on the network port.  
			By default, if Gemini doesn’t get an IP address assigned by DHCP, it will use its stored 
			value (<a href="http://192.168.0.111" target="_blank">192.168.0.111</a>) by default).&nbsp; 
			I know of no computer that can assign attached devices a DHCP 
			address unless you have set it up for
			<a href="http://windows.microsoft.com/en-us/windows/using-internet-connection-sharing#1TC=windows-7" target="_blank">
			Internet Connection sharing</a>.&nbsp; So the Static address is usually a must.
		</td>
	</tr>
	<tr>
		<td class="style6"><br />
			<ol>
				<li>
					Use a direct cable to connect Gemini 2’s Ethernet port to an 
					Ethernet port on your computer. What type of cable depends 
					on your computers port specifications, see above.</li>
				<li>
					Use the appropriate tools on your computer to assign a static 
					IP address to the computer’s Ethernet port.  
					Use either my
					<a href="crossovernetwork.php" target="_blank">instructions 
					for Windows 10, 8.1 or XP</a> or these  
					<a href="http://www.howtogeek.com/howto/19249/how-to-assign-a-static-ip-address-in-xp-vista-or-windows-7/" target="_blank" title="Tells how to set up a static IP in XP, Vista and Win 7">
					(How-To Geek has a web page telling how to assign a static 
					address in a computer for XP through Win10.)</a>
					The address should be in the form 192.168.0.xxx where xxx 
					is any number between 2 and 254 except 111.  Also make sure 
					no other device is using the same address.&nbsp; No two 
					Ethernet devices can use the same address on a network.&nbsp; Set the subnet mask to 255.255.255.0.  
					Set the default gateway to 192.168.0.1 <br />On Windows, you can do this from the control panel.  Look for an option to change 
					network connections.  Refer to your OS documentation for specific instructions.&nbsp; 
					Now if you have a router such as a Netgear, then that 
					routers default gateway is more than likely going to be 
					192.168.1.1&nbsp; If your routers gateway looks like this, 
					then you probably want to use setting to match that.&nbsp; 
					Change your computers hardware port to an address that is the form 192.168.1.xxx where xxx 
					is any number between 2 and 254 except 111.  Set the subnet mask to 255.255.255.0.  
					Set the default gateway to 192.168.1.1&nbsp;&nbsp; Now set 
					the Gemini-2 to 192.168.1.111 using the hand controller.</li>
				<li>
					You will need to know your computers default gateway.&nbsp; 
					You can obtain it by running a command prompt (click on cmd 
					and select run as administrator). See
					<a href="https://docs.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig" target="_blank">
					IPCONFIG Example</a>.&nbsp; At the cursor type: ipconfig 
					/all <br />This will show you the default gateways, mac address, 
					and IP addresses of all of your Ethernet ports, if they have 
					been assigned.<br />
				</li>
				<li>
					Power on Gemini and attempt to access the web server at 
					<a href="http://Gemini" target="_blank">http://Gemini</a> or 
					<a href="http://192.168.0.111" target="_blank">http://192.168.0.111</a>.&nbsp; 
					or as above if your network is not using the same gateway 
					address.&nbsp; If this doesn’t 
					work, use the hand controller menu to ensure that Gemini’s IP address is 
					<a href="http://192.168.0.111" target="_blank">http://192.168.0.111</a> by 
					selecting the menu->mount->network options.  If it is not set to that address, 
					then you can either change your computer’s IP address to match Gemini’s IP address or 
					you can change Gemini’s IP address to match your computers.&nbsp;
					Please note: Some browsers try to connect using a secure 
					connection,&nbsp; https://&nbsp; This will not work with the 
					Gemini-2.&nbsp; It has to start with http://</li>			
				<li>
					Gemini uses NetBIOS name resolution so that you don’t need to type the IP address into your 
					browser.  If you haven’t already done so, enter 
					<a href="http://gemini" target="_blank">http://gemini</a>  in your browser to 
					access the web server.  The username is “admin” and the default password is blank. 
					Here us an example of the login screen (with the user name already added): 
				</li>
				<li>
					If the steps in step 4 above do not work, you may need to 
					enable NetBios over TCIP.&nbsp; The sets are listed at the 
					bottom of this page.</li>
			</ol>
		</td>
	</tr>
	<tr>
		<td class="style7"><br />
			<img src="gemini-images/firmware_update/login.JPG" />
			<br />Fig 1
		</td>
	</tr>
	<tr>
		<td class="style6"><br />
			
	</td>
	</tr>
</table>

<hr class="Red" noshade="noshade" style="width: 800px; height: 4px" />


<table style="width: 900px" align="center">
	<tr class="style6">
		<td class="style3">
			Network without DHCP Support:
		</td>
	</tr>
</table>

<table style="width: 900px" align="center">
	<tr>
		<td class="style6">
			You may also have an existing network that does not use a DHCP server to assign IP addresses.  
			Such a network may be using IP auto configuration or static IP addresses in all of your machines.
			<ol>
				<li>Connect the Gemini 2 unit to the existing network through a hub, switch, 
					router or wireless adapter.</li>
				<li>Power Gemini on.</li>
				<li>Power your computer on, if it is not on already.  Look to see what IP address is assigned 
					to the Ethernet port on your computer.  Each OS has a different way to do this, so refer 
					to your OS documentation.  On most versions of Windows, you can type “ipconfig” in a 
					command prompt to see the IP address.</li>
				<li>Use the hand controller menu->mount->network buttons to access Gemini’s 
					IP address. Uncheck the DP checkbox.  Click on the IP address field 
					and change it to an IP address on the same subnet as you computer.  
					For example, if your computer’s IP address is 169.254.36.12, you 
					should set Gemini’s address to 169.254.36.xxx where xxx is a number 
					between 1 and 254 other than 12.  You should also ensure that you 
					do not set Gemini’s IP address to be the same as any other node on 
					the network.
				</li>
				<li>Gemini uses NetBIOS name resolution so that you don’t need to type the 
					IP address into your browser.  Enter 
				<a href="http://gemini/">http://gemini</a>  in your browser 
					to access the web server.  The username is “admin” and the default 
					password is blank. Note: Firmware versions after Feb 10, 2011 behave 
					as described above.  Versions between Feb 6th and Feb 
					10th don’t support NetBIOS name resolution, so you must 
					type the Gemini’s IP address in your browser rather than 
					using the hostname “Gemini.”  Versions previous to Feb 6th 
					do not support DHCP and must be configured as if you are 
					using a cross-over cable or network without DHCP server 
					as described above.  Versions between Jan 23rd and Feb 
					6th use 192.168.0.111 as the IP address, and version 
					prior to Jan 23, 2011 use 192.168.0.100.
				</li>
			</ol>		
		</td>
		<td class="style7">
		From Main Hand Controller Menu use "Menu"==>"Mount"==>"Network"&nbsp; 
		or "Menu"==&gt;"System"=="network" to see this menu.<br />
		<img alt="" height="611" src="hc/En-Images/En-Networkmainmenu.jpg" width="450" /></td>
	</tr>
</table>

<hr class="Red" noshade="noshade" style="width: 800px; height: 4px" />


<table style="width: 900px" align="center">
	<tr class="style6"><td class="style3"><br />
		Configuring the ASCOM Gemini.net Driver to use an Ethernet connection:
		
		</td>
	</tr>
	<tr><td class="style6">
	Of course to use the ASCOM Gemini.net driver, you must have ASCOM 6.2 installed and also the Gemini.net ASCOM driver.
	See <a href="http://www.ascom-standards.org/index.htm" target="_blank">http://www.ascom-standards.org/index.htm</a> 
		to download the latest ASCOM Platform, and then you can get the latest 
		driver from this site. See the Menu selection at the top of the page 
		Under Gemini-2 and download the Gemini.net ASCOM driver.&nbsp;  Once you have the Gemini.net driver installed, goto this page to 
		<a href="configuringEthernetASCOMdriver.php" target="_blank">Configuring the 
		ASCOM Driver Ethernet port</a>.
		</td>
	</tr>
</table>

<hr class="Red" noshade="noshade" style="width: 800px; height: 4px" />


<table style="width: 900px" align="center">
	<tr class="style6"><td class="style3"><br />
		Enabling NetBios over TCIP for Local Network:
		</td>
	</tr>
</table>
<table style="width: 900px" align="center">
	<tr><td class="style6">
		Netbios is what will allow you to use the 
		<a href="http://gemini" target="_blank">http://gemini</a>&nbsp; if using 
		a web page to access the Web interface, or <a href="ftp://admin@gemini">
		ftp://admin@gemini</a> if 
		using Windows File manager to access the directories/files of the micro 
		SDcard, instead of <a href="http://192.168.0.111">http://192.168.0.111</a> 
		(or what ever the Gemini-2 ip address is), or again
		<a href="ftp://admin@192.016.0.111">ftp://admin@192.016.0.111</a> for 
		accessing the SD card contents.<br />
&nbsp;<br />
	Some Windows systems do not have NetBios enabled. <br />
		Note: Normally the default setting on Windows assumes the following: "Use NetBios 
		setting from the DHCP server."&nbsp;&nbsp;
		However, if a static IP address is used or the DHCP server does not 
		provide NetBios setting, then enable NetBios over TCIP"<br />
		
		See <a href="Enabling_netbios.php" target="_blank">this page </a>for instructions on how to do this for Windows 7, XP and 
		95/98/ME.
	</td></tr>
</table>
<table style="width: 900px" align="center">
	<tr><td class="style6">
		There is also one other thing to take into account when connecting the 
		Gemini-2 itself, or any WiFi enabled device. If you are using a bridge 
		to connect the Gemini-2 using WiFi then you need to be aware that some routers let you block WiFi connected devices by there MAC 
			address.&nbsp;&nbsp; 
	</td></tr>
</table>
<table style="width: 900px" align="center">
	<tr><td></td></tr>
	<tr><td>  
		<a href="http://www.microsoft.com/en-us/download/details.aspx?id=21" target="_blank">
		Microsoft Net Framework 4.5</a> is required for the Gemini.net driver 
		and ASCOM 6.1 to function.&nbsp; Note that Microsoft Net 3.5 Framework is 
		installed by default in Windows 7, but it might not be turned on.&nbsp; 
		You will have to download the Net Framework 4.5 from Microsoft.&nbsp; 
		See&nbsp;
		<a href="http://www.microsoft.com/en-us/download/details.aspx?id=30653" target="_blank">
		Microsoft .Net Framework 4.5</a> </td></tr>
</table>

<!--
<table  align="center" style="width:900px">
	<tr>
	<td class="style6-border-white">
		May I  suggest you invest in a cheap but effective Cat5/Cat6 cable tester. Cost me less than $5.00 including shipping.&nbsp; <br />
		RJ45-RJ11-Cat5e-Cat6-Network-Lan-Cable-Tester 
		from Ebay for about $5.00 or search Ebay for 
		RJ45-RJ11-Cat5e-Network-Lan-Cable-Tester or web for NHSL-468<br />
		<br />Here is an example of it.  Works great, and easy to use.<br />
		<img alt="" height="833" src="gemini-images/cables/cable-tester1.jpg" width="900" /></td>
</tr>
</table>
-->

<table  align="center" style="width:900px">
	<tr>
		<td class="style7whiteborder" >
		Page last updated on June 23, 2018
		</td>
	</tr>
</table>

</body>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>


<head>
<title>Bottom page</title>
<link href="/gemini-2.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/ajxmenu_bottom.css" type="text/css">


</head>

<body style="color: #FFFFFF; background-color: #000000" >
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">This site is not for profit 
		and sells nothing and asks for no money for any help it provides.&nbsp; This 
		site is 
		here to help fellow Gemini-2 and Gemini-1 owners. This Web Site is not 
		associated with Losmandy-Hollywood General Machining Inc. or any of 
		their employees and never has been. There is no guarantee that all the 
		information is correct, but strives to provide the best information 
		possible. The use of any information is at your own risk.&nbsp; The webmaster 
		is an unpaid beta tester, and tries to work with other beta testers, and 
		René the writer of the firmware.&nbsp;
		If you would like to help keep this web site going send your gift to <a href="http://paypal.me/geminitwo">paypal.me/geminitwo</a> 
		Your gift will be used to defray the cost of keeping this web site up, unless you specify otherwise.</span></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">
		I have tried many times to make a PDF of this site with no luck. Every program
		to do this screws up the links and images. I am not going to write a manual either.
		I developed this web site for my own use in the beginning, but it soon went public.</span></td>
	</tr>
</table>

	<table align="center" style="width: 900px">
		<tr>
			<td>
<div class="AJXMenuSPDSMNA"><!-- AJXFILE:ajxmenu_bottom.css -->
 <div class="ajxmw1">
  <div class="ajxmw2">
<ul>
 <li class="tfirst tlast"><a href="https://www.gemini-2.com/" target="_self">HOME</a></li>
</ul>
  </div>
 </div>
 <br >
</div>
</td>
</tr>
</table>

<!--
<table align="center"style="width: 50px">
	<tr>
	<td class="style6">Hit counter by<a href="http://digits.net"> http://digits.net</a></td>
	
	
	<td class="style6R" width="45%">
  <a href="http://www.digits.net" target="_blank">
    <img src="https://counter.digits.net/?counter={921ba194-f2d6-95c4-2981-2437d185efba}&template=simple" 
     alt="Hit Counter by Digits" border="0"  />
  </a>
  </td>
  </tr>
</table>
-->
&nbsp;<table align="center" cellpadding="4" cellspacing="4" style="width: 70%">
	<tr class="style6">
		<td class="style1">Your Privacy Policy
<br>No Information is collected by this site.&nbsp; Cookies are set in your browser, 
but only for visited<br/>links to change color.
</td>
	</tr>
	<tr class="style6">
		<td class="style13"><b>Your use of any information on this site is at your own risk.</b></td>
	</tr>
</table>
		
	<p class="style7" align="center"><!--webbot bot="HTMLMarkup" startspan --><script language=javascript>

	  <!--
	  var contact = "Thomas Hilton"
	  var email = "tomh"
	  var emailHost = "gemini-2.com"
	  document.write("copyright&copy; - 2017-2011 -<a href=" + "mail" + "to:" + email + "@" + emailHost+ ">" + contact + "</a>" )
	 //-->
	</script><!--webbot bot="HTMLMarkup" endspan -->
	and <a href="Https://www.Gemini-2.com">https://www.gemini-2.com</a>
	<br />Gemini-2 and Gemini is a registered trade names of Hollywood General Machining Inc.</p>

	
</body>





</html>
