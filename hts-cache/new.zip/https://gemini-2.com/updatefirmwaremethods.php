<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Update Firmware for Gemini 2</title>

<link href="http://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css" />


<!DOCTYPE html 
      PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<link rel="stylesheet" href="https://gemini-2.com/ajxmenu.css" type="text/css">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta content="en-us" http-equiv="Content-Language" />
<title>Gemini 2 Mount Controller</title>

<link href="https://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css">
<style type="text/css">
a {
	color: #FF0000;
}
</style>


</head>
<body>
<table align="center" style="width: 900px">
	<tr><td align="center">
	<span class="h1">
		Gemini-2 and Gemini-1 Telescope Mount Controllers</span> <br />
		<span class="h2">Website and Tutorials </span>
		</td>
	</tr>
</table>


<table align="center" style="width: 900px">
	<tr>
		<td align="center">
<form action="https://www.google.com/search" method="get"> <div style="border:1px solid black;padding:4px;width:20em;"> <table align="center" border="0" cellpadding="0"> 
<tbody> 
<tr><td> <input maxlength="255" name="q" size="25" type="text" value="" /> <input type="submit" value="Google Search" /></td></tr> 
<tr><td align="center" style="font-size:75%"> <input checked="" name="sitesearch" type="checkbox" value="gemini-2.com" />
 only search Gemini-2.com<br /> </td></tr></tbody></table> </div> </form>
		
		</td>
	</tr>
</table>
<!--
<table align="center" style="width: 900px">
	<tr>
		<td class="style7" >
		There is a new <a href="http://wiki.gemini-2.com" target="_blank">Question and Answer Wiki</a> section where you can ask searchable questions.  		
		</td>
	</tr>
</table>
-->

<table align="center" style="width: 900px">
	<tr>
		<td align="center">
		</td>
	</tr>
</table>

<div class="AJXMenueDFaTFD"><!-- AJXFILE:ajxmenu.css -->
<ul>
 <li class="tfirst"><!--[if IE]><!--><a class="ajxsub" href="index.php" target="_self"><!--<![endif]-->Home/Start&nbsp;Here
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/Getting_started.php" target="_blank">1 - New Users Start Here</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/front_panel_pinouts.php" target="_blank"><!--<![endif]-->2.- Front Panel Pinouts
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Orginal Gemini-2 Version</a></li>
     <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">New Gemini-2 Mini</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/definitions.php" target="_blank">3 - Definitions</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->4.- Tutorials
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/quickstart/index.php" target="_blank">4.1 Quick Start &amp; Screen Alignment</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">4.2  Hand Controller</a></li>
     <li class="slast"><a href="https://gemini-2.com/alt-alignment.php" target="_blank" title="Manual method for adding a star to models.">4.3  Add a star to a model</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->5 - Videos
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_Videos.php" target="_blank">5a - Videos by Scott Losmandy on YouTube</a></li>
     <li class="slast"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">5b - Gemini.com  Videos</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->6 - Connecting Gemini-2 to Computer
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/connecting_Gemini_to_computers.php" target="_blank">6a- Connecting Gemini-2 to a computer</a></li>
     <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">6b-Using ASCOM with windows</a></li>
     <li class="slast"><a href="https://gemini-2.com/faqGII.php#Q3" target="_blank">6c - Multiple Gemini-2 on network</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/G2_Verse_G1-Modeling.php" target="_blank">7 - G2 Verse G1 modeling</a></li>
   <li><a href="https://gemini-2.com/web/index.php" target="_blank">8 - Web Interface Pages</a></li>
   <li><a href="https://gemini-2.com/limits.php" target="_blank">9 - Setting Limits - Very Important</a></li>
   <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">10 - Installing Gemini.net ASCOM driver</a></li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank">11 - FAQ about Gemini-2</a></li>
   <li><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">12 - Firmware versions and updating.</a></li>
   <li><a href="https://gemini-2.com/Simple_Rules_Gemini_Uses.php" target="_blank">13 - Rules that Gemini-2 follows:</a></li>
   <li class="slast"><a href="https://www.gemini-2.com/credits.php" target="_blank">13 - A little history</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini-2"><!--<![endif]-->Gemini&nbsp;2&nbsp;&nbsp;&nbsp;&nbsp;
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting Tips</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Start here for Gemini 2"><!--<![endif]-->Using the Gemini 2 controller
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/definitions.php" target="_blank">Definitions</a></li>
     <li><a href="https://gemini-2.com/alignment_procedure.php" target="_blank">Initial Alignment and Startup</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">Navigating Hand Controller Menus</a></li>
     <li><a href="https://gemini-2.com/web/index.php" target="_blank">Navigating the Internal Web Pages</a></li>
     <li><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Semi-Automatic Alignment Method</a></li>
     <li><a href="https://gemini-2.com/limits.php" target="_blank">Setting Limit switch drawing</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/E026.php" target="_blank" title="Will help you polar align the mount">Polar Axis Assist</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Connect G2 to Ethernet"><!--<![endif]-->Connectiong to Ethernet Port
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/ConnectingtoG2.php" target="_blank" title="connecting to web interface">Connecting to Ethernet Port</a></li>
     <li><a href="https://gemini-2.com/crossovernetwork.php" target="_blank" title="G2 directly to Computer">Configuring Win 10, Win7 &amp; XP for Static IP</a></li>
     <li><a href="https://gemini-2.com/Enabling_netbios.php" target="_blank">Enabling NetBios on Windows Networks</a></li>
     <li><a href="https://gemini-2.com/travel_routers.php" target="_blank">Adding WiFi to Gemini-2</a></li>
     <li><a href="https://gemini-2.com/ethernet_connections.php" target="_blank">Ethernet Connection methods/drawings</a></li>
     <li><a href="https://gemini-2.com/configuringEthernetASCOMdriver.php" target="_blank">Configuring The ASCOM Driver's Ethernet connection</a></li>
     <li class="slast"><a href="https://gemini-2.com/network-places.php" target="_blank">Adding the Gemini-2 to FTP network places</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank" title="5 ways to update firmware"><!--<![endif]-->Updating Gemini FIrmware
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">How to tell firmware versions</a></li>
     <li><a href="https://gemini-2.com/updatefirmwaremethods.php" target="_blank">Update Gemini Firmware Methods     </a></li>
     <li><a href="https://gemini-2.com/gfu.php" target="_blank">Using the Gemini Firmware Updater Program</a></li>
     <li><a href="https://gemini-2.com/Removing_SDCards.php" target="_blank">Removing and Replacing micro-SDcards</a></li>
     <li class="slast"><a href="https://gemini-2.com/copycatalogs.php" target="_blank">Adding Catalogs to the Handcontroller</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank" title="For Gemini 2">Frequently Asked Questions</a></li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#" title="Wiring"><!--<![endif]-->Gemini-2 Documentation
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">Movies produced for this site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Front Panel Pinouts and Connection Function Discriptions
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Original Gemini-2</a></li>
       <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">Gemini-2 Mini</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Cable Wiring
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/cable_wiring.php" target="_blank" title="Both G1 and G2">Serial Port Wiring</a></li>
       <li><a href="https://gemini-2.com/serial_port_modes.php" target="_blank" title="G2 only">Serial Port Modes</a></li>
       <li><a href="https://gemini-2.com/Losmandy_Serial_Cable.php" target="_blank" title="Inside of Losmandy Serial Cable">Losmandy Serial Cable </a></li>
       <li><a href="https://gemini-2.com/handcontroller-cable-ends.php" target="_blank">Hand Controller Cable</a></li>
       <li class="slast"><a href="https://gemini-2.com/hand_controller_extender.php" target="_blank">Hand controler Extender Addon</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">Losmandy Motors</a></li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
     <li><a href="https://gemini-2.com/Gemini2_features.php" target="_blank">Gemini-2 Features</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Gemini-2 and ASCOM Driver Errors</a></li>
     <li class="slast"><a href="https://gemini-2.com/Cksum.php" target="_blank" title="Courtesy of Paul Kanevsky">Gemini Command Checksum Calculator</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/hc/index.php" target="_blank"><!--<![endif]-->G-2&nbsp;HC&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/hc/E019A.php" target="_blank">Site</a></li>
   <li><a href="https://gemini-2.com/hc/E023A.php" target="_blank">Time</a></li>
   <li><a href="https://gemini-2.com/hc/En-networkmenu_A.php" target="_blank">Network</a></li>
   <li class="slast"><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Modeling</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/web/index.php" target="_blank" title="Web Tutorial"><!--<![endif]-->G-2&nbsp;Web&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/web/web-site-time.php" target="_blank" title="Web Site Time">Site Time</a></li>
   <li><a href="https://gemini-2.com/web/web-network.php" target="_blank" title="Web Network">Network</a></li>
   <li><a href="https://gemini-2.com/web/web-battery-ports.php" target="_blank" title="battery">Battery Voltage</a></li>
   <li class="slast"><a href="https://gemini-2.com/web/web-firmware-sram.php" target="_blank" title="Firmware Sram">Firmware SRAM</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini 1"><!--<![endif]-->Gemini&nbsp;1
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/faqG1.php" target="_blank">FAQ</a></li>
   <li><a href="https://gemini-2.com/G1drivers.php" target="_blank">G1 Driver/Manuals</a></li>
   <li><a href="https://gemini-2.com/pcb-pictures.php" target="_blank">Gemini 1 Versions</a></li>
   <li><a href="https://gemini-2.com/G1-repairers.php" target="_blank">Gemini Repair Facilities/People</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Changing batteries
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">Changing CR2354</a></li>
     <li class="slast"><a href="https://gemini-2.com/videos/changing_CR2032_battery.mp4" target="_blank">Changing CR2032</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/cable_wiring.php" target="_blank">RS-232 Cable wiring</a></li>
   <li><a href="https://gemini-2.com/G1_EPROM.php" target="_blank">Eprom Programming Sources and Source Code</a></li>
   <li><a href="https://gemini-2.com/usbtoserial.php" target="_blank" title="USB to Serial Converter recomendations">USB to Serial Port converter Recommendations</a></li>
   <li><a href="http://www.docgoerlich.de/L4Features.html" target="_blank">Level 4  Features</a></li>
   <li><a href="https://gemini-2.com/Gemini-1%20mods.php" target="_blank">Recommend Mod to extend battery life</a></li>
   <li class="slast"><a href="https://gemini-2.com/2nd_Communication_Port_Cable.php" target="_blank">2nd Communication Port Cable for Gemini 1</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Windows Only"><!--<![endif]-->ASCOM/USB/GPS
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="Installing_ASCOM.php" target="_blank">Installing ASCOM</a></li>
     <li><a href="Gemini2_drivers/GeminiTelescopeInstaller(1.0.72.0).exe" target="_blank" title="Version (1.0.72.0) supports G11T &amp; G811 + all others">ASCOM-Gemini.net Installer (Version 1.0.72.0)</a></li>
     <li><a href="configuringASCOMfirsttime.php" target="_blank">Setting up ASCOM for first time</a></li>
     <li><a href="Gemini2_drivers/Gemini_Telescope_Net_Installation_and_Operation.pdf" target="_blank">Gemini ASCOM Driver manual</a></li>
     <li><a href="configuringEthernetASCOMdriver.php" target="_blank">Setup ASCOM Ethernet Interface</a></li>
     <li><a href="DCOM-FIX-EXPLAIN.php" target="_blank">DCOM_Fix</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Menu
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/select_Ascom_options.php" target="_blank">How to select the different ASCOM menus</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMSetuppage.php" target="_blank" title="Configure Telescope">Configure Telescope Menu</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMAdvancedSetuppage.php" target="_blank" title="Advanced Gemini Setting">Advanced Gemini Setting</a></li>
       <li class="slast"><a href="https://gemini-2.com/Ascom_park_menu.php" target="_blank">The Park Menu</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/theSkyX_to_Gemini.php" target="_blank">Installing Gemini.net into TheSkyX</a></li>
     <li><a href="https://gemini-2.com/getting-GPS-into-ASCOMdriver.php" target="_blank">Get GPS data into Gemini.net Driver</a></li>
     <li><a href="https://gemini-2.com/scripting_examples.php" target="_blank">Example VB scripts</a></li>
     <li class="slast"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.0.pdf" target="_blank">UPD Protol Specifications</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->USB Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/L5-USB/USB_Drivers_for_Level_5_Firmware_after_June-4-2013.zip" target="_blank">Level 5 USB Drivers for Firmware dated Jun 4 2013 and later.</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->For Firmware previous to Jun 4, 2013 USB drivers 
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_32bit_USB_driver.zip" target="_blank">USB - Windows 32 Bit-PreLevel 5</a></li>
       <li><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_64bit_USB_driver.zip" target="_blank">USB Windows 64 Bit -Pre Level5</a></li>
       <li class="slast"><a href="https://gemini-2.com/installing_usb_drivers.php" target="_blank">USB Driver installion Instructions</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/featureport-serialport.php" target="_blank">USB cable for Feature Port</a></li>
     <li class="slast"><a href="https://gemini-2.com/usb-ethernet.php" target="_blank">Alternative to USB Drivers</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Help&nbsp;Topics
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://wiki.gemini-2.com" target="_blank">Gemini 1 &amp; 2 Question and Answer WIKI</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Mount and Misc Manuals"><!--<![endif]-->Manuals
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gemini Programming
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.2.pdf" target="_blank">UDP Protocol's</a></li>
       <li><a href="https://gemini-2.com/web/L5V2_1serial.html" target="_blank">Serial Command Description</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/CGICodes/CGIcodes.pdf" target="_blank">CGI codes</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Losmandy Mounts
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/losmandygoto/Gemini-II_Quick_Start_Guide_2_23b.pdf" target="_blank">Losmandy Gemini 2 Quick Start Guide</a></li>
       <li><a href="http://www.losmandy.com/pdf/gm-8-manual.pdf" target="_blank">Losmandy G8</a></li>
       <li><a href="http://www.losmandy.com/g-11-manual.html" target="_blank">Losmandy G11</a></li>
       <li><a href="http://www.losmandy.com/pdf/titan-instructions.pdf" target="_blank">Losmandy Titan</a></li>
       <li><a href="http://www.losmandy.com/pdf/polar-finder.pdf" target="_blank">Using Losmandy Polar Finder</a></li>
       <li><a href="http://www.gemini-2.com/downloads/pdf/GeminiL4UserManual.pdf" target="_blank">G1 Level 4 Manual</a></li>
       <li><a href="http://losmandy.com/gemini_servo_motor_install.html" target="_blank">Servo Mounting Instructions</a></li>
       <li class="slast"><a href="http://helixgate.net/G11opw.html" target="_blank" title="This is from Helixgate.net by Michael A. Siniscalchi">Assembling  One Piece Worm</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mountain Instruments
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.mi250.com/downloads/MI250%20Go-To%20Manual%202007.pdf" target="_blank">MI-250 Old - 2007 </a></li>
       <li class="slast"><a href="https://www.mi250.com/downloads/MI250%20Manual%202009.pdf" target="_blank">MI-250 New - 2009</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Guiding
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD1
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.rosecityastronomers.org/resources/pdf/GuideToGuiding.pdf" target="_blank">PHD Guiding manual</a></li>
         <li class="slast"><a href="http://www.stark-labs.com/phdguiding.html" target="_blank">PHD Guiding Software</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://openphdguiding.org/" target="_blank">PHD2 Software</a></li>
         <li><a href="http://openphdguiding.org/man/index.html" target="_blank">PHD2 On-Line Manual</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Tools.htm#Guiding_Assistant" target="_blank">Guiding Assistant</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Trouble_shooting.htm" target="_blank">Trouble Shooting</a></li>
         <li class="slast"><a href="https://openphdguiding.org/man-dev/Tools.htm#Star_cross_tool" target="_blank">Star-Cross Tool</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS</a></li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">ID Losmandy motor types</a></li>
     <li class="slast"><a href="http://screenshots.portforward.com/" target="_blank" title="Screeshots of most routers">Router Screen Shots</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Trouble Shooting
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting tips</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Problems</a></li>
     <li class="slast"><a href="https://gemini-2.com/handcontroller_errors.php" target="_blank">Trouble Shooting the touch screen.</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Time Zone Tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/hc/time_zone_offset_chart.php" target="_blank">Time Zone Offset Table for USA</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/timezonefacts.php" target="_blank">Time Zone Facts</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Tips from other sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank"><!--<![endif]-->G11/Gemini Tips from Mark Crossley
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.wilmslowastro.com/index.htm" target="_blank">Mark Crossley Home page</a></li>
       <li class="slast"><a href="https://www.google.com/search?q=methods+of+doing+polar+alignment+with+EQ+scopes&sourceid=ie7&rls=com.microsoft:en-US:IE-Address&ie=&oe=" target="_blank">Precision Polar Alignment -Astro-Tom.com</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://frazmtn.com/~bwallis/GEMINI_II_docx.pdf" target="_blank">Field Manual from Brad Wallis</a></li>
     <li><a href="http://www.company7.com/library/losmandy/notes.html" target="_blank">Gemini 1 info from Company 7</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://www.michaelherman.net/#!losmandy-g11-mount" target="_blank"><!--<![endif]-->Michael Herman G11 Tips
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/Michael_Herman/RA_Extension_Spacer.pdf" target="_blank">Installing the Partridge RA Extension.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Improving_OPW.pdf" target="_blank">Improving G11 OPW.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Making_7lb_counterweight.pdf" target="_blank">7 LB Counter Weight.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Polar_Scope_Improvements.pdf" target="_blank">New Rericle in the G11 Polar scope.pdf</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/Michael_Herman/Leveling_Handles.pdf" target="_blank">Leveling handles for Clutch Knobs</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank" title="Posted here till I can find the correct link for it">Titan Tips by Bob Allevo</a></li>
     <li><a href="https://gemini-2.com/downloads/Losmandy_Titan_Reassembly.pdf" target="_blank">Titan Reassembly courtesy of Ed Wily</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=gi3-VeQn7K0" target="_blank">Cable Management U-tube</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.sharpcap.co.uk/sharpcap/polar-alignment" target="_blank" title="Polar Alignment">Polar Alignment using SharpCap</a></li>
     <li><a href="http://astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Precision Polar Alignment-Astro-Tom</a></li>
     <li><a href="http://www.astro-baby.com/simplepolar/simple_polar_alignment.htm" target="_blank">Simple Polar Alignment</a></li>
     <li><a href="http://www.themcdonalds.net/richard/index.php?title=Polar_Alignment_of_your_Equatorial_Mount" target="_blank">Polar Alignment of your Equatorial Mount</a></li>
     <li><a href="http://astropixels.com/main/polaralignment.html" target="_blank">Polar Alignment using Drift Method</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=ArU5vC1o1Jk" target="_blank">PHD2 Drift Tool Tutorial</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gearboxs and Mods
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_New_Gearbox.php" target="_blank">Losmandy's New Gearbox</a></li>
     <li><a href="https://gemini-2.com/Gearbox_mod.php" target="_blank">Repairing the gearbox used on MI-250 and G11</a></li>
     <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mclennan Gearbox upgrade
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.horizontalheavens.com/mclennan_gearbox_upgrade.htm" target="_blank">Mclennan Gearbox upgrade by Horizontal Heavens</a></li>
       <li><a href="https://gemini-2.com/Mclennan_Gearboxes.php" target="_blank">Mclennan Gearbox upgrade by Hilmi Al-Kindy</a></li>
       <li class="slast"><a href="http://www.wilmslowastro.com/tips/mclennan_gbox.html" target="_blank">Replacomg the Losmandy Gearbox by Wilmslow Astro on MI-250</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Balancing your mount
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.wilmslowastro.com/tips/g11gemini.htm#balancing" target="_blank" title="Balancing your Mount">Balancing You Mount  by wilmslowastro.com</a></li>
     <li class="slast"><a href="http://starizona.com/acb/ccd/settingupbal.aspx" target="_blank">Balancing your mount by Starizona</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Useful Programs
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment methods
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->2 Star Alignment
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.alignmaster.de" target="_blank">Using 2 Stars with AlignMaster</a></li>
         <li class="slast"><a href="http://www.sharpcap.co.uk/sharpcap" target="_blank">SharpCap for use with Alignmaster</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Polar Alignment from Astro-Tom</a></li>
       <li><a href="http://www.celestialwonders.com/articles/polaralignment/" target="_blank">Polar Alignment Star offset method</a></li>
       <li><a href="http://celestialwonders.com/articles/polaralignment/polaralignmentsurvey.html" target="_blank">Survey of Polar Alignment Methods</a></li>
       <li><a href="http://canburytech.net/DriftAlign/" target="_blank">Understanding Drift Alignment</a></li>
       <li><a href="http://eqalign.net/e_index.html" target="_blank">EQAling</a></li>
       <li><a href="http://www.petesastrophotography.com/" target="_blank">Polar Alignment by Paul Kennett</a></li>
       <li><a href="http://www.andysshotglass.com/DriftAlignment.html" target="_blank">Polar Alignment by Andy's Shot Glass</a></li>
       <li class="slast"><a href="http://www.astrosurf.com/re/polar.html" target="_blank">Polar Alignment by Astrosurf</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Observatory programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.stellarium.org/" target="_blank">Stellarium</a></li>
       <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gude Programs
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst slast"><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank">MetaGude</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.bytearts.com/stellarium/" target="_blank" title="Make Stellarium ASCOM compatible for Windows">StellariumScope</a></li>
       <li><a href="http://www.ap-i.net/skychart/" target="_blank">SkyChart / Cartes du Ciel</a></li>
       <li><a href="http://zytratechnologies.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank">Setting up Stellarium</a></li>
       <li><a href="http://sourceforge.net/p/astrotortilla/home/Home/" target="_blank">AstroTortilla Astrophotography assistant</a></li>
       <li class="slast"><a href="http://lightvortexastronomy.blogspot.com/2013/08/tutorial-imaging-setting-up-and-using.html" target="_blank">Plate Solving with Astrotortilla</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Misc Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://darkhorizons.emissionline.com/GMB/gmb.htm" target="_blank">Gemini Model Builder</a></li>
       <li><a href="http://www.nirsoft.net/utils/usb_devices_view.html" target="_blank">View USB Port assignments </a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip FIle archiver use to zip and unzip all files on this site</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Disk and Partition Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.sdcard.org/downloads/formatter_4/" target="_blank">Micro SDcard Formatter</a></li>
       <li><a href="http://www.partitionwizard.com/" target="_blank">MiniTool Partition Wizard</a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs for Windows
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://filezilla-project.org/download.php?type=client" target="_blank">FileZilla</a></li>
       <li><a href="http://www.wsftple.com/download.aspx" target="_blank">WS_FTP LE (V12)</a></li>
       <li><a href="http://www.oldversion.com/WS_FTP_Limited_Edition.html" target="_blank">WS_FTP V6</a></li>
       <li class="slast"><a href="http://winscp.net/eng/index.php" target="_blank">WinSCP</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs For Mac
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.kekaosx.com/en/" target="_blank">Keka (7zip ported to OS X)</a></li>
       <li><a href="http://www.apple.com/downloads/macosx/internet_utilities/classicftpformac.html" target="_blank">Classic FTP</a></li>
       <li><a href="http://fetchsoftworks.com/">Fetch FTP</a></li>
       <li><a href="http://www.macorchard.com/filetransfer/" target="_blank">List of Many Mac FTP</a></li>
       <li class="slast"><a href="http://blog.hostilefork.com/trashes-fseventsd-and-spotlight-v100/" target="_blank">Hidden Files A MAC puts on the SDcard</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->GPS Related programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/GPSrelated/redirect.zip" target="_blank">GPS_Port_Director (No install necessary)</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/GPSrelated/VisualGPSInstall.zip" target="_blank">Visual GPS Installer</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Network Scanners
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.softperfect.com/products/networkscanner/" target="_blank">Softperfect Network Scanner</a></li>
       <li><a href="http://www.radmin.com/products/ipscanner/" target="_blank">Advanced IP Scaner</a></li>
       <li class="slast"><a href="http://free-ip-scanner.eusing-software.qarchive.org/" target="_blank">Free IP Scanner</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li class="slast"><a href="downloads/USV_View/usbdeview.zip" target="_blank">USB View - USB port scanner</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Power Controllers
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.digital-loggers.com/ac.html" target="_blank">AC Controlled Relay</a></li>
     <li><a href="http://www.digital-loggers.com/lpc7.html" target="_blank">Web Power Switch</a></li>
     <li class="slast"><a href="http://www.digital-loggers.com/EPCR5.html" target="_blank">Ethernet Power Controller 5</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li class="tlast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Favorites
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->User Groups
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://groups.io/g/Gemini-II/" target="_blank">Gemini-II at groups.io</a></li>
     <li><a href="https://groups.io/g/Gemini_users/" target="_blank">Gemini User Group at Groups.io</a></li>
     <li><a href="https://groups.io/g/Losmandy_users/" target="_blank">Losmandy User Group at Groups.io</a></li>
     <li><a href="http://groups.yahoo.com/neo/groups/Titan_Mount/info" target="_blank">Titian User Group</a></li>
     <li><a href="https://groups.io/g/MI-250/" target="_blank">MI-250 Users Group</a></li>
     <li><a href="https://groups.io/g/Gemini_ASCOM_Driver/" target="_blank">Gemini Ascom Driver Group at Groups.io</a></li>
     <li class="slast"><a href="http://groups.yahoo.com/neo/groups/ASCOM-Talk/info" target="_blank">Ascom Talk Group</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Web Sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.docgoerlich.de/Gemini.html" target="_blank">René Görlich's Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://losmandy.com" target="_blank"><!--<![endif]-->Losmand Links -Web Site
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/eq-mounts.html" target="_blank">Equatorial Mounts</a></li>
       <li><a href="http://www.losmandy.com/secondary.html" target="_blank">D Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/v-series.html" target="_blank">Y Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/losmandygoto/gemini2.html" target="_blank">Gemini 2 Goto Syste,</a></li>
       <li><a href="http://www.losmandy.com/starlapse.html" target="_blank">StarLapse System</a></li>
       <li><a href="http://www.losmandy.com/access.html" target="_blank">Telescope Accessories</a></li>
       <li><a href="http://www.losmandy.com/replacement.html" target="_blank">Replacement parts</a></li>
       <li><a href="http://www.losmandy.com/distributors.html" target="_blank">Dealers</a></li>
       <li><a href="http://www.losmandy.com/pricelist.html" target="_blank">Price List</a></li>
       <li><a href="http://www.losmandy.com/support.html" target="_blank">Technical Support</a></li>
       <li><a href="http://store.losmandy.com/">Ordering inside USA</a></li>
       <li><a href="https://secure28.securewebsession.com/losmandy.com/order.shtml" target="_blank">Ording International or custom parts</a></li>
       <li><a href="http://www.losmandy.com/whatsnew.html" target="_blank">Whats New</a></li>
       <li class="slast"><a href="https://www.valvoline.com/en-ecuador/our-products/grease/durablend-synthetic-blend-grease" target="_blank">Recommend Grease by Losmandy</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://www.mi250.com/" target="_blank">MI-250 Web Site</a></li>
     <li><a href="https://www.arizonaskys.com" target="_blank">ArizonaSkys (my obsevatory web site - under construction</a></li>
     <li><a href="http://www.ascom-standards.org/index.htm" target="_blank">Ascom Standards Org</a></li>
     <li><a href="https://www.nightskiesnetwork.ca/" target="_blank" title=" worldwide astronomy broadcast site">Night Skys Network</a></li>
     <li><a href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank">Wilmslow Astro G11 tips</a></li>
     <li><a href="http://astronomy.tools" target="_blank">Astronomy Tools - Calculators - FOV - Star Charts</a></li>
     <li><a href="http://www.skippysky.com.au/" target="_blank">SkippySky Astro-Weather Forcast</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Tuning the G11
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.astromaster.org/esperienze_file/G11maintenance_e.htm" target="_blank">Maintain and tune a G11 mount</a></li>
       <li class="slast"><a href="http://www.astro.uni-bonn.de/~mischa/mounts/g11_tuning.html" target="_blank">Tuning a G11- for 2000 or older mounts</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://garriou.didier.free.fr/astro/gemini_anglais.html" target="_blank">Didier Garriou Gemini Catalogs building site</a></li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank">Titan Tips by Bob Allevo</a></li>
     <li><a href="http://www.stargps.ca/" target="_blank">Star GPS Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://openphdguiding.org/" target="_blank">PHD2 Home</a></li>
       <li><a href="https://code.google.com/p/open-phd-guiding/wiki/DriftAlignmentWithPHD2" target="_blank">Open-phd-guiding</a></li>
       <li><a href="https://groups.google.com/forum/#!forum/open-phd-guiding" target="_blank">Discussion Group </a></li>
       <li class="slast"><a href="https://www.youtube.com/watch?v=LXFGRta98rs" target="_blank">Introduction to optimal auto - guiding: How to get the most from your set - up</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://www.sharpcap.co.uk/" target="_blank">SharpCap</a></li>
     <li class="slast"><a href="https://sites.google.com/site/astropipp/" target="_blank">Planetary Imaging Software</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/all-links.php" target="_blank">300+ Astronomy Links</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
</ul>
 <br >
</div>

</body>




<style type="text/css">
.auto-style1 {
	font-family: serif;
	font-size: medium;
	color: #FF0000;
}
.auto-style4 {
	border: 4px solid #FF0000;
	background-color: #000000;
}
</style>


</head>

<body style="color: #FFFFFF; background-color: #000000">
<table align="center" style="width: 900px">
	<tr>
		<td class="h2">
			<br/>
				Gemini 2 Firmware Programming Methods Selection<br/>
			</td>
	</tr>
	<tr>
		<td class="h4">
			<br/>
				<u><b>Please read this whole page before doing any firmware updating.</b></u>
				
			<br />
			</td>
	</tr>
</table>
<br />

	<table align="center" style="width: 900px" class="tableborder1">
		<tr><td class="style6">&nbsp;<a href="firmware-changes.php" target="_blank">Firmware-Changes List</a> to see 
			the changes implemented 
			after Dec 18, 2012 firmware's release.&nbsp;
		</td>
		</tr>
	</table>		

<br />
<br />

<table align="center" class="auto-style4" style="width: 900px">
		<!--
		<tr><td class="style6Red">
			Do not use any of the firmware on this site to update the new 
			version of the Gemini-2 with.&nbsp; The version it is shipping with 
			is different than the versions provided on this site. Again the 
			newer version has only one power plug..&nbsp; See
			<a href="http://www.gemini-2.com/faqG2.php#Q1" target="_blank">FAQ 
			Question 1</a> for changes.
		</td>
		</tr>
		-->
		<tr>
		<td class="style6"><em>I am very pleased to announce that we now have a Gemini2 firmware updated utility 
		"GFU", (updated 8 Feb 2015) 
		courtesy of Paul Kanevsky.&nbsp; You can find the instructions to use it 
		is
		<a href="http://www.gemini-2.com/gfu.php" target="_blank">here for 
		Windows</a><!-- and <a href="gfu_mac.php">here for the Mac</a>-->.  It has been tested on XP, 
		Vista, Win7, Win8.1 and Win10.&nbsp;&nbsp; It also has been tested in a VMWare 
		Fusion window on a MacBook Pro running Win7 64bit, and A Oracle VM 
		Virtual box window with the latest beta copy of Windows 10 x64.&nbsp; 
		<!--The Mac version has been tested on a MacBook running OS 10X.&nbsp;--> You must have the Gemini-2 connected via Ethernet to use it.&nbsp; It 
		will also require an internet connection to download the latest firmware 
		from this site.<br /> Thank You Paul.</em><br />
		</td>
	</tr>
</table>
<!-- <br /><br />

<table align="center" class="auto-style4" style="width: 900px">
	<tr>
		<td class="style6"><em>All versions of the main units firmware after Dec 18, 2012 
		should only be 
		installed over the Dec 18, 2012 or later firmware versions.&nbsp; If you have 
		never updated the main unit to the Dec 18, 2012 or later version, then you 
		will have to delete a file on the micro-sdcard before you can use GFU to 
		update to the latest version.&nbsp; (instructions updated as of Dec 1, 
		2014)<br />
		Please follow these <a href="gfu_for-Dec-18-2012.php">directions</a> to do the 
		do that.&nbsp; <br />
		Now any Gemini-2 that has firmware dated in March of 2011 or earlier can 
		only be updated by removing the micro SDcards and putting the new 
		firmware on them.&nbsp; Please use the
		<a href="https://groups.io/g/Gemini-II
info" target="_blank">
		Gemini-2 users</a> group to ask how to do this.</em><br />
		</td>
	</tr>
</table> -->
<a name="updateHC"></a><br />
<!--
<table align="center" class="auto-style4" style="width: 900px">
	<tr>
		<td class="style6">
		<em>20 Feb 2014 gemhc.bin hand controller update
		</em> - download this file from <a href="http://www.gemini-2.com/firmware1/current/gemhc.zip" target="_blank">gemhc.zip</a>&nbsp; Use the instructions
				<a href="hcfirmwareupdate.php" target="_blank">here</a> to upload 
		and install it.&nbsp; It fixes a bug in the modeling routines.&nbsp;<span class="auto-style2"><b>
		IMPORTANT: Only install this file if you have the 30 Sept 2013 
		and all the new button files that support it, or later hand controller firmware installed, 
		with all the new button files.</b></span><br />
		</td>
	</tr>
</table>
-->


<br />
<table align="center" style="width: 900px">
	<tr>
		
		<td width="900px" class="style6">
		There are 4 ways to update the firmware in the Gemini 2 controller. 
		All methods require an Ethernet connection between your computer and the 
		Gemini-2. This also includes removing the micro-SDcards and programming 
		them directly.&nbsp; 
		If for no other reason, it is required to tell the Web interface to 
		flash the program into the ARM processor.&nbsp; But for the other FTP methods 
		Ethernet is also required to transfer all the files.&nbsp; If you don't have an Ethernet connection see
		<a href="ConnectingtoG2.php" target="_blank">
		http://gemini-2.com/ConnectingtoG2.php</a><br />
		All updated files are listed at the bottom of this page.&nbsp; Other 
		web pages may have them listed also, but the links at the bottom of this 
		page should be the most current.<br /><br />The four methods are:<br />
		1. Use the new <a href="http://www.gemini-2.com/gfu.php" target="_blank">Firmware Update program for Windows</a>, <!-- or the <a href="http://www.gemini-2.com/gfu_mac.php" target="_blank">Firmware Update program for Mac</a>--> that can update everything, 
		just the main unit, catalog files, or the new video files.&nbsp; This is now the recommended 
		method.&nbsp; This routine updates the Gemini-2 almost twice as fast as most of the FTP methods.<br />
		<br />
			2. <a name="The_FTP_Methods">The FTP Methods
		</a>are divided into two methods, 
		according to which FTP method you use.&nbsp; The FTP methods are for advanced users, that understand how the 
		firmware and directory structure of the micro-SDCards works, and how to 
		use a computer.&nbsp; Use a FTP 
		method to program both the Main unit and Graphics Hand controller at the 
		same time. You either use an FTP client such as
		<a href="http://download.filezilla-project.org/FileZilla_3.7.3_win32-setup.exe" target="_blank">
		Filezilla Client</a>, or Windows File Explorer. (put
		ftp://admin@Gemini or
		ftp://admin@192.168.0.111 if using Windows File Explorer.)&nbsp; 
		Note if your IP address for the Gemini-2 is different then use that.
		<br />
		Use a FTP program (Recommended when more than one file is being 
		updated, or rebuilding the main units micro-SDcard file 
				structure.) Again this is only for Advanced user that 
				understand the directory and file structure of the micro-SDcards. Only firmware dated after 9 April 
		2011 has the FTP 
				capability build in.<br />
		
		<ul>
			<!--<li>Here is a
			<a href="selfextractingdemo.php" target="_blank">
			link</a> explaining the use of the Windows File Explorer method, but with a twist. It automatically
			downloads, extracts the files to C:\gemini2, and opens up two Windows Explorer Panes for you. It will only work
			on Windows systems that has NetBios functioning.&nbsp; It has worked 
			on some XP systems, not some XP systems.</li> -->
			<li>Here is a
			<a href="updateFileExplorer.php" target="_blank">
			link</a> explaining the use of the Windows File Explorer method.
			</li>
			<li>Here is a
			<a href="installing_level5_Vesion1.php" target="_blank">
			link </a>&nbsp;explaining the use of the FTP (Filezilla client) method.</li>
		</ul>
				
		<hr class="style2" noshade="noshade" style="width: 900px" />
		<br />	
		</td>
	</tr>
</table>
	
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">
		3. Use the Web interface.&nbsp; (Recommended when gemhc.bin or 
				NewGem.bin/gemhc.bin is the only files being updated.)&nbsp; You can 
		only update one file at a time using this method.&nbsp; This 
		method requires you to use the SD Card tab of the web interface.&nbsp; 
		You use the "Upload a file to the SD card's current directory"&nbsp; If 
		uploading the NewGem.bin file you do that to the root of the SDcard.&nbsp; 
		If uploading GemHC.bin (hand controller programing file) you first 
		select the HCFirmware directory and then do the upload.&nbsp; If 
		uploading a catalog file to the hand controller you also select the 
		HCFirmware directory. If the uploaded file was NewGem.bin, then you will 
		have to go into the web interface, Firmware/SRAM tab and flash this file 
		into the ARM processor for it to do any update.<br />
		<br />
		 <hr class="auto-style1" style="width: 900px" noshade="noshade" />
		 <br />
		<br />
		4. Remove the micro-SDcards, format &amp; program them and 
				reinstall them. If your 
				Hand Controller firmware is before Jan 31,2011, and your main 
				unit firmware is before April 9 2011 then you might have to use this 
				method. After that the Update program in Paragraph 1 
				(recommended) or FTP method should work.
				It is the method you might have to use if your SDcards gets corrupted.&nbsp; 
		This is always the fall back method if something goes wrong, to try and 
		recover either the main unit or the hand controller. see
		<a href="Removing_SDCards.php" target="_blank">
		http://gemini-2.com/Removing_SDCards.php</a> <br />
		
		<br /> <span class="style2">If you have to format the SD card it is best to download the official 
				SDcard format routine from the</span>
		<a href="https://www.sdcard.org" target="_blank">https://www.sdcard.org</a>
		<span class="style2">download section.</span><br /><br />
		<hr class="auto-style1" noshade="noshade" style="width: 900px; height: 4px" /><br />
			
		NOTES:
		1. The Hand Controller is updated using a file called gemhc.bin, 
			and can be done from the main Gemini 2 unit using either the Web 
			interface or the FTP method. Putting the gemhc.bin file in a 
			subdirectory called HCFirmware will upload it to the hand controller 
			from the main Gemini 2 unit. Please note that there are now 38 (as of 
		August 2013) button files that also have to be uploaded to update the 
		Hand controller.&nbsp; Please note that the Gemini MUST BE THROUGH 
			THE BOOT MENU for this to work. Also any catalog (.GUC file) can be 
			uploaded to the hand controller the same way.<br /><br />
		2. The Main Gemini unit's 
		ARM processor is updated using a file called NewGem.bin. But there are 
		many files in up to 30 sub-directories, that support it.&nbsp; Not all 
		have to be present, but the EN directory is a must for the English 
		language.&nbsp; The Gemini-2 creates some of these directories itself, 
		such as LOGS, CONFIG, PEC, and MODELS.<br /><br />
		
		3.	Both micro-SDcards (the one in the Hand Controller, and the one 
			in the Main Gemini 2) also contain many other files.&nbsp; These 
			other files can be put on the 
			
			Main Gemini 2 unit with a 
				FTP program, or
				one at a time with the web interface, or
				by removing the 
			card and putting the files on it with a card reader/writer, and the reinstalling 
			the card. There are 2 ways to do this with the Hand Controller files, 
				
					use a card reader/writer 
			on the micro-SDcard in the Hand controller, or 
					put the files in the HCFirmware directory of the main micro-SDcard directory.  This is normally a one time thing, 
			as most of the files on the Hand Controller mini-SDcard are the Star 
			Catalogs and button files which seldom change if ever. <br /><br />

<!--
			<hr class="auto-style2" style="width: 900px" noshade="noshade" /><br />
		

		Note that normally 
		the below available files are to do updates 
			with. They are supplied in Zip format&nbsp; and will need to be unzipped:&nbsp; 
		The combined.zip file contains all the other files listed below and is in the proper 
		Directory/File Structure for the main units micro SDcard.&nbsp; It will 
		update both the main unit and hand controller files except the Catalogs 
		of the Hand Controller.&nbsp; GFU can be used to install most of the 
		below files.&nbsp; <br />
		<br />
		</td>
	</tr>
</table>
		
<table align="CENTER" style="width: 900px">
	<tr>
		<td class="style6">
			<br />
			<hr class="style2" noshade="noshade" style="height: 4px" />
			<ul>
				<li><a href="http://www.gemini-2.com/firmware1/current/combined.zip" target="_blank">Combined.zip</a> file contains the NewGem.bin file, the contents of SDcard.zip
				to update the main unit and gemhc.bin for updating the hand controller, and the 
				HC_SDCard_upload.zip files for updating&nbsp; hand controller.&nbsp; 
				All current 
				updates are in this file.&nbsp; This is the default file that GFU will look for and install.<br /> 
				<br /></li><li>
				<a href="http://www.gemini-2.com/firmware1/current/V5-2_Individual_zips/NewGem.zip" target="_blank">NewGem.bin</a> - programming file for Main unit. 
					Only programs the arm processor. Note: it's download format 
					is a zip file and it must be unzipped before use.&nbsp; Do 
				not use GFU for this file.<br /><br /> </li>
				<li>
				<a href="http://www.gemini-2.com/firmware1/current/V5-2_Individual_zips/SDcard.zip" target="_blank">SDcard.zip</a> - this is the rest of the files on the main 
					units micro-SDcard, and is necessary for proper operation.&nbsp;&nbsp; 
				You can use GFU for this file, uncheck Flash, uncheck HC, 
				uncheck catalogs. They do not include the hand controller files.<br /><br /></li>
				<li>
				<a href="http://www.gemini-2.com/firmware1/current/V5-2_Individual_zips/gemhc.zip" target="_blank">gemhc.bin</a> - hand controller programming file.&nbsp; 
				This only programs the arm processor in the hand controller.&nbsp; 
				Note: it's download format is a zip file and it must be unzipped 
				before use. Use the instructions
				<a href="hcfirmwareupdate.php" target="_blank">here</a> to upload 
				and install it.&nbsp; Do not use GFU to install this file.&nbsp; <br /><br /> </li>
				
								
				<li>
				<a href="http://www.gemini-2.com/firmware1/current/V5-2_Individual_zips/HC-reader-writer_version.zip" target="_blank">HC-reader-writer_version.zip</a> - 
				All the hand controller files for the 14 Feb 2016 firmware.&nbsp; The directory structure of this 
				zip file is formatted for using it with a micro-SDcard card 
				reader/writer only.&nbsp;It must not be used in the main unit. It 
				DOES&nbsp; 
				include the gemhc.bin file.&nbsp; It also includes the catalogs 
				files. Do not use GFU with this file. 
				You should also format the micro SDcard with the 
				<a href="https://www.sdcard.org/downloads/formatter_4/" target="_blank">
				Official SDcard 
				format utility</a> from the SD Association.&nbsp;&nbsp; <br /><br /></li>
				<li>
				<a href="http://www.gemini-2.com/firmware1/current/V5-2_Individual_zips/HC_SDcard_upload.zip" target="_blank">HC_SDcard_upload.zip</a> - these are the same files that 
					are in the HC_SDcard.zip file.&nbsp; They are in&nbsp; 
					in one directory, and the contents would be put in the HCFirmware directory on the main unit using an FTP 
					program or card reader/writer.&nbsp; Then the Hand 
					controller can be commanded to upload these files. It DOES 
					NOT include the gemhc.bin file, or the Catalog Files for the 
					hand controller. Do not use GFU for this file.<br /><br /></li>
				
					<li>
					<a href="http://www.gemini-2.com/firmware1/current/catalogs.zip" target="_blank">Catalogs.zip</a> - these are the catalogs files for upload 
					to the Hand controller.&nbsp; Catalogs files are stored in a 
					separate process to the hand controller.&nbsp; They can be 
					directly written to the mico-SDcard in the hand controller 
					using a card reader/writer, or they can be put into the 
					HCFirmware directory of the micro-SDcard in the main unit.&nbsp; 
					The main unit will then upload them to the hand controller.&nbsp; 
					You can also see
					<a href="http://gemini-2.com/copycatalogs.php" target="_blank">
					adding catalogs to the hand controller</a> for a different 
					method of doing this. You can use GFU for this file.&nbsp; 
					Check HC and Catalogs, uncheck Gemini and Flash.<br /><br /></li>
					<!--<li>
					<a href="http://www.gemini-2.com/firmware1/current/Manual.zip" target="_blank">
					Manuals.zip</a> - these are extracted from the Gemini-2.com web site. 
					They can only be displayed in a Web browser that is on the same 
					network as the Gemini-2.&nbsp; If you have a laptop or 
					tablet 
					connected to the Gemini-2 then you can see them in it's web 
					browser.&nbsp; They are there mainly for ones who go into 
					the field and have no web connectivity. The directory for 
					these manuals is "Manual" and is placed at the root of the 
					micro-SDcard in the main unit.&nbsp; They are part of the 
					combined.zip file so normally do not need to be downloaded 
					as a separate item.&nbsp; The Manual directory is the 
					largest directory approaching almost 14 megabytes of 
					directories and files. This directory takes about a half 
					hour or more to upload using a FTP process into the 
					Gemini-2. If you don't need them, then I suggest you delete 
					this directory from the Combined.zip files after unzipping 
					it.&nbsp; It will save you allot of time.&nbsp; If you are 
					using a card reader/writer, then the size really does not 
					matter, so leave them in place.&nbsp; The choice is yours.&nbsp; 
					GFU can be used to upload these files.&nbsp; Uncheck HC, 
					Catalogs and Flash, Check Gemini.<br /><br /></li> -->
					<!--<li>PAA Tutorial.pdf file have now been added into the Main SDcard 
					it is contained in the combined.zip file.&nbsp; <br /><br /></li>-->
					
<!--						<li><a href="firmware1/current/MHC.zip" target="_blank">
						MHC</a> Directory - which stood for Mobile hand 
						controller.&nbsp; This was removed at Scott Losmandy 
						request. It can be very slow when trying to bring in 
						some of the larger star catalog files.&nbsp; You really 
						need a fast WiFi device to use this.&nbsp; It was wrote by a 
						third party, who has since left the Losmandy family of 
						mounts to design&nbsp; his own.&nbsp; This file contains 
						2 directories. MHC and EN. The EN directory only 
						contains a index.htm file to update the English version 
						of the web interface so that the MHC files can be found.&nbsp; 
						If you decide to use this, you need to overwrite the EN 
						directory with this one and add the MHC directory to the 
						other.&nbsp; This firmware will not be in any of the 
						other files, and is not being keep updated to work with 
						new changes in firmware.&nbsp; That is the reason for 
						it's removal. This file can easily be put into the 
						Gemini-2 using GFU.&nbsp; In the drop down box, point 
						GFU to download
						<a href="http://www.gemini-2.com/firmware1/current/MHC.zip">
						http://www.gemini-2.com/firmware1/current/MHC.zip</a> 
						Make sure you <u>uncheck</u> HC, Catalogs and Flash. The GFU 
						will time out if you do not.<br /><br /></li>
					</ul>
-->
				
			</td>
		</tr>
</table>

<hr class="style2" noshade="noshade" style="width: 900px; height: 4px" />

<table align="CENTER" style="width: 900px">
	<tr>
		<td class="style7">
		Below is the Directory and file structure of the 
		Main Gemini-2 micro SDcard.</td>
		</tr>
</table>
<table align="CENTER" style="width: 900px">
	<tr>
		<td class="style6">
			<ul>
				<li>
				<u><strong>AltAZ</strong></u>&nbsp; - 
				Directory - These is for Alt AZ mounts and contains 4 subdirectoried</li>
				<li>
				<u><strong>Catalogs</strong></u> - Directory contains all the star catalogs in *.Guc 
				format. Currently there are 20 catalogs.</li>
				<li>
				<u><strong>CONFIG</strong></u> - 
				Directory - if you tell the Gemini to store your configuration 
				using the web interface (Store SRAM) then it will be stored in 
				this directory.</li>
				<li>
				<u><strong>DE</strong></u> - Directory 
				- this is the German director and contains 40 files</li>
				<li>
				<u><strong>DOC</strong></u> - 
				Directory - this directory contains the PAA_Tutorial in PDF 
				format.</li>
				<li>
				<u><strong>EN</strong></u> - Directory 
				- This is the English directory and contains 44 files</li>
				<li>
				<u><strong>ES</strong></u> - Directory 
				- This is the Spanish directory and contains 39 files</li>
				<li>
				<u><strong>FR</strong></u> - Directory 
				- this is the French directory and contains 40 files</li>
				<li>
				<u><strong>HC</strong></u> - Directory - this directory contains the hand controller on the web 
				interface - 7 files</li>
				<li>
				<u><strong>HCFirmware</strong></u> - 
				Directory - this directory is normally empty, and only contains 
				files when they need to be uploaded to the hand controller.</li>
				<li>
				<u><strong>MHC</strong> </u>-Directory - which stood for Mobile hand controller.&nbsp;&nbsp; It can be very slow 
				when trying to bring in some of the larger star catalog files.&nbsp; 
				You really need a fast WiFi device to use this. It is designed 
				to work with Android phones/tablets and Iphones and Ipads.</li>
				<li>
				<u><strong>Logs</strong></u> - 
				Directory - this directory is created only by the Gemini-2 and 
				normally only contains the Gemini.log, Pointing.Dat files. If 
				you have created a model, then a model.log will be here also.</li>
				<li>
				<u><strong>Manual</strong></u> - Directory - directory, Please see above description about this 
				directory.</li>
				<li>
				<u><strong>Models</strong></u> - Directory - If you tell the Gemini to store your model using the 
				web interface it will be stored here.</li>
				<li>
				<u><strong>PEC</strong></u> - 
				Directory - if you create a PEC file then it will be stored in 
				this directory.</li>
				<li>
				<u><strong>NewGem.bin</strong></u> - File -this file is the programming file for the 
				Gemini-2 Main ARM processor.</li>
			</ul>
		</td>
		</tr>
</table>
<br />
<hr class="style2" noshade="noshade" style="width: 900px; height: 4px" />
<br />
<table align="CENTER" style="width: 900px">
	<tr>
		<td class="style7">
		Below is the Directory and file structure of the 
		Hand Controller micro SDcard.</td>
		</tr>
</table>
<table align="CENTER" style="width: 900px">
	<tr>
		<td class="stylet">
			<ul>
				<li>
				<u><strong>Catalogs</strong></u> - 
				Directory contains all the star catalogs in *.Guc 
				format. Currently there are 20 catalogs.</li>
				<li>
				<u><strong>HCFirmware</strong></u> - Directory - it is where all the button files&nbsp; 
				and the gemlogo.bin are 
				loaded.&nbsp; </li>
				<li>
				<u><strong>GemHC.bin</strong></u> - file that will be uploaded into the hand controllers 
				ARM processor to program it. After it is programmed, the ARM 
				processor will rename it to current.bin, so it is not programmed 
				again.</li>
				
			</ul>
		</td>
		</tr>
</table>
<table  align="center" style="width:900px">
	<tr>
		<td class="style7">
		Page last updated on Sept 07 , 2016
		</td>
	</tr>
</table>


</body>




<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>


<head>
<title>Bottom page</title>
<link href="/gemini-2.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/ajxmenu_bottom.css" type="text/css">


</head>

<body style="color: #FFFFFF; background-color: #000000" >
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">This site is not for profit 
		and sells nothing and asks for no money for any help it provides.&nbsp; This 
		site is 
		here to help fellow Gemini-2 and Gemini-1 owners. This Web Site is not 
		associated with Losmandy-Hollywood General Machining Inc. or any of 
		their employees and never has been. There is no guarantee that all the 
		information is correct, but strives to provide the best information 
		possible. The use of any information is at your own risk.&nbsp; The webmaster 
		is an unpaid beta tester, and tries to work with other beta testers, and 
		René the writer of the firmware.&nbsp;
		If you would like to help keep this web site going send your gift to <a href="http://paypal.me/geminitwo">paypal.me/geminitwo</a> 
		Your gift will be used to defray the cost of keeping this web site up, unless you specify otherwise.</span></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">
		I have tried many times to make a PDF of this site with no luck. Every program
		to do this screws up the links and images. I am not going to write a manual either.
		I developed this web site for my own use in the beginning, but it soon went public.</span></td>
	</tr>
</table>

	<table align="center" style="width: 900px">
		<tr>
			<td>
<div class="AJXMenuSPDSMNA"><!-- AJXFILE:ajxmenu_bottom.css -->
 <div class="ajxmw1">
  <div class="ajxmw2">
<ul>
 <li class="tfirst tlast"><a href="https://www.gemini-2.com/" target="_self">HOME</a></li>
</ul>
  </div>
 </div>
 <br >
</div>
</td>
</tr>
</table>

<!--
<table align="center"style="width: 50px">
	<tr>
	<td class="style6">Hit counter by<a href="http://digits.net"> http://digits.net</a></td>
	
	
	<td class="style6R" width="45%">
  <a href="http://www.digits.net" target="_blank">
    <img src="https://counter.digits.net/?counter={921ba194-f2d6-95c4-2981-2437d185efba}&template=simple" 
     alt="Hit Counter by Digits" border="0"  />
  </a>
  </td>
  </tr>
</table>
-->
&nbsp;<table align="center" cellpadding="4" cellspacing="4" style="width: 70%">
	<tr class="style6">
		<td class="style1">Your Privacy Policy
<br>No Information is collected by this site.&nbsp; Cookies are set in your browser, 
but only for visited<br/>links to change color.
</td>
	</tr>
	<tr class="style6">
		<td class="style13"><b>Your use of any information on this site is at your own risk.</b></td>
	</tr>
</table>
		
	<p class="style7" align="center"><!--webbot bot="HTMLMarkup" startspan --><script language=javascript>

	  <!--
	  var contact = "Thomas Hilton"
	  var email = "tomh"
	  var emailHost = "gemini-2.com"
	  document.write("copyright&copy; - 2017-2011 -<a href=" + "mail" + "to:" + email + "@" + emailHost+ ">" + contact + "</a>" )
	 //-->
	</script><!--webbot bot="HTMLMarkup" endspan -->
	and <a href="Https://www.Gemini-2.com">https://www.gemini-2.com</a>
	<br />Gemini-2 and Gemini is a registered trade names of Hollywood General Machining Inc.</p>

	
</body>




