<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Troubling Gemini-2 Problems</title>



<!DOCTYPE html 
      PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<link rel="stylesheet" href="https://gemini-2.com/ajxmenu.css" type="text/css">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta content="en-us" http-equiv="Content-Language" />
<title>Gemini 2 Mount Controller</title>

<link href="https://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css">
<style type="text/css">
a {
	color: #FF0000;
}
</style>


</head>
<body>
<table align="center" style="width: 900px">
	<tr><td align="center">
	<span class="h1">
		Gemini-2 and Gemini-1 Telescope Mount Controllers</span> <br />
		<span class="h2">Website and Tutorials </span>
		</td>
	</tr>
</table>


<table align="center" style="width: 900px">
	<tr>
		<td align="center">
<form action="https://www.google.com/search" method="get"> <div style="border:1px solid black;padding:4px;width:20em;"> <table align="center" border="0" cellpadding="0"> 
<tbody> 
<tr><td> <input maxlength="255" name="q" size="25" type="text" value="" /> <input type="submit" value="Google Search" /></td></tr> 
<tr><td align="center" style="font-size:75%"> <input checked="" name="sitesearch" type="checkbox" value="gemini-2.com" />
 only search Gemini-2.com<br /> </td></tr></tbody></table> </div> </form>
		
		</td>
	</tr>
</table>
<!--
<table align="center" style="width: 900px">
	<tr>
		<td class="style7" >
		There is a new <a href="http://wiki.gemini-2.com" target="_blank">Question and Answer Wiki</a> section where you can ask searchable questions.  		
		</td>
	</tr>
</table>
-->

<table align="center" style="width: 900px">
	<tr>
		<td align="center">
		</td>
	</tr>
</table>

<div class="AJXMenueDFaTFD"><!-- AJXFILE:ajxmenu.css -->
<ul>
 <li class="tfirst"><!--[if IE]><!--><a class="ajxsub" href="index.php" target="_self"><!--<![endif]-->Home/Start&nbsp;Here
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/Getting_started.php" target="_blank">1 - New Users Start Here</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/front_panel_pinouts.php" target="_blank"><!--<![endif]-->2.- Front Panel Pinouts
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Orginal Gemini-2 Version</a></li>
     <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">New Gemini-2 Mini</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/definitions.php" target="_blank">3 - Definitions</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->4.- Tutorials
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/quickstart/index.php" target="_blank">4.1 Quick Start &amp; Screen Alignment</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">4.2  Hand Controller</a></li>
     <li class="slast"><a href="https://gemini-2.com/alt-alignment.php" target="_blank" title="Manual method for adding a star to models.">4.3  Add a star to a model</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->5 - Videos
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_Videos.php" target="_blank">5a - Videos by Scott Losmandy on YouTube</a></li>
     <li class="slast"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">5b - Gemini.com  Videos</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->6 - Connecting Gemini-2 to Computer
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/connecting_Gemini_to_computers.php" target="_blank">6a- Connecting Gemini-2 to a computer</a></li>
     <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">6b-Using ASCOM with windows</a></li>
     <li class="slast"><a href="https://gemini-2.com/faqGII.php#Q3" target="_blank">6c - Multiple Gemini-2 on network</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/G2_Verse_G1-Modeling.php" target="_blank">7 - G2 Verse G1 modeling</a></li>
   <li><a href="https://gemini-2.com/web/index.php" target="_blank">8 - Web Interface Pages</a></li>
   <li><a href="https://gemini-2.com/limits.php" target="_blank">9 - Setting Limits - Very Important</a></li>
   <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">10 - Installing Gemini.net ASCOM driver</a></li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank">11 - FAQ about Gemini-2</a></li>
   <li><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">12 - Firmware versions and updating.</a></li>
   <li><a href="https://gemini-2.com/Simple_Rules_Gemini_Uses.php" target="_blank">13 - Rules that Gemini-2 follows:</a></li>
   <li class="slast"><a href="https://www.gemini-2.com/credits.php" target="_blank">13 - A little history</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini-2"><!--<![endif]-->Gemini&nbsp;2&nbsp;&nbsp;&nbsp;&nbsp;
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting Tips</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Start here for Gemini 2"><!--<![endif]-->Using the Gemini 2 controller
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/definitions.php" target="_blank">Definitions</a></li>
     <li><a href="https://gemini-2.com/alignment_procedure.php" target="_blank">Initial Alignment and Startup</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">Navigating Hand Controller Menus</a></li>
     <li><a href="https://gemini-2.com/web/index.php" target="_blank">Navigating the Internal Web Pages</a></li>
     <li><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Semi-Automatic Alignment Method</a></li>
     <li><a href="https://gemini-2.com/limits.php" target="_blank">Setting Limit switch drawing</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/E026.php" target="_blank" title="Will help you polar align the mount">Polar Axis Assist</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Connect G2 to Ethernet"><!--<![endif]-->Connectiong to Ethernet Port
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/ConnectingtoG2.php" target="_blank" title="connecting to web interface">Connecting to Ethernet Port</a></li>
     <li><a href="https://gemini-2.com/crossovernetwork.php" target="_blank" title="G2 directly to Computer">Configuring Win 10, Win7 &amp; XP for Static IP</a></li>
     <li><a href="https://gemini-2.com/Enabling_netbios.php" target="_blank">Enabling NetBios on Windows Networks</a></li>
     <li><a href="https://gemini-2.com/travel_routers.php" target="_blank">Adding WiFi to Gemini-2</a></li>
     <li><a href="https://gemini-2.com/ethernet_connections.php" target="_blank">Ethernet Connection methods/drawings</a></li>
     <li><a href="https://gemini-2.com/configuringEthernetASCOMdriver.php" target="_blank">Configuring The ASCOM Driver's Ethernet connection</a></li>
     <li class="slast"><a href="https://gemini-2.com/network-places.php" target="_blank">Adding the Gemini-2 to FTP network places</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank" title="5 ways to update firmware"><!--<![endif]-->Updating Gemini FIrmware
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">How to tell firmware versions</a></li>
     <li><a href="https://gemini-2.com/updatefirmwaremethods.php" target="_blank">Update Gemini Firmware Methods     </a></li>
     <li><a href="https://gemini-2.com/gfu.php" target="_blank">Using the Gemini Firmware Updater Program</a></li>
     <li><a href="https://gemini-2.com/Removing_SDCards.php" target="_blank">Removing and Replacing micro-SDcards</a></li>
     <li class="slast"><a href="https://gemini-2.com/copycatalogs.php" target="_blank">Adding Catalogs to the Handcontroller</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank" title="For Gemini 2">Frequently Asked Questions</a></li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#" title="Wiring"><!--<![endif]-->Gemini-2 Documentation
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">Movies produced for this site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Front Panel Pinouts and Connection Function Discriptions
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Original Gemini-2</a></li>
       <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">Gemini-2 Mini</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Cable Wiring
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/cable_wiring.php" target="_blank" title="Both G1 and G2">Serial Port Wiring</a></li>
       <li><a href="https://gemini-2.com/serial_port_modes.php" target="_blank" title="G2 only">Serial Port Modes</a></li>
       <li><a href="https://gemini-2.com/Losmandy_Serial_Cable.php" target="_blank" title="Inside of Losmandy Serial Cable">Losmandy Serial Cable </a></li>
       <li><a href="https://gemini-2.com/handcontroller-cable-ends.php" target="_blank">Hand Controller Cable</a></li>
       <li class="slast"><a href="https://gemini-2.com/hand_controller_extender.php" target="_blank">Hand controler Extender Addon</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">Losmandy Motors</a></li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
     <li><a href="https://gemini-2.com/Gemini2_features.php" target="_blank">Gemini-2 Features</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Gemini-2 and ASCOM Driver Errors</a></li>
     <li class="slast"><a href="https://gemini-2.com/Cksum.php" target="_blank" title="Courtesy of Paul Kanevsky">Gemini Command Checksum Calculator</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/hc/index.php" target="_blank"><!--<![endif]-->G-2&nbsp;HC&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/hc/E019A.php" target="_blank">Site</a></li>
   <li><a href="https://gemini-2.com/hc/E023A.php" target="_blank">Time</a></li>
   <li><a href="https://gemini-2.com/hc/En-networkmenu_A.php" target="_blank">Network</a></li>
   <li class="slast"><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Modeling</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/web/index.php" target="_blank" title="Web Tutorial"><!--<![endif]-->G-2&nbsp;Web&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/web/web-site-time.php" target="_blank" title="Web Site Time">Site Time</a></li>
   <li><a href="https://gemini-2.com/web/web-network.php" target="_blank" title="Web Network">Network</a></li>
   <li><a href="https://gemini-2.com/web/web-battery-ports.php" target="_blank" title="battery">Battery Voltage</a></li>
   <li class="slast"><a href="https://gemini-2.com/web/web-firmware-sram.php" target="_blank" title="Firmware Sram">Firmware SRAM</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini 1"><!--<![endif]-->Gemini&nbsp;1
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/faqG1.php" target="_blank">FAQ</a></li>
   <li><a href="https://gemini-2.com/G1drivers.php" target="_blank">G1 Driver/Manuals</a></li>
   <li><a href="https://gemini-2.com/pcb-pictures.php" target="_blank">Gemini 1 Versions</a></li>
   <li><a href="https://gemini-2.com/G1-repairers.php" target="_blank">Gemini Repair Facilities/People</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Changing batteries
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">Changing CR2354</a></li>
     <li class="slast"><a href="https://gemini-2.com/videos/changing_CR2032_battery.mp4" target="_blank">Changing CR2032</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/cable_wiring.php" target="_blank">RS-232 Cable wiring</a></li>
   <li><a href="https://gemini-2.com/G1_EPROM.php" target="_blank">Eprom Programming Sources and Source Code</a></li>
   <li><a href="https://gemini-2.com/usbtoserial.php" target="_blank" title="USB to Serial Converter recomendations">USB to Serial Port converter Recommendations</a></li>
   <li><a href="http://www.docgoerlich.de/L4Features.html" target="_blank">Level 4  Features</a></li>
   <li><a href="https://gemini-2.com/Gemini-1%20mods.php" target="_blank">Recommend Mod to extend battery life</a></li>
   <li class="slast"><a href="https://gemini-2.com/2nd_Communication_Port_Cable.php" target="_blank">2nd Communication Port Cable for Gemini 1</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Windows Only"><!--<![endif]-->ASCOM/USB/GPS
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="Installing_ASCOM.php" target="_blank">Installing ASCOM</a></li>
     <li><a href="Gemini2_drivers/GeminiTelescopeInstaller(1.0.72.0).exe" target="_blank" title="Version (1.0.72.0) supports G11T &amp; G811 + all others">ASCOM-Gemini.net Installer (Version 1.0.72.0)</a></li>
     <li><a href="configuringASCOMfirsttime.php" target="_blank">Setting up ASCOM for first time</a></li>
     <li><a href="Gemini2_drivers/Gemini_Telescope_Net_Installation_and_Operation.pdf" target="_blank">Gemini ASCOM Driver manual</a></li>
     <li><a href="configuringEthernetASCOMdriver.php" target="_blank">Setup ASCOM Ethernet Interface</a></li>
     <li><a href="DCOM-FIX-EXPLAIN.php" target="_blank">DCOM_Fix</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Menu
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/select_Ascom_options.php" target="_blank">How to select the different ASCOM menus</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMSetuppage.php" target="_blank" title="Configure Telescope">Configure Telescope Menu</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMAdvancedSetuppage.php" target="_blank" title="Advanced Gemini Setting">Advanced Gemini Setting</a></li>
       <li class="slast"><a href="https://gemini-2.com/Ascom_park_menu.php" target="_blank">The Park Menu</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/theSkyX_to_Gemini.php" target="_blank">Installing Gemini.net into TheSkyX</a></li>
     <li><a href="https://gemini-2.com/getting-GPS-into-ASCOMdriver.php" target="_blank">Get GPS data into Gemini.net Driver</a></li>
     <li><a href="https://gemini-2.com/scripting_examples.php" target="_blank">Example VB scripts</a></li>
     <li class="slast"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.0.pdf" target="_blank">UPD Protol Specifications</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->USB Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/L5-USB/USB_Drivers_for_Level_5_Firmware_after_June-4-2013.zip" target="_blank">Level 5 USB Drivers for Firmware dated Jun 4 2013 and later.</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->For Firmware previous to Jun 4, 2013 USB drivers 
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_32bit_USB_driver.zip" target="_blank">USB - Windows 32 Bit-PreLevel 5</a></li>
       <li><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_64bit_USB_driver.zip" target="_blank">USB Windows 64 Bit -Pre Level5</a></li>
       <li class="slast"><a href="https://gemini-2.com/installing_usb_drivers.php" target="_blank">USB Driver installion Instructions</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/featureport-serialport.php" target="_blank">USB cable for Feature Port</a></li>
     <li class="slast"><a href="https://gemini-2.com/usb-ethernet.php" target="_blank">Alternative to USB Drivers</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Help&nbsp;Topics
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://wiki.gemini-2.com" target="_blank">Gemini 1 &amp; 2 Question and Answer WIKI</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Mount and Misc Manuals"><!--<![endif]-->Manuals
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gemini Programming
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.2.pdf" target="_blank">UDP Protocol's</a></li>
       <li><a href="https://gemini-2.com/web/L5V2_1serial.html" target="_blank">Serial Command Description</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/CGICodes/CGIcodes.pdf" target="_blank">CGI codes</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Losmandy Mounts
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/losmandygoto/Gemini-II_Quick_Start_Guide_2_23b.pdf" target="_blank">Losmandy Gemini 2 Quick Start Guide</a></li>
       <li><a href="http://www.losmandy.com/pdf/gm-8-manual.pdf" target="_blank">Losmandy G8</a></li>
       <li><a href="http://www.losmandy.com/g-11-manual.html" target="_blank">Losmandy G11</a></li>
       <li><a href="http://www.losmandy.com/pdf/titan-instructions.pdf" target="_blank">Losmandy Titan</a></li>
       <li><a href="http://www.losmandy.com/pdf/polar-finder.pdf" target="_blank">Using Losmandy Polar Finder</a></li>
       <li><a href="http://www.gemini-2.com/downloads/pdf/GeminiL4UserManual.pdf" target="_blank">G1 Level 4 Manual</a></li>
       <li><a href="http://losmandy.com/gemini_servo_motor_install.html" target="_blank">Servo Mounting Instructions</a></li>
       <li class="slast"><a href="http://helixgate.net/G11opw.html" target="_blank" title="This is from Helixgate.net by Michael A. Siniscalchi">Assembling  One Piece Worm</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mountain Instruments
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.mi250.com/downloads/MI250%20Go-To%20Manual%202007.pdf" target="_blank">MI-250 Old - 2007 </a></li>
       <li class="slast"><a href="https://www.mi250.com/downloads/MI250%20Manual%202009.pdf" target="_blank">MI-250 New - 2009</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Guiding
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD1
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.rosecityastronomers.org/resources/pdf/GuideToGuiding.pdf" target="_blank">PHD Guiding manual</a></li>
         <li class="slast"><a href="http://www.stark-labs.com/phdguiding.html" target="_blank">PHD Guiding Software</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://openphdguiding.org/" target="_blank">PHD2 Software</a></li>
         <li><a href="http://openphdguiding.org/man/index.html" target="_blank">PHD2 On-Line Manual</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Tools.htm#Guiding_Assistant" target="_blank">Guiding Assistant</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Trouble_shooting.htm" target="_blank">Trouble Shooting</a></li>
         <li class="slast"><a href="https://openphdguiding.org/man-dev/Tools.htm#Star_cross_tool" target="_blank">Star-Cross Tool</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS</a></li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">ID Losmandy motor types</a></li>
     <li class="slast"><a href="http://screenshots.portforward.com/" target="_blank" title="Screeshots of most routers">Router Screen Shots</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Trouble Shooting
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting tips</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Problems</a></li>
     <li class="slast"><a href="https://gemini-2.com/handcontroller_errors.php" target="_blank">Trouble Shooting the touch screen.</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Time Zone Tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/hc/time_zone_offset_chart.php" target="_blank">Time Zone Offset Table for USA</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/timezonefacts.php" target="_blank">Time Zone Facts</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Tips from other sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank"><!--<![endif]-->G11/Gemini Tips from Mark Crossley
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.wilmslowastro.com/index.htm" target="_blank">Mark Crossley Home page</a></li>
       <li class="slast"><a href="https://www.google.com/search?q=methods+of+doing+polar+alignment+with+EQ+scopes&sourceid=ie7&rls=com.microsoft:en-US:IE-Address&ie=&oe=" target="_blank">Precision Polar Alignment -Astro-Tom.com</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://frazmtn.com/~bwallis/GEMINI_II_docx.pdf" target="_blank">Field Manual from Brad Wallis</a></li>
     <li><a href="http://www.company7.com/library/losmandy/notes.html" target="_blank">Gemini 1 info from Company 7</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://www.michaelherman.net/#!losmandy-g11-mount" target="_blank"><!--<![endif]-->Michael Herman G11 Tips
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/Michael_Herman/RA_Extension_Spacer.pdf" target="_blank">Installing the Partridge RA Extension.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Improving_OPW.pdf" target="_blank">Improving G11 OPW.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Making_7lb_counterweight.pdf" target="_blank">7 LB Counter Weight.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Polar_Scope_Improvements.pdf" target="_blank">New Rericle in the G11 Polar scope.pdf</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/Michael_Herman/Leveling_Handles.pdf" target="_blank">Leveling handles for Clutch Knobs</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank" title="Posted here till I can find the correct link for it">Titan Tips by Bob Allevo</a></li>
     <li><a href="https://gemini-2.com/downloads/Losmandy_Titan_Reassembly.pdf" target="_blank">Titan Reassembly courtesy of Ed Wily</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=gi3-VeQn7K0" target="_blank">Cable Management U-tube</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.sharpcap.co.uk/sharpcap/polar-alignment" target="_blank" title="Polar Alignment">Polar Alignment using SharpCap</a></li>
     <li><a href="http://astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Precision Polar Alignment-Astro-Tom</a></li>
     <li><a href="http://www.astro-baby.com/simplepolar/simple_polar_alignment.htm" target="_blank">Simple Polar Alignment</a></li>
     <li><a href="http://www.themcdonalds.net/richard/index.php?title=Polar_Alignment_of_your_Equatorial_Mount" target="_blank">Polar Alignment of your Equatorial Mount</a></li>
     <li><a href="http://astropixels.com/main/polaralignment.html" target="_blank">Polar Alignment using Drift Method</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=ArU5vC1o1Jk" target="_blank">PHD2 Drift Tool Tutorial</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gearboxs and Mods
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_New_Gearbox.php" target="_blank">Losmandy's New Gearbox</a></li>
     <li><a href="https://gemini-2.com/Gearbox_mod.php" target="_blank">Repairing the gearbox used on MI-250 and G11</a></li>
     <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mclennan Gearbox upgrade
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.horizontalheavens.com/mclennan_gearbox_upgrade.htm" target="_blank">Mclennan Gearbox upgrade by Horizontal Heavens</a></li>
       <li><a href="https://gemini-2.com/Mclennan_Gearboxes.php" target="_blank">Mclennan Gearbox upgrade by Hilmi Al-Kindy</a></li>
       <li class="slast"><a href="http://www.wilmslowastro.com/tips/mclennan_gbox.html" target="_blank">Replacomg the Losmandy Gearbox by Wilmslow Astro on MI-250</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Balancing your mount
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.wilmslowastro.com/tips/g11gemini.htm#balancing" target="_blank" title="Balancing your Mount">Balancing You Mount  by wilmslowastro.com</a></li>
     <li class="slast"><a href="http://starizona.com/acb/ccd/settingupbal.aspx" target="_blank">Balancing your mount by Starizona</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Useful Programs
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment methods
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->2 Star Alignment
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.alignmaster.de" target="_blank">Using 2 Stars with AlignMaster</a></li>
         <li class="slast"><a href="http://www.sharpcap.co.uk/sharpcap" target="_blank">SharpCap for use with Alignmaster</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Polar Alignment from Astro-Tom</a></li>
       <li><a href="http://www.celestialwonders.com/articles/polaralignment/" target="_blank">Polar Alignment Star offset method</a></li>
       <li><a href="http://celestialwonders.com/articles/polaralignment/polaralignmentsurvey.html" target="_blank">Survey of Polar Alignment Methods</a></li>
       <li><a href="http://canburytech.net/DriftAlign/" target="_blank">Understanding Drift Alignment</a></li>
       <li><a href="http://eqalign.net/e_index.html" target="_blank">EQAling</a></li>
       <li><a href="http://www.petesastrophotography.com/" target="_blank">Polar Alignment by Paul Kennett</a></li>
       <li><a href="http://www.andysshotglass.com/DriftAlignment.html" target="_blank">Polar Alignment by Andy's Shot Glass</a></li>
       <li class="slast"><a href="http://www.astrosurf.com/re/polar.html" target="_blank">Polar Alignment by Astrosurf</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Observatory programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.stellarium.org/" target="_blank">Stellarium</a></li>
       <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gude Programs
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst slast"><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank">MetaGude</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.bytearts.com/stellarium/" target="_blank" title="Make Stellarium ASCOM compatible for Windows">StellariumScope</a></li>
       <li><a href="http://www.ap-i.net/skychart/" target="_blank">SkyChart / Cartes du Ciel</a></li>
       <li><a href="http://zytratechnologies.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank">Setting up Stellarium</a></li>
       <li><a href="http://sourceforge.net/p/astrotortilla/home/Home/" target="_blank">AstroTortilla Astrophotography assistant</a></li>
       <li class="slast"><a href="http://lightvortexastronomy.blogspot.com/2013/08/tutorial-imaging-setting-up-and-using.html" target="_blank">Plate Solving with Astrotortilla</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Misc Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://darkhorizons.emissionline.com/GMB/gmb.htm" target="_blank">Gemini Model Builder</a></li>
       <li><a href="http://www.nirsoft.net/utils/usb_devices_view.html" target="_blank">View USB Port assignments </a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip FIle archiver use to zip and unzip all files on this site</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Disk and Partition Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.sdcard.org/downloads/formatter_4/" target="_blank">Micro SDcard Formatter</a></li>
       <li><a href="http://www.partitionwizard.com/" target="_blank">MiniTool Partition Wizard</a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs for Windows
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://filezilla-project.org/download.php?type=client" target="_blank">FileZilla</a></li>
       <li><a href="http://www.wsftple.com/download.aspx" target="_blank">WS_FTP LE (V12)</a></li>
       <li><a href="http://www.oldversion.com/WS_FTP_Limited_Edition.html" target="_blank">WS_FTP V6</a></li>
       <li class="slast"><a href="http://winscp.net/eng/index.php" target="_blank">WinSCP</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs For Mac
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.kekaosx.com/en/" target="_blank">Keka (7zip ported to OS X)</a></li>
       <li><a href="http://www.apple.com/downloads/macosx/internet_utilities/classicftpformac.html" target="_blank">Classic FTP</a></li>
       <li><a href="http://fetchsoftworks.com/">Fetch FTP</a></li>
       <li><a href="http://www.macorchard.com/filetransfer/" target="_blank">List of Many Mac FTP</a></li>
       <li class="slast"><a href="http://blog.hostilefork.com/trashes-fseventsd-and-spotlight-v100/" target="_blank">Hidden Files A MAC puts on the SDcard</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->GPS Related programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/GPSrelated/redirect.zip" target="_blank">GPS_Port_Director (No install necessary)</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/GPSrelated/VisualGPSInstall.zip" target="_blank">Visual GPS Installer</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Network Scanners
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.softperfect.com/products/networkscanner/" target="_blank">Softperfect Network Scanner</a></li>
       <li><a href="http://www.radmin.com/products/ipscanner/" target="_blank">Advanced IP Scaner</a></li>
       <li class="slast"><a href="http://free-ip-scanner.eusing-software.qarchive.org/" target="_blank">Free IP Scanner</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li class="slast"><a href="downloads/USV_View/usbdeview.zip" target="_blank">USB View - USB port scanner</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Power Controllers
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.digital-loggers.com/ac.html" target="_blank">AC Controlled Relay</a></li>
     <li><a href="http://www.digital-loggers.com/lpc7.html" target="_blank">Web Power Switch</a></li>
     <li class="slast"><a href="http://www.digital-loggers.com/EPCR5.html" target="_blank">Ethernet Power Controller 5</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li class="tlast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Favorites
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->User Groups
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://groups.io/g/Gemini-II/" target="_blank">Gemini-II at groups.io</a></li>
     <li><a href="https://groups.io/g/Gemini_users/" target="_blank">Gemini User Group at Groups.io</a></li>
     <li><a href="https://groups.io/g/Losmandy_users/" target="_blank">Losmandy User Group at Groups.io</a></li>
     <li><a href="http://groups.yahoo.com/neo/groups/Titan_Mount/info" target="_blank">Titian User Group</a></li>
     <li><a href="https://groups.io/g/MI-250/" target="_blank">MI-250 Users Group</a></li>
     <li><a href="https://groups.io/g/Gemini_ASCOM_Driver/" target="_blank">Gemini Ascom Driver Group at Groups.io</a></li>
     <li class="slast"><a href="http://groups.yahoo.com/neo/groups/ASCOM-Talk/info" target="_blank">Ascom Talk Group</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Web Sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.docgoerlich.de/Gemini.html" target="_blank">René Görlich's Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://losmandy.com" target="_blank"><!--<![endif]-->Losmand Links -Web Site
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/eq-mounts.html" target="_blank">Equatorial Mounts</a></li>
       <li><a href="http://www.losmandy.com/secondary.html" target="_blank">D Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/v-series.html" target="_blank">Y Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/losmandygoto/gemini2.html" target="_blank">Gemini 2 Goto Syste,</a></li>
       <li><a href="http://www.losmandy.com/starlapse.html" target="_blank">StarLapse System</a></li>
       <li><a href="http://www.losmandy.com/access.html" target="_blank">Telescope Accessories</a></li>
       <li><a href="http://www.losmandy.com/replacement.html" target="_blank">Replacement parts</a></li>
       <li><a href="http://www.losmandy.com/distributors.html" target="_blank">Dealers</a></li>
       <li><a href="http://www.losmandy.com/pricelist.html" target="_blank">Price List</a></li>
       <li><a href="http://www.losmandy.com/support.html" target="_blank">Technical Support</a></li>
       <li><a href="http://store.losmandy.com/">Ordering inside USA</a></li>
       <li><a href="https://secure28.securewebsession.com/losmandy.com/order.shtml" target="_blank">Ording International or custom parts</a></li>
       <li><a href="http://www.losmandy.com/whatsnew.html" target="_blank">Whats New</a></li>
       <li class="slast"><a href="https://www.valvoline.com/en-ecuador/our-products/grease/durablend-synthetic-blend-grease" target="_blank">Recommend Grease by Losmandy</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://www.mi250.com/" target="_blank">MI-250 Web Site</a></li>
     <li><a href="https://www.arizonaskys.com" target="_blank">ArizonaSkys (my obsevatory web site - under construction</a></li>
     <li><a href="http://www.ascom-standards.org/index.htm" target="_blank">Ascom Standards Org</a></li>
     <li><a href="https://www.nightskiesnetwork.ca/" target="_blank" title=" worldwide astronomy broadcast site">Night Skys Network</a></li>
     <li><a href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank">Wilmslow Astro G11 tips</a></li>
     <li><a href="http://astronomy.tools" target="_blank">Astronomy Tools - Calculators - FOV - Star Charts</a></li>
     <li><a href="http://www.skippysky.com.au/" target="_blank">SkippySky Astro-Weather Forcast</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Tuning the G11
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.astromaster.org/esperienze_file/G11maintenance_e.htm" target="_blank">Maintain and tune a G11 mount</a></li>
       <li class="slast"><a href="http://www.astro.uni-bonn.de/~mischa/mounts/g11_tuning.html" target="_blank">Tuning a G11- for 2000 or older mounts</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://garriou.didier.free.fr/astro/gemini_anglais.html" target="_blank">Didier Garriou Gemini Catalogs building site</a></li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank">Titan Tips by Bob Allevo</a></li>
     <li><a href="http://www.stargps.ca/" target="_blank">Star GPS Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://openphdguiding.org/" target="_blank">PHD2 Home</a></li>
       <li><a href="https://code.google.com/p/open-phd-guiding/wiki/DriftAlignmentWithPHD2" target="_blank">Open-phd-guiding</a></li>
       <li><a href="https://groups.google.com/forum/#!forum/open-phd-guiding" target="_blank">Discussion Group </a></li>
       <li class="slast"><a href="https://www.youtube.com/watch?v=LXFGRta98rs" target="_blank">Introduction to optimal auto - guiding: How to get the most from your set - up</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://www.sharpcap.co.uk/" target="_blank">SharpCap</a></li>
     <li class="slast"><a href="https://sites.google.com/site/astropipp/" target="_blank">Planetary Imaging Software</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/all-links.php" target="_blank">300+ Astronomy Links</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
</ul>
 <br >
</div>

</body>



<link href="gemini-2.css" rel="stylesheet" type="text/css" />


<style type="text/css">
.auto-style1 {
	text-decoration: underline;
}
.auto-style3 {
	margin-left: 40px;
}
</style>


</head>

<body style="color: #FFFFFF; background-color: #000000" class="h2">


<table align="center" style="width: 900px">

	<tr>
		<td class="h3">Troublingshooting Gemini-2 Problems</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style7">Note: most links are from this site and not on the 
		Gemini-2 itself.</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
	<tr>
		<td class="style6">Please note if you are using older versions of the firmware, please update
		 to the latest and try your problem again before reporting your problems.&nbsp; 
		To tell your firmware dates go
		<a href="tellfirmwareversion.php" target="_blank">here.</a></td>
	</tr>
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
	<tr>
		<td class="style6" ><strong>When either the Gemini-2 or Gemini-1 starts to show problems/errors, 
		always change the battery.&nbsp; Low batteries can give very 
		weird symptoms.</strong></td>
	</tr>
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td width="300px" class="style7"><a href="#1">Report Problems</a></td>
		<td width="300px" class="style7"><a href="#6">ASCOM Driver won't connect</a></td>
		<td width="300px" class="style7"><a href="#Install-uninstall-driver-fails">ASCOM Driver won't Install</a></td>
	</tr>
	<tr>
		<td width="300px" class="style7"><a href="#5">Back after power fail</a></td>
		<td width="300px" class="style7"><a href="#12">DEC or RA misbehaving</a></td>
		<td width="300px" class="style7"><a href="#14">Ethernet problems</a>.</td>
	</tr>
	<tr>
		<td width="300px" class="style7"><a href="#8">Forced Cold Start</a></td>
		<td width="300px" class="style7"><a href="#3">HC not connecting</a></td>
		<td width="300px" class="style7"><a href="#4">How to Bench Test</a></td>
	</tr>
	<tr>
		<td width="300px" class="style7"><a href="#7">Low/Bad Battery Symptoms</a></td>
		<td width="300px" class="style7"><a href="#13">Motor Stall Faults.</a></td>
		<td width="300px" class="style7"><a href="#11">Mount rejecting stars</a></td>
	</tr>
	<tr>
		<td width="300px" class="style7"><a href="#Removing_Virus_or_Malicious_Software">Removing Virus or Malicious Software</a></td>
		<td width="300px" class="style7"><a href="#10">Screen changing languages when touched.</a></td>
		<td width="300px" class="style7"><a href="#2">Slews Wrong Direction</a></td>
	</tr>
	<tr>
		<td width="300px" class="style7"><a href="#9">Some Screens of the HC not functioning 
		after firmware upgrade</a></td>
		<td width="300px" class="style7"><a href="#2a">Tracks in Wrong Direction</a></td>
		<td width="300px" class="style7"></td>
	</tr>
<!--	<tr>
		<td width="300px" class="style7"><a href="#15"> </a></td>
		
	</tr>-->
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>

<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">1. <a name="1"></a> <em><u>Reporting Problems:</u></em><br />
		&nbsp;&nbsp;&nbsp;
		If you are having problems that you would like to 
		report to the writer of the code for either the Gemini-2 or the ASCOM 
		driver, please follow the steps at
		<a href="http://www.gemini-2.com/error-reporting.php" target="_blank">
		http://www.gemini-2.com/error-reporting.php</a></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp; &nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">2. <a name="2"></a> <u><em>
		Mount Slews the Wrong way:</em></u><br />
&nbsp;&nbsp;&nbsp; If your mount slews in the wrong direction with the 
		arrow buttons or during an alignment, please check these items. 		
		<ol type="A"><li>Make sure the RA and Dec cable are connected correctly. 
			Remember the DEC is the top connector on the mount, and the RA is the bottom connector.</li>
			<li>Make sure your Latitude, Longitude, and Timezone are set 
			correctly.&nbsp; Timezone is the most common error, with the format 
			of the Latitude and Longitude being second.&nbsp; The seconds must 
			be between 0 and 59 like a clock.<br />See
			<a href="http://www.gemini-2.com/hc/E019.php" target="_blank">
			site menu</a>.&nbsp; On HC, Menu--&gt;Site</li>
			<li>Make sure you Local and UTC times are showing correctly on the 
			Web interface.<br />See 
			<a href="http://www.gemini-2.com/web/web-site-time.php" target="_blank">
			Site/Time</a> on the Web interface.</li>
			<li>Make sure that your mount type is selected correctly, 
			<br />See	<a href="http://www.gemini-2.com/hc/En-mounttype.php" target="_blank">
			mount type menu</a>. On HC, Menu--&gt;Mount--&gt;Type</li>
			<li>Check that the gearing is correct. 
			<br />See <a href="http://www.gemini-2.com/hc/En-customgearing.php">
			gearing</a> and
			<a href="http://www.gemini-2.com/hc/default_gearing_setting.php" target="_blank">
			gearing chart</a>.&nbsp; Oh HC, see Menu--&gt;mount--&gt;gearing.</li>
			<li>If you have just done a firmware upgrade, Please make sure you 
			have done a
			<a href="http://www.gemini-2.com/web/web-firmware-sram.php" target="_blank">
			SRAM Reset</a> at the bottom of the Web interface page Firmware/SRAM.&nbsp; </li>
			<li>Make sure your battery is good.&nbsp; See <a href="#7">Low Battery Symptoms</a></li>
			<li><a name="2a"></a>If all the above is correct, and the mount 
			still slews in the wrong direction, and also tracks in the wrong 
			direction, you might have a mount where the gearboxes was replaced 
			with Mclennan gearboxes.&nbsp; These gearboxes reverse the direction of 
			the drive train.&nbsp; You will have to use 
			<a href="http://www.gemini-2.com/web/web-mount.php" target="_blank">custom mount</a> 
			and change the sign of The RA Worm Ratio and the Dec Worm Ratio, or if 
			you mount is a G11 and both gearboxes was upgraded, you can select 
			MI-250.&nbsp; You will have to reset your limits also. In menu bar 
			see "Tips/Programs"--&gt;"Gearboxes and Mods"--&gt;"Mclennan Gearbox 
			Upgrade"</li>
		</ol></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;&nbsp; &nbsp;</td>
	</tr>
</table>

<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">3. <a name="3"></a> <u><em>Hand 
		Controller will not connect:</em></u><br />
&nbsp;&nbsp; If the hand controller will not connect, and is only 
		giving the message "Connecting to Gemini"</td>
	</tr>
	<tr>
		<td class="style6">
		<ol type="A"><li>
		
			make sure the hand controller is plugged into the bottom Serial Port 
			2/Graphics HC connector.</li>
			<li>
		
			If you just updated the firmware, then the micro SDcard in the HC 
			might have become corrupted. If this has happened, you will have to 
			remove the micro SDcard from the hand controller and then use an 
			external 
			micro SDcard reader/writer (normally USB device) to examine the cards contents.&nbsp; 
			Note: the only way to see the contents of the micro SDcard in the 
			hand controller is with an external reader/writer. The 
			root of the card should look like this:<br />
			<img alt="" height="88" src="gemini-images/troublingshooting/HC_root.jpg" width="152" /></li><br />
			<ol type="I">
			<li>The current.bin file indicates that the program was programmed into the ARM processor. <br />If it had 
			not been programmed, then it's name would still be gemhc.bin</li>
			<li>While the catalogs directory should have about 20 star catalogs with 
			there names ending in .guc&nbsp; All the catalog files are optional.&nbsp; 
			You can have just the ones you want.</li>
				<li>The HCfirmware directory should look like this with 37 files 
				in it.&nbsp; None of these files are optional.&nbsp; All must be 
				in the HCFirmware directory for the HC to work correctly.<br />
				<img alt="" height="344" src="gemini-images/troublingshooting/inside-hcfirmware_dir.jpg" width="700" />
				</li> 
				<li>To remove and replace the micro SDcard please see:
				<a href="http://gemini-2.com/Removing_SDCards.php" target="_blank">
				Removing Micro SDcard</a></li>
				<li>Also the micro-SDcard in the hand controller comes loose in 
				it socket.&nbsp; This is especially true of the first versions 
				of the hand controller.&nbsp; Normally simply reseating the card 
				will fix the problem.</li>
				<li>Another problem is that the RJ-12 connectors on the coiled 
				cord, becomes worn.&nbsp; They are pretty simple to cut off and 
				replace, if you have a crimper for RJ12 connectors.&nbsp; Most 
				Home Depots, Lowes and Radio Shacks carriers the connectors and 
				crimpers.</li>
				<li>Since the GFU program has now been releases, You can also 
				try first formatting the the micro-SDcard in the hand controller 
				and then use GFU to upload all new files.&nbsp; You will 
				how-ever have to have the hand controller partially working for 
				this to work.&nbsp; To format the mico-SDcard, go to Menu --&gt; 
				HC--&gt;SDcard--&gt;Format SDcard--&gt;Select Yes.&nbsp; Wait for the 
				Format to finish.&nbsp; Then open up GFU, on on the option boxes 
				only check "HC" and "catalogs," leave Gemini and Flash 
				unchecked.&nbsp; Hit the Start button.&nbsp; When the GFU 
				routines stops, unplug the hand controller and then plug it back 
				in.&nbsp; It should start uploading all the hand controller 
				files, which will take about 45 minutes or so.</li>
			</ol>
			
		</ol>
		<!--
		<ol type="a" start="3">
			<li>
		
			</li>
		</ol>
		-->
		</td>
	</tr>
</table>

<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">4. <a name="4"></a> <span class="auto-style1"><u><em>How to Bench Test.</em></u>
		<ol type="A"><li>
		
			I prefer to do bench testing with motors removed from the mount.&nbsp; 
			Now you can safely run the Gemini-2 or Gemini-1 without motors, but 
			you can tell so much more with the motors connected.
			<ol type="I">
				<li> 
				You can almost test all the functions of the Gemini-2 on the bench this way.  Just about all of the pictures 
				taken for this web site was done this way.</li>
				<li> 
				Notice when first powering on, that the RA motor does not turn.&nbsp; 
				It only starts rotating after a boot mode is selected. (Assuming 
				you are in parking mode 0, more on this later.)</li>
				<li> 
				The RA motor turns CCW for GM-8 and G11.&nbsp; It turns CW for 
				HGM-200, Titan, Titan 50 and MI-250.&nbsp; The speed is about 1 
				revolution in 10 seconds, but depends on the mount type.</li>
			</ol>
		
		</li>
			<li>Testing the guider input:&nbsp; If you have a Classic/Standard 
			hand controller, this can be plugged into the Guider input jack.&nbsp; 
			You can use the DEC and RA button to then simulate Guider input 
			signals.<br />If you have a GPUSB from Shoestring Astronomy along 
			with there GPUSBNudge program to do the same thing.
			<ol type="I">
				<li>
				RA
				buttons will cause the RA shaft to slow down with an -RA button 
				and speed up with a +RA button.</li>
				<li>
				DEC buttons will cause the CW with Positive DEC (GM8 &amp; G11) and 
				CCW with negative DEC button (again GM8 &amp; G11)&nbsp; The other 
				mounts will be opposite.
				</li>
			</ol>
			</li>
			<li>Testing Hand Controller input.&nbsp;
			<ol type="I">
				<li>The hand controller normally connects to the Serial Port 2 
				input jack.&nbsp; The baud rate for the hand controller is 
				always 57600 baud.&nbsp; This can only be set using the Web 
				interface using the 
				<a href="http://www.gemini-2.com/web/web-serial-ports.php" target="_blank">Serial Ports tab</a>.&nbsp; Set Serial Port 2.&nbsp;</li>
				<li>Will the hand controller work into Serial Port 1, Yes, but 
				you must set the baud rate of that port to 57600.&nbsp; Serial 
				port 1 will default to 9600 baud after a firmware update, so 
				having the hand controller connected to it is not the best idea.</li>
			</ol>
			</li>
			<li>Testing Serial Port 1 for GPS connection.&nbsp;
			<ol type="I">
				<li>
				Please see this
				<a href="http://www.gemini-2.com/GPS.php" target="_blank">page</a> 
				for using the Losmandy GPS or the Star GPS unit.</li>
				<li>
				Please note that the GPS does not update the TimeZone setting.&nbsp; 
				All GPS units only return UTC time.&nbsp; The Gemini-2 then can 
				take that time and the TimeZone value you have set using either 
				the site menu or the TimeZone menu and display your local time.&nbsp; 
				If your Timezone is set wrong, then the Gemini-2 will calculate 
				the local time wrong.&nbsp; If you do not like to worry about 
				daylight saving time changing the TimeZone requirements, then 
				set the TimeZone to UTC which would be zero.&nbsp; Enter UTC 
				Time and Date manually or use a GPS unit.&nbsp; The local time 
				now will display the UTC time and date, and the G2 will be 
				happy.&nbsp; Make sure your Latitude and Longitude are correct.</li>
				<li>
				It is possible to simulate a GPS connection using programs such as GPS port director found under useful Programs. 
				This program will allow a GPS connected to a PC to be redirected to a com port connected into the Gemini-2. Your PC
				is of course going to have to have 2 serial ports.  Now one of these can be a USB style GPS unit 
				(such as the ones that used to be supplied with Microsoft 
				Streets and Maps.&nbsp; There are also many cheap USB GPS units 
				on the market.), where it's driver
				creates a virtual serial port.  Most likely, you would have to use a USB to Serial adapter for the second serial port.</li>
			</ol>
			</li>
			
		</ol></td>
	</tr>
</table>
<table align="center"  style="width: 900px">
	<tr><td>&nbsp;</td>
	</tr>
</table>

<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6"> <a name="5"></a>5. <u><em>Back After Power Fail.</em></u>
		<ol type="A">
		<li>
		Gemini has a voltage supervisor on board that is primarily used to save all important data (positional, date, time) at power-off. 
		This is necessary to allow for permanent PEC and Warm (Re)Start. 
		</li>
		<li>
		This supervisor triggers an interrupt if the voltage drops down below about 10V. 
		All GoTo operations are stopped, motors are halted, Housekeeping is done, all files are closed.
		</li>
		<li>
		G2 then enters a loop and waits for browning out (power off) or for regaining power. 
		If power comes back the message "Back after power fail" is displayed and 
		normal operation can proceed.
		</li>
		</ol>
	</td>
	</tr>
</table>
<table align="center"  style="width: 900px">
	<tr><td>&nbsp;</td>
	</tr>
</table>


<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		6. <a name="6"></a><u><em>ASCOM Driver won't connect:</em></u>
			<ol type="A">
			<li>
			The ASCOM Gemini.net driver normally depends on what is called "NetBios 
			Name Resolution" to find and connect to the Gemini-2 using Ethernet.&nbsp; 
			For this to work, several things have to be in place:
			<ol type="I">
				<li>
				See <a href="configuringEthernetASCOMdriver.php" target="_blank">
				Configuring Ethernet ASCOM Driver</a> and follow these steps to 
				configure the ASCOM driver for Ethernet connection.</li>
				<li>
				NetBios Name Resolution has to be enabled on the system.&nbsp;
				<a href="Enabling_netbios.php" target="_blank">Enabling NetBios</a></li>
				<li>
				DHCP is also the normal default mode for setting the IP address.
				<ol type="i">
					<li>If you are connecting directly into a laptop wired 
					connector (not using a router), you are probably
					using static IP addresses.</li>
					<li>It is possible to make Windows provide a DHCP address to 
					the Gemini-2 using "Internet Connection Sharing (ICS)." The 
					problem with this is that it normally makes the network 
					after the Laptop a Public network, which limits things.&nbsp; 
					I am not going to get into how to configure ICS here, as 
					this really depends on your Lan layout. Here are several 
					links on how to do it for Win 7.<ol type="a">
						<li>
						<a href="http://windows.microsoft.com/en-us/windows/using-internet-connection-sharing#1TC=windows-7" target="_blank">
						Using ICS with Win 7</a>.</li>
						<li>
						<a href="http://windows.microsoft.com/en-us/windows/using-internet-connection-sharing#1TC=windows-7" target="_blank">
						Set up a shared Internet connection using ICS</a></li>
					</ol>
					</li>
				</ol>
				
				</li>
			</ol>
			</li>
				<li>The UPD ports that the ASCOM Gemini.net communicates through 
				in the router have to be available and enabled.&nbsp; This is a 
				router setting, and they are normally open in most routers, and 
				because there or thousands of different routers available, this 
				cannot be covered here.</li>
				<li>The ports also must not be blocked by the Firewall.&nbsp; If 
				they are, then you will have to tell your firewall to allow 
				them. </li>
				<li><a name="Install-uninstall-driver-fails"></a>If you try to install a newer version of the ASCOM 
				Gemini.net driver, or try to uninstall the Gemini.net driver 
				using the Control Panel and get an error message that some of 
				the components are missing and the install or uninstall fails, 
				then you are going to have to use a different program to try and 
				remove the rest of the driver.&nbsp; Paul, the writer of the 
				ASCOM Gemini.net driver recommends trying VSRevo Group's Revo 
				Uninstaller.&nbsp; There is a free and paid ($39.25 for 1 
				computer) versions and portable ($69.25 for unlimited computers) 
				versions
				<a href="http://www.revouninstaller.com/revo_uninstaller_free_download.html" target="_blank">
				here.</a> </li>
			</ol>
			</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr class="style6">
		<td>
		7. <a name="7"></a><em><u>Low/Bad Battery Symptoms:</u></em>
		<ol type="A">
			<li>
			The internal battery 
			in the main Gemini 2 unit powers both the Real Time clock and the internal CMOS-RAM both of 
			which are 
			located inside the ARM processor that is the brains of the Gemini-2.&nbsp; 
			This battery is a CR2354, and the type of holder makes it a little 
			difficult to replace in the Original Gemini-2. (<a href="http://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">CR2354 
			battery change video</a>.)&nbsp;In the new Gemini-2 Mini the battery 
			type is a CR2450 and is much easier to change. (<a href="http://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2450.mp4" target="_blank">CR2450 
			battery change video</a>). There is no battery in the hand 
			controller.&nbsp;&nbsp; Symptoms of a low or dead battery:</li>
			<ol type="I">
				<li>Not remember the site on power up, </li>
				<li>Comes up with the wrong time or date,</li>
				<li>Does not remember mount type,</li>
				<li>Model or PEC not remembered,</li>
				<li>GOTO's are erratic</li>
				<li>Forced Cold Start. </li>
				<li>There could be many other problems caused by this also.</li>
			</ol>
			<li>Replace this battery when the battery level scale shows it to be 
			2.75 volts or lower.&nbsp; You find this reading on the Web 
			interface under Battery, Ports tab. See
			<a href="/web/web-battery-ports.php" target="_blank">web battery, 
			ports</a> as an example.</li>
			<li class="style6Red">IMPORTANT: As soon as you have replaced the battery, 
			<em><u>Please power on the Gemini-2 and set the time and date.</u></em> If you don't it is possible 
			that the ARM processor will try and draw a lot of power from the 
			battery, and could cause internal damage.</li>
			<li class="style6"">I suggest that if you have the original Gemini-2 you
			consider changing the battery holder to the one for the CR2450.
			You can get one from 
			<a href="https://www.mouser.com/ProductDetail/Keystone-Electronics/1053?qs=%2fha2pyFaduhIp1yZj%252bHL4dqpQ0dEcYMmVEgfiPuLFYacWefKptt%252b9Q%3d%3d" target="_blank">Mouser Electronics Part number 534-1053-BH</a>
			It will fit in the same holes and space as the current battery holder.  You might consider using
			<a href="https://www.mouser.com/ProductDetail/Chip-Quik/SMD1?qs=sGAEpiMZZMtyU1cDF2RqUEx4HVIhVm2RxvaiiXwXOtA%3d" target="_blank">ChipQuik SMD Removal kit</a> which contains solder that stays molten long enough to easily remove the old
			holder very easy.  I know, I used it to change to this battery holder on my own
			Gemini-2. Of course I should not have to say if you do this, 
			you do it at your own risk. So you might want to get a TV or Computer repair shop to do it for you.</li>
<!--			</ol>
		<br />
		
		<ol type="A"> -->
			<li class="style6">To Remove the front panel requires a 1/16 inch 
			Allen Wrench.&nbsp; They can be ordered from Losmandy for&nbsp; a 
			small fee plus shipping.</li>
		</ol>
		</td>
	</tr>
</table>

<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<!--
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
-->
<table align="center" class="tableborder1" style="width: 900px">
	<tr class="style6">
		<td>
		8. <a name="8"></a><em><u>Forced Cold Start:</u></em>
		<ol type="A">
			<li>
			The internal battery 
			in the main Gemini 2 unit powers both the Real Time clock and the internal CMOS-RAM both of 
			which are 
			located inside the ARM processor that is the brains of the Gemini-2.&nbsp; 
			This battery is a CR2354, and the type of holder makes it a little 
			difficult to replace in the Original Gemini-2. (<a href="http://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">CR2354 
			battery change video</a>.)&nbsp;In the new Gemini-2 Mini the battery 
			type is a CR2450 and is much easier to change. (<a href="http://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2450.mp4" target="_blank">CR2450 
			battery change video</a>). There is no battery in the hand 
			controller.&nbsp;&nbsp; Symptoms of a low or dead battery:</li>
			<ol type="I">
				<li>Forced Cold Start. Also this can also happen on Gemini-1 
				systems as well.</li>
				<li>Not remember the site on power up, </li>
				<li>Comes up with the wrong time or date,</li>
				<li>Does not remember mount type,</li>
				<li>Model or PEC not remembered,</li>
				<li>GOTO's are erratic </li>
				<li>There could be many other problems caused by this also.</li>
				
			</ol>
			<li>Also there is a selection menu on the hand controller "Menu 
			--&gt;Startup --&gt;Cold Start" that will force a startup in cold start.&nbsp; 
			Like wise, the Web interface also has this same selection. Also see 
			at the bottom of page
			<a href="http://www.gemini-2.com/web/web-mount.php" target="_blank">
			http://www.gemini-2.com/web/web-mount.php</a> for an example.&nbsp;It's 
			normal selection is "Ask if Possible".&nbsp; 
			If you have your Gemini-2 connected via Ethernet, then
			<a href="http://gemini/mountpar.cgi" target="_blank">http://gemini/mountpar.cgi</a> 
			will take you to the web interface page. You will have to log in.</li>
		</ol>
		</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		9. <a name="9"></a> <u><em>
		Some Screens of HC not functioning after firmware update:</em></u><br />
&nbsp;&nbsp; If 
		some or most of the screens in the hand controller are malfunction after 
		a firmware update then the micro-SDcard in the hand controller is 
		probably corrupt.&nbsp; Do the following steps to try and recover and 
		redo the hand controller.</td>
	</tr>
	<tr>
		<td class="style6">
		
		<ol type="A">
		<li>
			make sure the hand controller is plugged into the bottom Serial Port 
			2/Graphics HC connector.</li>
			
			<li>
			If you just updated the firmware, then the micro SDcard in the HC 
			might have become corrupted. If this has happened, you might be able 
			to recover by doing a format of the Micro-SDcard.&nbsp;</li>
			<ol type="a">
				<li>On the Hand Controller Main Screen, Select "Menu" =&gt; "HC" =&gt; 
				"SD Card" =&gt; "Format SDcard" =&gt;"Yes"&nbsp; This will do an 
				internal format of the micro-SDcard in the hand controller unit.
				</li>
				<li>
				Now we are going to use GFU firmware download program twice. So 
				bring up the GFU program and make sure the IP address the 
				location of the Download are correct.
				</li>
				<li>Now uncheck all the 
				check boxes except HC.&nbsp; Your GFU screen should look similar 
				to this: 
				</li>
				
				</ol>
			</ol>
			</td>
			</tr>
	</table>
	<table  align="center" style="width:900px">
	<tr>
		<td class="style6">
			<img alt="" height="380" src="gemini-images/troublingshooting/gfu_first.jpg" width="900" />
			</td>
		</tr>
	</table>				
	<table  align="center" style="width:900px">
	<tr>
		<td class="style6">

			 <p class="auto-style3">d. Hit the "Start" Button<br />
			e.  and then let GFU go through Download, Extract, and Upload.<br />
			f. Now unplug the hand controller, and then plug it back in.&nbsp; 
				It should start uploading programs into the hand controller, and 
				also flash itself.<br />
							g. Now we need to do the same thing except 
				with the catalogs of the hand controller.<br />
			h. Open GFU back up and unselect all the checkboxes except catalogs.
			 </p>
			</td>
			</tr>
			</table>
				
	<table  align="center" style="width:900px">
	<tr>
		<td class="style6">
		<img alt="" height="422" src="gemini-images/troublingshooting/gfu_second.jpg" width="900" />
		</td>
	</tr>
</table>
	<table  align="center" style="width:900px">
	<tr>
		<td class="style6">
				i. Hit the "Start" Button, and then let GFU go through 
				Download, Extract, and Upload <br />
				j. Again unplug the hand controller and plug it back in. 
				It will start uploading all the catalogs to the hand controller 
				from the main unit. The catalog files are large, and this 
				can take an hour or so.
		</td>
	</tr>
</table>


<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		</td>
	</tr>
	<tr>
		<td class="style6">
		
		<a name="Removing_Virus_or_Malicious_Software"></a><u>Removing Virus or 
		Malicious Software</u>:
If you suspect that your Windows computer has a virus or 
			Malicious Software, Microsoft has two tools that can help you get 
			rid of it.<br />
		<ol>
			<li>Windows Defender Offline <a href="http://windows.microsoft.com/en-US/windows/what-is-windows-defender-offline" 
			target="_blank">http://windows.microsoft.com/en-US/windows/what-is-windows-defender-offline</a></li>
			<li>Malicious Software Removal tool <a href="http://www.microsoft.com/security/pc-security/malware-removal.aspx" 
			target="_blank">http://www.microsoft.com/security/pc-security/malware-removal.aspx</a></li>
		</ol>
		<p>I suggest that you use custom scan and only scan one drive at a time.&nbsp; 
		If the scan does not complete you will loose the results of the scan.</p>
		</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		10. <a name="10"></a><em><u>Calibrating the Screen:</u></em> If the 
		screen changes languages when pushing on it, the the most probable cause 
		is that the screen touchpad calibration is way off.&nbsp; This is pretty easy to fix.&nbsp; 
		Just turn off the Gemini-2 and turn it back on while watching the Hand 
		controller.&nbsp; The second screen displayed will be the calibration 
		screen.&nbsp; You need to touch in the center of it, to start the 
		calibration routine.&nbsp; You have to be fast as this screen is only 
		displayed for about 1 second if you do not touch it.&nbsp; After 
		touching it, it will give you three calibration points to touch, each on 
		a seperate screen.&nbsp; I recommend using a stylus to do this.
		Then there will be a final screen that will go-away with a count down 
		timer.&nbsp; This should fix the problem.</td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>

<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		11. <u><em>
		Mount Rejecting stars:</em></u><br />
&nbsp;&nbsp;&nbsp; If your mount 
		is rejecting stars telling you they are not reachable, please check these items. 		
		<ol type="A">
			<li>Make sure your Latitude, Longitude, and Timezone are set 
			correctly.<br />See
			<a href="http://www.gemini-2.com/hc/E019.php" target="_blank">
			site menu</a>.&nbsp; On HC, Menu--&gt;Site</li>
			<li>Make sure you Local and UTC times are showing correctly on the 
			Web interface.<br />See 
			<a href="http://www.gemini-2.com/web/web-site-time.php" target="_blank">
			Site/Time</a> on the Web interface.</li>
			<li>Make sure that your mount type is selected correctly, 
			<br />See	<a href="http://www.gemini-2.com/hc/En-mounttype.php" target="_blank">
			mount type menu</a>. On HC, Menu--&gt;Mount--&gt;Type</li>
			<li>Make sure your limits are set correctly. See
			<a href="http://www.gemini-2.com/limits.php" target="_blank">Limits</a>.</li>
			
			<li>If you have just done a firmware upgrade, Please make sure you 
			have done a
			<a href="http://www.gemini-2.com/web/web-firmware-sram.php" target="_blank">
			SRAM Reset</a> at the bottom of the Web interface page Firmware/SRAM.&nbsp; </li>
			<li>Make sure your battery is good.&nbsp; See <a href="#7">Low Battery Symptoms</a></li>
			<li><a name="2a"></a>If all the above is correct, and the mount 
			still rejects stars, Please try entering your time and date as UTC, 
			and set the time offset to ZERO</li>
		</ol></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">
		12. <a name="12"></a> <u><em>
		DEC or RA misbehaving:</em></u><br />
&nbsp;&nbsp;&nbsp; If your mount 
		DEC or RA misbehaving, please check these items. 		
		<ol type="A">
			<li> That the motor cables are in the correct place. The DEC is the TOP motor.  Don't feel bad if you get them backward. It happens all the time.
			
			
			</li>
			<li> DEC or RA not moving, Getting a STALL message.&nbsp; This 
			indicates that you probably have one of 3 things wrong.
			<ol type="a">
				<li>You have a bad motor cable.
				</li>
				<li>You have a bad motor. This has many indications, some of them very strange.<ol type="i">
					<li>If the motor still turns, but seems to go twice as far 
					as it should, then the encoder is bad.&nbsp; This is a very 
					rare case but does happen. (it indicates only one of the 
					encoder sensors is working. This provides only half the 
					pulses it should, so the motor has to turn twice as far to 
					satisfy the Gemini-2 encoder count.)</li>
					<li>If the motor starts off spinning at high speed, the 
					encoder is probably bad.&nbsp; This happens most often. (if 
					the Gemini-2 receives no encoder pulses it commands more 
					current to the motor. That makes the motor start spinning 
					wildly.&nbsp; Sometime a DEC motor will only do this when 
					commanded to move.)</li>
					<li>If the motor will not move and you are getting STALL 
					warning, then the motor winding, or connector might have 
					gone bad.<br />
					</li>
				</ol>
				</li>
				<li>The internal driver inside the Gemini has gone bad.</li>
			</ol>
			
			
			</li>
			
			<li>DEC or RA not moving, but no STALL message.&nbsp; Check that the 
			OLDHAM coupler is not slipping on the worm shaft.&nbsp; It is 
			between the worm and gearbox.</li>
			
		</ol></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="style6">&nbsp;</td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">13. <a name="13"></a> <u><em>
		Motor Stall Faults:</em></u><br />
&nbsp;&nbsp;&nbsp; If your mount 
		RA or DEC is having motor stall faults, here is a couple of suggestions. 		
		<ol type="A">
			<li> Ensure the power supply is sufficient in voltage and amperage. 
			Many forum posters recommend at least 15V and 4-5 Amps minimum, and 
			so do I.</li>
			<li> &nbsp;Use slower slewing speeds with 12V supplies.&nbsp; If you 
			are using only a 12V power source and have the stall faults.&nbsp; 
			Lowered the slewing speeds to 500 for RA and DEC and see if this 
			clears the .</li>
			
		</ol></td>
	</tr>
</table>
<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style6">14. <a name="14"></a> <u><em>
		Ethernet Problems:</em></u><br />
&nbsp;&nbsp;&nbsp; If you are using an USB to Ethernet adapter. 		
		<ol type="A">
			<li> Ensure that the computers Advanced Power setting: "USB selective suspend setting" is set to disabled.&nbsp; 
			See Image. 
			<a href="ethernet_connections.php#Turn_off_USB_suspend" target="_blank">See image</a>.</li>
			<li> Make sure the drivers you are using is the latest.</li>
			
		</ol></td>
	</tr>
</table>

<table align="center" class="tableborder1" style="width: 900px">
	<tr>
		<td class="style7">
		<a href="http://download.teamviewer.com/download/TeamViewerQS_en.exe" target="_blank">Teamviewer Quick Support download</a>
		</td>
	</tr>
</table>
<table  align="center" style="width:900px">
	<tr>
		<td class="style7">
		Page last updated on Oct 9, 2018
		</td>
	</tr>
</table>

</body>




<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>


<head>
<title>Bottom page</title>
<link href="/gemini-2.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/ajxmenu_bottom.css" type="text/css">


</head>

<body style="color: #FFFFFF; background-color: #000000" >
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">This site is not for profit 
		and sells nothing and asks for no money for any help it provides.&nbsp; This 
		site is 
		here to help fellow Gemini-2 and Gemini-1 owners. This Web Site is not 
		associated with Losmandy-Hollywood General Machining Inc. or any of 
		their employees and never has been. There is no guarantee that all the 
		information is correct, but strives to provide the best information 
		possible. The use of any information is at your own risk.&nbsp; The webmaster 
		is an unpaid beta tester, and tries to work with other beta testers, and 
		René the writer of the firmware.&nbsp;
		If you would like to help keep this web site going send your gift to <a href="http://paypal.me/geminitwo">paypal.me/geminitwo</a> 
		Your gift will be used to defray the cost of keeping this web site up, unless you specify otherwise.</span></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">
		I have tried many times to make a PDF of this site with no luck. Every program
		to do this screws up the links and images. I am not going to write a manual either.
		I developed this web site for my own use in the beginning, but it soon went public.</span></td>
	</tr>
</table>

	<table align="center" style="width: 900px">
		<tr>
			<td>
<div class="AJXMenuSPDSMNA"><!-- AJXFILE:ajxmenu_bottom.css -->
 <div class="ajxmw1">
  <div class="ajxmw2">
<ul>
 <li class="tfirst tlast"><a href="https://www.gemini-2.com/" target="_self">HOME</a></li>
</ul>
  </div>
 </div>
 <br >
</div>
</td>
</tr>
</table>

<!--
<table align="center"style="width: 50px">
	<tr>
	<td class="style6">Hit counter by<a href="http://digits.net"> http://digits.net</a></td>
	
	
	<td class="style6R" width="45%">
  <a href="http://www.digits.net" target="_blank">
    <img src="https://counter.digits.net/?counter={921ba194-f2d6-95c4-2981-2437d185efba}&template=simple" 
     alt="Hit Counter by Digits" border="0"  />
  </a>
  </td>
  </tr>
</table>
-->
&nbsp;<table align="center" cellpadding="4" cellspacing="4" style="width: 70%">
	<tr class="style6">
		<td class="style1">Your Privacy Policy
<br>No Information is collected by this site.&nbsp; Cookies are set in your browser, 
but only for visited<br/>links to change color.
</td>
	</tr>
	<tr class="style6">
		<td class="style13"><b>Your use of any information on this site is at your own risk.</b></td>
	</tr>
</table>
		
	<p class="style7" align="center"><!--webbot bot="HTMLMarkup" startspan --><script language=javascript>

	  <!--
	  var contact = "Thomas Hilton"
	  var email = "tomh"
	  var emailHost = "gemini-2.com"
	  document.write("copyright&copy; - 2017-2011 -<a href=" + "mail" + "to:" + email + "@" + emailHost+ ">" + contact + "</a>" )
	 //-->
	</script><!--webbot bot="HTMLMarkup" endspan -->
	and <a href="Https://www.Gemini-2.com">https://www.gemini-2.com</a>
	<br />Gemini-2 and Gemini is a registered trade names of Hollywood General Machining Inc.</p>

	
</body>




