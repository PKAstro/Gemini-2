<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Astronomy Links</title>
<!DOCTYPE html 
      PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>

<link rel="stylesheet" href="https://gemini-2.com/ajxmenu.css" type="text/css">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta content="en-us" http-equiv="Content-Language" />
<title>Gemini 2 Mount Controller</title>

<link href="https://gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css">
<style type="text/css">
a {
	color: #FF0000;
}
</style>


</head>
<body>
<table align="center" style="width: 900px">
	<tr><td align="center">
	<span class="h1">
		Gemini-2 and Gemini-1 Telescope Mount Controllers</span> <br />
		<span class="h2">Website and Tutorials </span>
		</td>
	</tr>
</table>


<table align="center" style="width: 900px">
	<tr>
		<td align="center">
<form action="https://www.google.com/search" method="get"> <div style="border:1px solid black;padding:4px;width:20em;"> <table align="center" border="0" cellpadding="0"> 
<tbody> 
<tr><td> <input maxlength="255" name="q" size="25" type="text" value="" /> <input type="submit" value="Google Search" /></td></tr> 
<tr><td align="center" style="font-size:75%"> <input checked="" name="sitesearch" type="checkbox" value="gemini-2.com" />
 only search Gemini-2.com<br /> </td></tr></tbody></table> </div> </form>
		
		</td>
	</tr>
</table>
<!--
<table align="center" style="width: 900px">
	<tr>
		<td class="style7" >
		There is a new <a href="http://wiki.gemini-2.com" target="_blank">Question and Answer Wiki</a> section where you can ask searchable questions.  		
		</td>
	</tr>
</table>
-->

<table align="center" style="width: 900px">
	<tr>
		<td align="center">
		</td>
	</tr>
</table>

<div class="AJXMenueDFaTFD"><!-- AJXFILE:ajxmenu.css -->
<ul>
 <li class="tfirst"><!--[if IE]><!--><a class="ajxsub" href="index.php" target="_self"><!--<![endif]-->Home/Start&nbsp;Here
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/Getting_started.php" target="_blank">1 - New Users Start Here</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/front_panel_pinouts.php" target="_blank"><!--<![endif]-->2.- Front Panel Pinouts
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Orginal Gemini-2 Version</a></li>
     <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">New Gemini-2 Mini</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/definitions.php" target="_blank">3 - Definitions</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->4.- Tutorials
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/quickstart/index.php" target="_blank">4.1 Quick Start &amp; Screen Alignment</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">4.2  Hand Controller</a></li>
     <li class="slast"><a href="https://gemini-2.com/alt-alignment.php" target="_blank" title="Manual method for adding a star to models.">4.3  Add a star to a model</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->5 - Videos
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_Videos.php" target="_blank">5a - Videos by Scott Losmandy on YouTube</a></li>
     <li class="slast"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">5b - Gemini.com  Videos</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->6 - Connecting Gemini-2 to Computer
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/connecting_Gemini_to_computers.php" target="_blank">6a- Connecting Gemini-2 to a computer</a></li>
     <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">6b-Using ASCOM with windows</a></li>
     <li class="slast"><a href="https://gemini-2.com/faqGII.php#Q3" target="_blank">6c - Multiple Gemini-2 on network</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/G2_Verse_G1-Modeling.php" target="_blank">7 - G2 Verse G1 modeling</a></li>
   <li><a href="https://gemini-2.com/web/index.php" target="_blank">8 - Web Interface Pages</a></li>
   <li><a href="https://gemini-2.com/limits.php" target="_blank">9 - Setting Limits - Very Important</a></li>
   <li><a href="https://gemini-2.com/Installing_ASCOM.php" target="_blank">10 - Installing Gemini.net ASCOM driver</a></li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank">11 - FAQ about Gemini-2</a></li>
   <li><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">12 - Firmware versions and updating.</a></li>
   <li><a href="https://gemini-2.com/Simple_Rules_Gemini_Uses.php" target="_blank">13 - Rules that Gemini-2 follows:</a></li>
   <li class="slast"><a href="https://www.gemini-2.com/credits.php" target="_blank">13 - A little history</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini-2"><!--<![endif]-->Gemini&nbsp;2&nbsp;&nbsp;&nbsp;&nbsp;
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting Tips</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Start here for Gemini 2"><!--<![endif]-->Using the Gemini 2 controller
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/definitions.php" target="_blank">Definitions</a></li>
     <li><a href="https://gemini-2.com/alignment_procedure.php" target="_blank">Initial Alignment and Startup</a></li>
     <li><a href="https://gemini-2.com/hc/index.php" target="_blank">Navigating Hand Controller Menus</a></li>
     <li><a href="https://gemini-2.com/web/index.php" target="_blank">Navigating the Internal Web Pages</a></li>
     <li><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Semi-Automatic Alignment Method</a></li>
     <li><a href="https://gemini-2.com/limits.php" target="_blank">Setting Limit switch drawing</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/E026.php" target="_blank" title="Will help you polar align the mount">Polar Axis Assist</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Connect G2 to Ethernet"><!--<![endif]-->Connectiong to Ethernet Port
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/ConnectingtoG2.php" target="_blank" title="connecting to web interface">Connecting to Ethernet Port</a></li>
     <li><a href="https://gemini-2.com/crossovernetwork.php" target="_blank" title="G2 directly to Computer">Configuring Win 10, Win7 &amp; XP for Static IP</a></li>
     <li><a href="https://gemini-2.com/Enabling_netbios.php" target="_blank">Enabling NetBios on Windows Networks</a></li>
     <li><a href="https://gemini-2.com/travel_routers.php" target="_blank">Adding WiFi to Gemini-2</a></li>
     <li><a href="https://gemini-2.com/ethernet_connections.php" target="_blank">Ethernet Connection methods/drawings</a></li>
     <li><a href="https://gemini-2.com/configuringEthernetASCOMdriver.php" target="_blank">Configuring The ASCOM Driver's Ethernet connection</a></li>
     <li class="slast"><a href="https://gemini-2.com/network-places.php" target="_blank">Adding the Gemini-2 to FTP network places</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank" title="5 ways to update firmware"><!--<![endif]-->Updating Gemini FIrmware
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/tellfirmwareversion.php" target="_blank">How to tell firmware versions</a></li>
     <li><a href="https://gemini-2.com/updatefirmwaremethods.php" target="_blank">Update Gemini Firmware Methods     </a></li>
     <li><a href="https://gemini-2.com/gfu.php" target="_blank">Using the Gemini Firmware Updater Program</a></li>
     <li><a href="https://gemini-2.com/Removing_SDCards.php" target="_blank">Removing and Replacing micro-SDcards</a></li>
     <li class="slast"><a href="https://gemini-2.com/copycatalogs.php" target="_blank">Adding Catalogs to the Handcontroller</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/faqGII.php" target="_blank" title="For Gemini 2">Frequently Asked Questions</a></li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#" title="Wiring"><!--<![endif]-->Gemini-2 Documentation
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/gemini2_videos.php" target="_blank">Movies produced for this site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Front Panel Pinouts and Connection Function Discriptions
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/front_panel_pinouts.php" target="_blank">Original Gemini-2</a></li>
       <li class="slast"><a href="https://gemini-2.com/front_panel_pinouts_mini-gemini-2.php" target="_blank">Gemini-2 Mini</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Cable Wiring
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/cable_wiring.php" target="_blank" title="Both G1 and G2">Serial Port Wiring</a></li>
       <li><a href="https://gemini-2.com/serial_port_modes.php" target="_blank" title="G2 only">Serial Port Modes</a></li>
       <li><a href="https://gemini-2.com/Losmandy_Serial_Cable.php" target="_blank" title="Inside of Losmandy Serial Cable">Losmandy Serial Cable </a></li>
       <li><a href="https://gemini-2.com/handcontroller-cable-ends.php" target="_blank">Hand Controller Cable</a></li>
       <li class="slast"><a href="https://gemini-2.com/hand_controller_extender.php" target="_blank">Hand controler Extender Addon</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">Losmandy Motors</a></li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
     <li><a href="https://gemini-2.com/Gemini2_features.php" target="_blank">Gemini-2 Features</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Gemini-2 and ASCOM Driver Errors</a></li>
     <li class="slast"><a href="https://gemini-2.com/Cksum.php" target="_blank" title="Courtesy of Paul Kanevsky">Gemini Command Checksum Calculator</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/hc/index.php" target="_blank"><!--<![endif]-->G-2&nbsp;HC&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/hc/E019A.php" target="_blank">Site</a></li>
   <li><a href="https://gemini-2.com/hc/E023A.php" target="_blank">Time</a></li>
   <li><a href="https://gemini-2.com/hc/En-networkmenu_A.php" target="_blank">Network</a></li>
   <li class="slast"><a href="https://gemini-2.com/hc/En-SAE-01.php" target="_blank">Modeling</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="https://gemini-2.com/web/index.php" target="_blank" title="Web Tutorial"><!--<![endif]-->G-2&nbsp;Web&nbsp;Tutorial
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/web/web-site-time.php" target="_blank" title="Web Site Time">Site Time</a></li>
   <li><a href="https://gemini-2.com/web/web-network.php" target="_blank" title="Web Network">Network</a></li>
   <li><a href="https://gemini-2.com/web/web-battery-ports.php" target="_blank" title="battery">Battery Voltage</a></li>
   <li class="slast"><a href="https://gemini-2.com/web/web-firmware-sram.php" target="_blank" title="Firmware Sram">Firmware SRAM</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="All Things Gemini 1"><!--<![endif]-->Gemini&nbsp;1
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://gemini-2.com/faqG1.php" target="_blank">FAQ</a></li>
   <li><a href="https://gemini-2.com/G1drivers.php" target="_blank">G1 Driver/Manuals</a></li>
   <li><a href="https://gemini-2.com/pcb-pictures.php" target="_blank">Gemini 1 Versions</a></li>
   <li><a href="https://gemini-2.com/G1-repairers.php" target="_blank">Gemini Repair Facilities/People</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Changing batteries
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/videos/Losmandy_Gemini_Battery_CR2354.mp4" target="_blank">Changing CR2354</a></li>
     <li class="slast"><a href="https://gemini-2.com/videos/changing_CR2032_battery.mp4" target="_blank">Changing CR2032</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><a href="https://gemini-2.com/cable_wiring.php" target="_blank">RS-232 Cable wiring</a></li>
   <li><a href="https://gemini-2.com/G1_EPROM.php" target="_blank">Eprom Programming Sources and Source Code</a></li>
   <li><a href="https://gemini-2.com/usbtoserial.php" target="_blank" title="USB to Serial Converter recomendations">USB to Serial Port converter Recommendations</a></li>
   <li><a href="http://www.docgoerlich.de/L4Features.html" target="_blank">Level 4  Features</a></li>
   <li><a href="https://gemini-2.com/Gemini-1%20mods.php" target="_blank">Recommend Mod to extend battery life</a></li>
   <li class="slast"><a href="https://gemini-2.com/2nd_Communication_Port_Cable.php" target="_blank">2nd Communication Port Cable for Gemini 1</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Windows Only"><!--<![endif]-->ASCOM/USB/GPS
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="Installing_ASCOM.php" target="_blank">Installing ASCOM</a></li>
     <li><a href="Gemini2_drivers/GeminiTelescopeInstaller(1.0.72.0).exe" target="_blank" title="Version (1.0.72.0) supports G11T &amp; G811 + all others">ASCOM-Gemini.net Installer (Version 1.0.72.0)</a></li>
     <li><a href="configuringASCOMfirsttime.php" target="_blank">Setting up ASCOM for first time</a></li>
     <li><a href="Gemini2_drivers/Gemini_Telescope_Net_Installation_and_Operation.pdf" target="_blank">Gemini ASCOM Driver manual</a></li>
     <li><a href="configuringEthernetASCOMdriver.php" target="_blank">Setup ASCOM Ethernet Interface</a></li>
     <li><a href="DCOM-FIX-EXPLAIN.php" target="_blank">DCOM_Fix</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->ASCOM Menu
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/select_Ascom_options.php" target="_blank">How to select the different ASCOM menus</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMSetuppage.php" target="_blank" title="Configure Telescope">Configure Telescope Menu</a></li>
       <li><a href="https://gemini-2.com/configuringASCOMAdvancedSetuppage.php" target="_blank" title="Advanced Gemini Setting">Advanced Gemini Setting</a></li>
       <li class="slast"><a href="https://gemini-2.com/Ascom_park_menu.php" target="_blank">The Park Menu</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/theSkyX_to_Gemini.php" target="_blank">Installing Gemini.net into TheSkyX</a></li>
     <li><a href="https://gemini-2.com/getting-GPS-into-ASCOMdriver.php" target="_blank">Get GPS data into Gemini.net Driver</a></li>
     <li><a href="https://gemini-2.com/scripting_examples.php" target="_blank">Example VB scripts</a></li>
     <li class="slast"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.0.pdf" target="_blank">UPD Protol Specifications</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->USB Related
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/L5-USB/USB_Drivers_for_Level_5_Firmware_after_June-4-2013.zip" target="_blank">Level 5 USB Drivers for Firmware dated Jun 4 2013 and later.</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->For Firmware previous to Jun 4, 2013 USB drivers 
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_32bit_USB_driver.zip" target="_blank">USB - Windows 32 Bit-PreLevel 5</a></li>
       <li><a href="https://gemini-2.com/Gemini2_drivers/Gemini2_64bit_USB_driver.zip" target="_blank">USB Windows 64 Bit -Pre Level5</a></li>
       <li class="slast"><a href="https://gemini-2.com/installing_usb_drivers.php" target="_blank">USB Driver installion Instructions</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/featureport-serialport.php" target="_blank">USB cable for Feature Port</a></li>
     <li class="slast"><a href="https://gemini-2.com/usb-ethernet.php" target="_blank">Alternative to USB Drivers</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/GPS.php" target="_blank">GPS Receivers</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Help&nbsp;Topics
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><a href="https://wiki.gemini-2.com" target="_blank">Gemini 1 &amp; 2 Question and Answer WIKI</a></li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" title="Mount and Misc Manuals"><!--<![endif]-->Manuals
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gemini Programming
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/Gemini2_drivers/UPD_Protocol/Gemini_UDP_Protocol_Specification_1.2.pdf" target="_blank">UDP Protocol's</a></li>
       <li><a href="https://gemini-2.com/web/L5V2_1serial.html" target="_blank">Serial Command Description</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/CGICodes/CGIcodes.pdf" target="_blank">CGI codes</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Losmandy Mounts
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/losmandygoto/Gemini-II_Quick_Start_Guide_2_23b.pdf" target="_blank">Losmandy Gemini 2 Quick Start Guide</a></li>
       <li><a href="http://www.losmandy.com/pdf/gm-8-manual.pdf" target="_blank">Losmandy G8</a></li>
       <li><a href="http://www.losmandy.com/g-11-manual.html" target="_blank">Losmandy G11</a></li>
       <li><a href="http://www.losmandy.com/pdf/titan-instructions.pdf" target="_blank">Losmandy Titan</a></li>
       <li><a href="http://www.losmandy.com/pdf/polar-finder.pdf" target="_blank">Using Losmandy Polar Finder</a></li>
       <li><a href="http://www.gemini-2.com/downloads/pdf/GeminiL4UserManual.pdf" target="_blank">G1 Level 4 Manual</a></li>
       <li><a href="http://losmandy.com/gemini_servo_motor_install.html" target="_blank">Servo Mounting Instructions</a></li>
       <li class="slast"><a href="http://helixgate.net/G11opw.html" target="_blank" title="This is from Helixgate.net by Michael A. Siniscalchi">Assembling  One Piece Worm</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mountain Instruments
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.mi250.com/downloads/MI250%20Go-To%20Manual%202007.pdf" target="_blank">MI-250 Old - 2007 </a></li>
       <li class="slast"><a href="https://www.mi250.com/downloads/MI250%20Manual%202009.pdf" target="_blank">MI-250 New - 2009</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Guiding
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD1
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.rosecityastronomers.org/resources/pdf/GuideToGuiding.pdf" target="_blank">PHD Guiding manual</a></li>
         <li class="slast"><a href="http://www.stark-labs.com/phdguiding.html" target="_blank">PHD Guiding Software</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://openphdguiding.org/" target="_blank">PHD2 Software</a></li>
         <li><a href="http://openphdguiding.org/man/index.html" target="_blank">PHD2 On-Line Manual</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Tools.htm#Guiding_Assistant" target="_blank">Guiding Assistant</a></li>
         <li><a href="https://openphdguiding.org/man-dev/Trouble_shooting.htm" target="_blank">Trouble Shooting</a></li>
         <li class="slast"><a href="https://openphdguiding.org/man-dev/Tools.htm#Star_cross_tool" target="_blank">Star-Cross Tool</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/GPS.php" target="_blank">GPS</a></li>
     <li><a href="https://gemini-2.com/Losmandy-motors.php" target="_blank">ID Losmandy motor types</a></li>
     <li class="slast"><a href="http://screenshots.portforward.com/" target="_blank" title="Screeshots of most routers">Router Screen Shots</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Trouble Shooting
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/troubleshooting.php" target="_blank">Trouble Shooting tips</a></li>
     <li><a href="https://gemini-2.com/error-reporting.php" target="_blank">Reporting Problems</a></li>
     <li class="slast"><a href="https://gemini-2.com/handcontroller_errors.php" target="_blank">Trouble Shooting the touch screen.</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Time Zone Tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/hc/time_zone_offset_chart.php" target="_blank">Time Zone Offset Table for USA</a></li>
     <li class="slast"><a href="https://gemini-2.com/hc/timezonefacts.php" target="_blank">Time Zone Facts</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Tips from other sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank"><!--<![endif]-->G11/Gemini Tips from Mark Crossley
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.wilmslowastro.com/index.htm" target="_blank">Mark Crossley Home page</a></li>
       <li class="slast"><a href="https://www.google.com/search?q=methods+of+doing+polar+alignment+with+EQ+scopes&sourceid=ie7&rls=com.microsoft:en-US:IE-Address&ie=&oe=" target="_blank">Precision Polar Alignment -Astro-Tom.com</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://frazmtn.com/~bwallis/GEMINI_II_docx.pdf" target="_blank">Field Manual from Brad Wallis</a></li>
     <li><a href="http://www.company7.com/library/losmandy/notes.html" target="_blank">Gemini 1 info from Company 7</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://www.michaelherman.net/#!losmandy-g11-mount" target="_blank"><!--<![endif]-->Michael Herman G11 Tips
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/Michael_Herman/RA_Extension_Spacer.pdf" target="_blank">Installing the Partridge RA Extension.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Improving_OPW.pdf" target="_blank">Improving G11 OPW.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Making_7lb_counterweight.pdf" target="_blank">7 LB Counter Weight.pdf</a></li>
       <li><a href="https://gemini-2.com/downloads/Michael_Herman/Polar_Scope_Improvements.pdf" target="_blank">New Rericle in the G11 Polar scope.pdf</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/Michael_Herman/Leveling_Handles.pdf" target="_blank">Leveling handles for Clutch Knobs</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank" title="Posted here till I can find the correct link for it">Titan Tips by Bob Allevo</a></li>
     <li><a href="https://gemini-2.com/downloads/Losmandy_Titan_Reassembly.pdf" target="_blank">Titan Reassembly courtesy of Ed Wily</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=gi3-VeQn7K0" target="_blank">Cable Management U-tube</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment tips
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.sharpcap.co.uk/sharpcap/polar-alignment" target="_blank" title="Polar Alignment">Polar Alignment using SharpCap</a></li>
     <li><a href="http://astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Precision Polar Alignment-Astro-Tom</a></li>
     <li><a href="http://www.astro-baby.com/simplepolar/simple_polar_alignment.htm" target="_blank">Simple Polar Alignment</a></li>
     <li><a href="http://www.themcdonalds.net/richard/index.php?title=Polar_Alignment_of_your_Equatorial_Mount" target="_blank">Polar Alignment of your Equatorial Mount</a></li>
     <li><a href="http://astropixels.com/main/polaralignment.html" target="_blank">Polar Alignment using Drift Method</a></li>
     <li class="slast"><a href="https://www.youtube.com/watch?v=ArU5vC1o1Jk" target="_blank">PHD2 Drift Tool Tutorial</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gearboxs and Mods
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://gemini-2.com/Losmandy_New_Gearbox.php" target="_blank">Losmandy's New Gearbox</a></li>
     <li><a href="https://gemini-2.com/Gearbox_mod.php" target="_blank">Repairing the gearbox used on MI-250 and G11</a></li>
     <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Mclennan Gearbox upgrade
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.horizontalheavens.com/mclennan_gearbox_upgrade.htm" target="_blank">Mclennan Gearbox upgrade by Horizontal Heavens</a></li>
       <li><a href="https://gemini-2.com/Mclennan_Gearboxes.php" target="_blank">Mclennan Gearbox upgrade by Hilmi Al-Kindy</a></li>
       <li class="slast"><a href="http://www.wilmslowastro.com/tips/mclennan_gbox.html" target="_blank">Replacomg the Losmandy Gearbox by Wilmslow Astro on MI-250</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Balancing your mount
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.wilmslowastro.com/tips/g11gemini.htm#balancing" target="_blank" title="Balancing your Mount">Balancing You Mount  by wilmslowastro.com</a></li>
     <li class="slast"><a href="http://starizona.com/acb/ccd/settingupbal.aspx" target="_blank">Balancing your mount by Starizona</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Useful Programs
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Polar Alignment methods
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->2 Star Alignment
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst"><a href="http://www.alignmaster.de" target="_blank">Using 2 Stars with AlignMaster</a></li>
         <li class="slast"><a href="http://www.sharpcap.co.uk/sharpcap" target="_blank">SharpCap for use with Alignmaster</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.astro-tom.com/tips_and_advice/precision_polar_alignment.htm" target="_blank">Polar Alignment from Astro-Tom</a></li>
       <li><a href="http://www.celestialwonders.com/articles/polaralignment/" target="_blank">Polar Alignment Star offset method</a></li>
       <li><a href="http://celestialwonders.com/articles/polaralignment/polaralignmentsurvey.html" target="_blank">Survey of Polar Alignment Methods</a></li>
       <li><a href="http://canburytech.net/DriftAlign/" target="_blank">Understanding Drift Alignment</a></li>
       <li><a href="http://eqalign.net/e_index.html" target="_blank">EQAling</a></li>
       <li><a href="http://www.petesastrophotography.com/" target="_blank">Polar Alignment by Paul Kennett</a></li>
       <li><a href="http://www.andysshotglass.com/DriftAlignment.html" target="_blank">Polar Alignment by Andy's Shot Glass</a></li>
       <li class="slast"><a href="http://www.astrosurf.com/re/polar.html" target="_blank">Polar Alignment by Astrosurf</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Observatory programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.stellarium.org/" target="_blank">Stellarium</a></li>
       <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Gude Programs
        <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
        <ul>
         <li class="sfirst slast"><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank">MetaGude</a></li>
        </ul>
        <!--[if lte IE 6]></td></tr></table></a><![endif]-->
       </li>
       <li><a href="http://www.bytearts.com/stellarium/" target="_blank" title="Make Stellarium ASCOM compatible for Windows">StellariumScope</a></li>
       <li><a href="http://www.ap-i.net/skychart/" target="_blank">SkyChart / Cartes du Ciel</a></li>
       <li><a href="http://zytratechnologies.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank">Setting up Stellarium</a></li>
       <li><a href="http://sourceforge.net/p/astrotortilla/home/Home/" target="_blank">AstroTortilla Astrophotography assistant</a></li>
       <li class="slast"><a href="http://lightvortexastronomy.blogspot.com/2013/08/tutorial-imaging-setting-up-and-using.html" target="_blank">Plate Solving with Astrotortilla</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Misc Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://darkhorizons.emissionline.com/GMB/gmb.htm" target="_blank">Gemini Model Builder</a></li>
       <li><a href="http://www.nirsoft.net/utils/usb_devices_view.html" target="_blank">View USB Port assignments </a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip FIle archiver use to zip and unzip all files on this site</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Disk and Partition Programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://www.sdcard.org/downloads/formatter_4/" target="_blank">Micro SDcard Formatter</a></li>
       <li><a href="http://www.partitionwizard.com/" target="_blank">MiniTool Partition Wizard</a></li>
       <li class="slast"><a href="http://www.7-zip.org/" target="_blank">7-Zip</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs for Windows
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://filezilla-project.org/download.php?type=client" target="_blank">FileZilla</a></li>
       <li><a href="http://www.wsftple.com/download.aspx" target="_blank">WS_FTP LE (V12)</a></li>
       <li><a href="http://www.oldversion.com/WS_FTP_Limited_Edition.html" target="_blank">WS_FTP V6</a></li>
       <li class="slast"><a href="http://winscp.net/eng/index.php" target="_blank">WinSCP</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->FTP Programs For Mac
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.kekaosx.com/en/" target="_blank">Keka (7zip ported to OS X)</a></li>
       <li><a href="http://www.apple.com/downloads/macosx/internet_utilities/classicftpformac.html" target="_blank">Classic FTP</a></li>
       <li><a href="http://fetchsoftworks.com/">Fetch FTP</a></li>
       <li><a href="http://www.macorchard.com/filetransfer/" target="_blank">List of Many Mac FTP</a></li>
       <li class="slast"><a href="http://blog.hostilefork.com/trashes-fseventsd-and-spotlight-v100/" target="_blank">Hidden Files A MAC puts on the SDcard</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->GPS Related programs
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://gemini-2.com/downloads/GPSrelated/redirect.zip" target="_blank">GPS_Port_Director (No install necessary)</a></li>
       <li class="slast"><a href="https://gemini-2.com/downloads/GPSrelated/VisualGPSInstall.zip" target="_blank">Visual GPS Installer</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Network Scanners
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.softperfect.com/products/networkscanner/" target="_blank">Softperfect Network Scanner</a></li>
       <li><a href="http://www.radmin.com/products/ipscanner/" target="_blank">Advanced IP Scaner</a></li>
       <li class="slast"><a href="http://free-ip-scanner.eusing-software.qarchive.org/" target="_blank">Free IP Scanner</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li class="slast"><a href="downloads/USV_View/usbdeview.zip" target="_blank">USB View - USB port scanner</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Power Controllers
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.digital-loggers.com/ac.html" target="_blank">AC Controlled Relay</a></li>
     <li><a href="http://www.digital-loggers.com/lpc7.html" target="_blank">Web Power Switch</a></li>
     <li class="slast"><a href="http://www.digital-loggers.com/EPCR5.html" target="_blank">Ethernet Power Controller 5</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
 <li class="tlast"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Favorites
  <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
  <ul>
   <li class="sfirst"><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->User Groups
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="https://groups.io/g/Gemini-II/" target="_blank">Gemini-II at groups.io</a></li>
     <li><a href="https://groups.io/g/Gemini_users/" target="_blank">Gemini User Group at Groups.io</a></li>
     <li><a href="https://groups.io/g/Losmandy_users/" target="_blank">Losmandy User Group at Groups.io</a></li>
     <li><a href="http://groups.yahoo.com/neo/groups/Titan_Mount/info" target="_blank">Titian User Group</a></li>
     <li><a href="https://groups.io/g/MI-250/" target="_blank">MI-250 Users Group</a></li>
     <li><a href="https://groups.io/g/Gemini_ASCOM_Driver/" target="_blank">Gemini Ascom Driver Group at Groups.io</a></li>
     <li class="slast"><a href="http://groups.yahoo.com/neo/groups/ASCOM-Talk/info" target="_blank">Ascom Talk Group</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->Web Sites
    <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
    <ul>
     <li class="sfirst"><a href="http://www.docgoerlich.de/Gemini.html" target="_blank">René Görlich's Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="http://losmandy.com" target="_blank"><!--<![endif]-->Losmand Links -Web Site
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.losmandy.com/eq-mounts.html" target="_blank">Equatorial Mounts</a></li>
       <li><a href="http://www.losmandy.com/secondary.html" target="_blank">D Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/v-series.html" target="_blank">Y Series Dovetail Systems</a></li>
       <li><a href="http://www.losmandy.com/losmandygoto/gemini2.html" target="_blank">Gemini 2 Goto Syste,</a></li>
       <li><a href="http://www.losmandy.com/starlapse.html" target="_blank">StarLapse System</a></li>
       <li><a href="http://www.losmandy.com/access.html" target="_blank">Telescope Accessories</a></li>
       <li><a href="http://www.losmandy.com/replacement.html" target="_blank">Replacement parts</a></li>
       <li><a href="http://www.losmandy.com/distributors.html" target="_blank">Dealers</a></li>
       <li><a href="http://www.losmandy.com/pricelist.html" target="_blank">Price List</a></li>
       <li><a href="http://www.losmandy.com/support.html" target="_blank">Technical Support</a></li>
       <li><a href="http://store.losmandy.com/">Ordering inside USA</a></li>
       <li><a href="https://secure28.securewebsession.com/losmandy.com/order.shtml" target="_blank">Ording International or custom parts</a></li>
       <li><a href="http://www.losmandy.com/whatsnew.html" target="_blank">Whats New</a></li>
       <li class="slast"><a href="https://www.valvoline.com/en-ecuador/our-products/grease/durablend-synthetic-blend-grease" target="_blank">Recommend Grease by Losmandy</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="https://www.mi250.com/" target="_blank">MI-250 Web Site</a></li>
     <li><a href="https://www.arizonaskys.com" target="_blank">ArizonaSkys (my obsevatory web site - under construction</a></li>
     <li><a href="http://www.ascom-standards.org/index.htm" target="_blank">Ascom Standards Org</a></li>
     <li><a href="https://www.nightskiesnetwork.ca/" target="_blank" title=" worldwide astronomy broadcast site">Night Skys Network</a></li>
     <li><a href="http://www.wilmslowastro.com/tips/g11gemini.htm" target="_blank">Wilmslow Astro G11 tips</a></li>
     <li><a href="http://astronomy.tools" target="_blank">Astronomy Tools - Calculators - FOV - Star Charts</a></li>
     <li><a href="http://www.skippysky.com.au/" target="_blank">SkippySky Astro-Weather Forcast</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#" target="_blank"><!--<![endif]-->Tuning the G11
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="http://www.astromaster.org/esperienze_file/G11maintenance_e.htm" target="_blank">Maintain and tune a G11 mount</a></li>
       <li class="slast"><a href="http://www.astro.uni-bonn.de/~mischa/mounts/g11_tuning.html" target="_blank">Tuning a G11- for 2000 or older mounts</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://garriou.didier.free.fr/astro/gemini_anglais.html" target="_blank">Didier Garriou Gemini Catalogs building site</a></li>
     <li><a href="https://gemini-2.com/downloads/TitanTipsByBobAllevo.pdf" target="_blank">Titan Tips by Bob Allevo</a></li>
     <li><a href="http://www.stargps.ca/" target="_blank">Star GPS Web Site</a></li>
     <li><!--[if IE]><!--><a class="ajxsub" href="#"><!--<![endif]-->PHD2
      <!--[if gt IE 6]><!--></a><!--<![endif]--><!--[if lte IE 6]><table><tr><td><![endif]-->
      <ul>
       <li class="sfirst"><a href="https://openphdguiding.org/" target="_blank">PHD2 Home</a></li>
       <li><a href="https://code.google.com/p/open-phd-guiding/wiki/DriftAlignmentWithPHD2" target="_blank">Open-phd-guiding</a></li>
       <li><a href="https://groups.google.com/forum/#!forum/open-phd-guiding" target="_blank">Discussion Group </a></li>
       <li class="slast"><a href="https://www.youtube.com/watch?v=LXFGRta98rs" target="_blank">Introduction to optimal auto - guiding: How to get the most from your set - up</a></li>
      </ul>
      <!--[if lte IE 6]></td></tr></table></a><![endif]-->
     </li>
     <li><a href="http://www.sharpcap.co.uk/" target="_blank">SharpCap</a></li>
     <li class="slast"><a href="https://sites.google.com/site/astropipp/" target="_blank">Planetary Imaging Software</a></li>
    </ul>
    <!--[if lte IE 6]></td></tr></table></a><![endif]-->
   </li>
   <li class="slast"><a href="https://gemini-2.com/all-links.php" target="_blank">300+ Astronomy Links</a></li>
  </ul>
  <!--[if lte IE 6]></td></tr></table></a><![endif]-->
 </li>
</ul>
 <br >
</div>

</body>



<style type="text/css">
.auto-style1 {
	font-size: small;
}
</style>

<link href="/gemini-2.css" rel="stylesheet" type="text/css" />


</head>

<body style="color: #FFFFFF; background-color: #000000">


<p class="h2"> 350+&nbsp; Astronomy Related Links and Growing
<br /> 
All links should open in a new window

</p>
<table class="style9" cellpadding="2" style="height: 2px; width: 950px" align="center">
	<tr>
		<td style="width: 475px" class="style6wborder">
		<div class="h2">Manufactures</div>
<!--<p align="left" class="style6">-->
<div align="left" class="style6">


<!--<br /><a href="http://colfaxtactical.com/" target="_blank" rel="nofollow">Colfax Tactical - 
Previously Moutain Instruments </a>-->
<a href="http://www.losmandy.com/" target="_blank" rel="nofollow">Losmandy Astronomical Products</a>
<br /><a href="http://www.docgoerlich.de/Gemini.html" target="_blank" rel="nofollow">René Görlich's Gemini Telescope Positioning System's</a>
<br /><a href="http://www.admaccessories.com/" target="_blank" rel="nofollow">ADM Rings &amp; DoveTail Saddles</a>
<br /><a href="http://www.auroraeurotech.com/CloudSensor.php" target="_blank" rel="nofollow">Aurora Eurotech Cloud Sensor</a>
<br /><a href="http://www.advancedtelescope.com" target="_blank" rel="nofollow">Advanced Telescope Systems - Piers</a>
<br /><a href="http://www.apogeeinc.com" target="_blank" rel="nofollow">Apogeeinc Telescope Accessories</a>
<br /><a href="http://www.astrogene1000.com/" target="_blank" rel="nofollow">Astrogene1000.com Astronomy Products</a>
<br /><a href="http://www.astronomik.com/en/" target="_blank" rel="nofollow">Astronomik Optical Filters</a>
<!--<br /><a href="http://astrosky.homestead.com" target="_blank" rel="nofollow">Astrosky Truss Dobsonian Telescopes and Piers</a>-->
<br /><a href="http://www.astronomics.com" target="_blank" rel="nofollow">Astronomics</a>
	<br /><a href="http://astrodevices.net/" target="_blank">Astro Devices</a> Very Large EQ Drive System
<br /><a href="http://www.astro-physics.com/" target="_blank" rel="nofollow">Astro-Physics Mounts</a>
<br /><a href="http://www.astro-electronic.de/" target="_blank" rel="nofollow">Astro Electronic FS2 Mount Drive German only</a> 
<br /><a href="http://www.astrosysteme.at/eng/hot.html" target="_blank" rel="nofollow">ASA Direct Drive Mount</a>
<br /><a href="http://www.atik-cameras.com/" target="_blank" rel="nofollow">ATIK Camera</a>
<br /><a href="http://www.avalon-instruments.com/" target="_blank">Avalon Instruments</a>
<!--<br /><a href="http://www.bbastrodesigns.com/BBAstroDesigns.html" target="_blank" rel="nofollow">BBAstroDesigns</a>-->
<br /><a href="http://www.brainboxes.com/" target="_blank" rel="nofollow">brainboxes - Serial Ports of all kinds</a><br />
	<a href="http://blueastro.se" target="_blank">BlueAstro</a> Remote Control 
	USB Hub
<br /><a href="http://www.burgessoptical.com/" target="_blank" rel="nofollow">Burgess Optical</a>
<br /><a href="http://www.cablewholesale.com" target="_blank" rel="nofollow">CableWholesale - Source of HC cable for G1</a>
<br /><a href="http://www.celestron.com" target="_blank" rel="nofollow">Celestron -- Homepage</a>
<br /><a href="http://www.comtrol.co.uk/"  target="_blank" rel="nofollow">Comtrol</a> Ethernet and more
<br /><a href="http://www.deepspaceproducts.com" target="_blank" rel="nofollow">Deep Space products</a>Tuning and 10Micron mounts
<br /><a href="http://www.dewbuster.com/" target="_blank" rel="nofollow">DewBuster Controller</a>
<br /><a href="http://www.digi.com"  target="_blank" rel="nofollow">Digi International - AnywhereUSB</a>
<br />
	<a href="http://www.digital-loggers.com/ac.html" target="_blank">Digital Loggers</a> AC Controlled Relay 
<br />
	<a href="http://www.digital-loggers.com/lpc7.html" target="_blank">Digital Loggers</a> Web Controlled Power Switch 7 
<br />
	<a href="http://www.digital-loggers.com/EPCR5.html" target="_blank">Digital Loggers</a> Ethernet Power Controller 5 
<br /><a href="http://www.discmounts.com" target="_blank" rel="nofollow">DiscMounts Home</a>
<br /><a href="http://www.domeobservatory.com/" target="_blank" rel="nofollow">Durango Skys Dome and Roll-Offs</a>
<br /><a href="http://www.durhamradio.com/pyramid-cb-base-ps12-ps14-ps26-ps36-station-power-supply-supplies.html" target="_blank" rel="nofollow" title="Heavy Duty Power supplies">Durham Radio Power Supplies</a>
<br />
	<a href="http://www.easysync-ltd.com" target="_blank">EasySync Adapters </a>
	USB/RS232/ETHERNET
<br /><a href="http://industrialcomponent.com/baaske/ethernet-isolation.html" target="_blank" rel="nofollow">Ethernet Power Isolation</a>
<br /><a href="http://edbyersco.com/">Edward R. Byers</a> makers of the finest mounts.
<br /><a href="http://www.explorescientific.com/" target="_blank" rel="nofollow">Explore Scientific Telescopes</a>
<br /><a href="http://www.explora-dome.com/" target="_blank" rel="nofollow">ExploraDome</a>
<br /><a href="http://www.farpointastro.com" target="_blank" rel="nofollow">Farpoint Astro Products - Dovetails More</a>
<br />	<a href="http://www.optecinc.com/astronomy/catalog/focuslynx/focuslynx.htm" target="_blank">FocusLync Focuser Hub</a> - Dual Focuser 
	by Optec
<br /><a href="http://www.gefen.com" target="_blank" rel="nofollow">Gefen Corp USB Extenders</a>
<br /><a href="http://www.gerdneumann.net/english/home" target="_blank" rel="nofollow" title="Design, development and production of precision mechanical and optical Instruments">Gerd Neumann Astronomical Instruments</a>
<br /><a href="http://www.hubbleoptics.com/artificial-stars.html" target="_blank" rel="nofollow">Hubble Optics</a>&nbsp; 5 Star Artificial Star
<br /><a href="http://www.moxa.com/"  target="_blank" rel="nofollow">MOXA--Solutions for Device Networking</a>
<br /><a href="http://firgelliauto.com/default.php?cPath=104" target="_blank" rel="nofollow" title="Track actuators for Roofs???">FirGelli Automation Track Actuator</a>
<br /><a href="http://www.globalplastics.ca" target="_blank" rel="nofollow">Global Plastics Services</a>
<br /><a href="http://www.highpointscientific.com/" target="_blank">High Point Scientific</a>
<br /><a href="http://www.hotechusa.com/category-s/23.htm" target="_blank" rel="nofollow">Hotech CT Laser Collinmator</a>
<br /><a href="http://www.hotechusa.com" target="_blank" rel="nofollow">Hotech OptoElectronic Accessories</a><br />
<a href="http://www.sciencecenter.net/hutech/index.htm" target="_blank" rel="nofollow">Hutech Borg</a>
<br /><a href="http://www.icron.com/" target="_blank" rel="nofollow">Icron Technologies - USB Extension</a>
<br /><a href="http://ioptron.com" target="_blank" rel="nofollow">iOptron</a> 
<!-- <br /><a href="http://www.lumicon.com" target="_blank" rel="nofollow" title="Telescope Filters and much more">LUMICON Astronomical Accessories</a>-->
<br /><a href="http://www.keterex.com/kxusb150.php" target="_blank" rel="nofollow" title="This is  a link to the Full Speed USB Isolator, USB-150 by Keterex Systems ">Keterex -Maker of the USB Isolator</a>
<br /><a href="http://www.olimex.com/dev/usb-iso.html" target="_blank" rel="nofollow">USB-Iso USB Isolator</a>
<br /><a href="http://www.startech.com/Cards-Adapters/Serial-Cards-Adapters/1-Port-FTDI-USB-to-Serial-RS232-Adapter-Cable-with-Optical-Isolation~ICUSB2321FIS" target="_blank" rel="nofollow">StarTech USB to RS232 optical Isolated adapter</a>
<!--<br /><a href="http://www.l-com" target="_blank" rel="nofollow">L-Com -  Cables and more</a>-->
<br /><a href="http://luntsolarsystems.com/site/" target="_blank" rel="nofollow">Lunt Solar Systems-Solar telescopes</a>
<br /><a href="http://www.mcintoshlabs.com/"target="_blank" rel="nofollow">McIntosh Labs - Home Theater Systems</a>
<br /><a href="http://www.mallincam.net/" target="_blank" rel="nofollow" title="Astronomical Video CCD camera">Mallincam Astronomical Video CCD camera</a>
<br /><a href="http://www.meade.com" target="_blank" rel="nofollow">Meade Telescopes</a>
<br /><a href="http://www.mda-telescoop.com/" target="_blank" rel="nofollow">MDA TelesCoop Ltd - Tracking System</a>
<br /><a href="http://moggadapters.com/astro/adapter.asp" target="_blank" rel="nofollow" title="Make all kind of Web cam adapters">Mogg Adapers- Web Cam Adapters</a>
<br /> <a href="https://www.monoprice.com/product?p_id=16377" target="_blank">Monoprice</a> 10m to 50M USB3.0 using Optical 
<br /><a href="http://www.optcorp.com/" target="_blank" rel="nofollow">Oceanside Photo &amp; Telescope</a>
<br /><a href="http://stores.ebay.ca/BJOMEJAG-EBUYER-STORE/Astronomical-FIlters-/_i.html?rt=nc&amp;_fsub=2&amp;_sid=8343593&amp;_trksid=p4634.c0.m14.l1581&amp;_pgn=1" target="_blank" rel="nofollow">Omega Optical Filters on Ebay</a>
<br /><a href="http://www.omegafilters.com/" target="_blank" rel="nofollow">Omega Optical Web site</a>
<br /><a href="http://www.onlinemetals.com" target="_blank" rel="nofollow">OnlineMetals.com - Online Metal Supply</a>
<br /> <a href="http://opticstarnorthamerica.com/" target="_blank" rel="nofollow">OpticStarNorthAmerica for Video Deep Space</a>
<br /><a href="http://www.optecinc.com" target="_blank" rel="nofollow">Optec Inc.</a>
<br /><a href="http://www.ozlasers.com/" target="_blank">OZ Lasers in Australia</a> 
<br /> <a href="http://www.gpi-encoders.com/" target="_blank" rel="nofollow">Gurley Precision Encoders</a>
<br /> <a href="http://www.renishaw.com" target="_blank" rel="nofollow">Renishaw Optical angle encoders</a>
<br /><a href="http://www.rw-america.com/products/miniature_couplings/mk1/" target="_blank" rel="nofollow">R+W Coupling Technology</a> - Replacement for Oldham Coupler
<br /><a href="http://www.telescope.com" target="_blank" rel="nofollow">Orion Telescopes and Binoculars</a>
<br /><a href="http://www.parallaxinstruments.com/index.html" target="_blank" rel="nofollow">Parallax 	Instruments Inc.</a>
<br /><a href="http://www.bisque.com/sc/pages/Paramount-ME.aspx" target="_blank" rel="nofollow">Paramount-ME Mount</a>
<!--<br /><a href="http://www.pwtec.com" target="_blank" rel="nofollow">Particle Wave Technologies</a> -->
<br /><a href="http://www.pier-tech.com/"target="_blank" rel="nofollow">Pier Tech Inc</a>
<!--<br /><a href="http://www.pwtec.com" target="_blank" rel="nofollow">Pinnacle pier</a> -->
<br /><a href="http://planewave.com/" target="_blank" rel="nofollow">Planewave Instruments</a>
	<br /><a href="http://plugable.com" target="_blank">Plugable Technologies</a>&nbsp; 
	USB to Everything adapters<br />
<a href="http://www.powerstream.com/" target="_blank" rel="nofollow">PowerStream </a>- Power Supplies

<br /><a href="http://www.qhyccd.com" target="_blank" rel="nofollow">QHYCCD Cameras</a>
<br /><a href="http://www.ritzcamera.com/webapp/wcs/stores/servlet/SearchView?storeId=10001&amp;catalogId=10001&amp;langId=-1&amp;keyword=Pyramid+power+supply&amp;x=0&amp;y=0" target="_blank" rel="nofollow" title="Best prices on Pyranid Power Supplies">Pyramid Power Supply From RitzCamera</a>
<br /><a href="http://www.qsimaging.com/" target="_blank" rel="nofollow">QSI Scientific Grade CCD Cameras</a>
<br /><a href="http://www.ruland.com/ps_couplings_bellows.asp" target="_blank" rel="nofollow">Ruland Shaft Coupling</a> - Replacement for Oldham Couplers
<br /><a href="http://www.scopestuff.com" target="_blank" rel="nofollow">ScopeStuff</a>
<!--<br /><a href="http://www.rcopticalsystems.com" target="_blank" rel="nofollow">RC Optical Systems</a>-->
<br /><a href="http://sbig.com/" target="_blank" rel="nofollow">SBIG Astronomical Instruments</a>
<br /><a href="http://www.scopeguard.com/" target="_blank" rel="nofollow">ScopeGuard mount cases
</a>
<br /><a href="http://www.store.shoestringastronomy.com" target="_blank" >Shoestring Astronomy</a>
<br /><a href="http://www.siderealtechnology.com/" target="_blank" rel="nofollow">Sidereal Technology</a>
<br />
	<a href="http://www.silexamerica.com/products/connectivity-solutions/device-networking/usb-parallel-connectivity/ds-600/" target="_blank">Silex 
	DS600 Gigibit Ethernet to USB 3.0 Converter</a><br /><a href="http://www.siriusobservatories.com/" target="_blank" rel="nofollow">Sirius Observatories</a>
<br /><a href="http://www.unihedron.com" target="_blank" rel="nofollow">Sky Quality Meter by Unihedron</a>
</div>
</td>

<td class="style6wborder">
<div class="h2">Manufactures Continued</div> 
<div align="left" class="style6">

<br />
	<a href="http://www.skyshed.com/" target="_blank" rel="nofollow" >Skyshed Plans, Kits</a>
<br /><a href="http://www.skyshedpod.com/" target="_blank" rel="nofollow">Skyshed Pod</a>
<br /><a href="http://www.astrometric.com" target="_blank" rel="nofollow">SkyWalker by Astrometic Instruments</a>
<br /><a href="http://www.skywatchertelescope.net" target="_blank" rel="nofollow">Sky-Watcher</a>
<br /><a href="http://starizona.com/" target="_blank" rel="nofollow">Starizona - Home of the Hyperstar</a>
<br /><a href="https://starizona.com/tutorial/hyperstar-specifications/">Starizona Hyperstar Specifications</a>
<br /><a href="http://www.stargps.ca" target="_blank" rel="nofollow">Star GPS - Recommend GPS receiver for Gemini</a>
<br /><a href="http://www.starlightinstruments.com" target="_blank" rel="nofollow">Starlight Instruments-Feather Touch Focuser</a>
<br /><a href="http://www.sxccd.com" target="_blank" rel="nofollow">Starlight-Xpress Camera's</a>
<br /><a href="http://www.startech.com/" target="_blank" rel="nofollow">StarTech Electronic adapters</a>
<br /><a href="http://stellarmasses.com/t/losmandy" target="_blank">Stellar Masses</a> Stainless Steel Counter weights
<br /><a href="http://www.stellarcat.com/" target="_blank" rel="nofollow">ServoCat Goto Controller by StellarCat</a> 
<br /><a href="http://www.stellarvue.com" target="_blank" rel="nofollow">Stellarvue Telescopes and Accessories</a>
<br /><a href="http://www.telegizmos.com/" target="_blank" rel="nofollow">Telegizmos Solar Scope Cover</a>
<br /><a href="http://cncsupplyinc.com/" target="_blank" rel="nofollow">TelescopesAdapters.com</a>
<br /><a href="http://www.mda-telescoop.com" target="_blank" rel="nofollow" >Telescope Guide Master</a>
<br /><a href="http://www.thousandoaksoptical.com/" target="_blank" rel="nofollow" >Thousand Oaks Optical Solar Filters</a>
<br /><a href="http://www.tmboptical.com/" target="_blank" rel="nofollow" title="Thomas Beck Telescopes ">TMB Optical</a> 
<br /><a href="http://www.unitek-products.com/" target="_blank"  rel="nofollow" >UNITEK USB and Ethernet adapters</a>
<br /><a href="http://www.usdigital.com" target="_blank" rel="nofollow">US Digital - Encoders for Losmandy Motors</a>
<br /><a href="http://vpi.us/" target="_blank" rel="nofollow">VPI - Video Products and cables</a>
<br /><a href="http://www.williamoptics.com" target="_blank" rel="nofollow">William Optics USA</a>
<br /><a href="http://www.zengine.ho8.com/" rel="nofollow" target="_blank">Zengineering - MallinCam Cables and more</a>
<br />Electroluminescent Panels
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.luminousfilm.com/" target="_blank" rel="nofollow">Luminous Film</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.adorama.com/searchsite/default.aspx?searchinfo=rosco%20white" target="_blank" rel="nofollow">Adorama Camera 
Plastic Panels</a>
<br />Encoders
<br />&nbsp;&nbsp;&nbsp; <a href="http://www.gpi-encoders.com/" target="_blank" rel="nofollow">Gurley Precision Instruments Encoders</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.renishaw.com/en/1030.aspx" target="_blank" rel="nofollow">Renishaw Absolute Encoders</a> 

</div>

<hr class="style2" />
<div class="h2">Dealers</div>

<div align="left" class="style6">
<a href="http://www.adorama.com" target="_blank" >Adorama Camera (No Telescopes)</a>
<br /><a href="http://www.astrovid.com" target="_blank" rel="nofollow">Adirondack Video Astronomy</a>
<!--<br /><a href="http://www.buytelescopes.com">Anacortes Telescope & Wild Bird</a>-->
<br /><a href="http://www.alpineastro.com/"  target="_blank" rel="nofollow">Alpine Astronomical</a>
<br /><a href="http://www.apm-telescopes.de/index.php" target="_blank" rel="nofollow">APM Telescopes</a>
<br /><a href="http://www.astronomics.com" target="_blank" rel="nofollow">Astronomics.com</a>
<br /><a href="http://www.surveillance-video.com/astronomy-sept-2009.html" target="_blank" rel="nofollow">Astronomy Resources</a>
<br /><a href="http://www.bestbuycable.com" target="_blank" rel="nofollow">BestBuyCable</a>
<br /><a href="http://www.bhphotovideo.com"  target="_blank" rel="nofollow">B & H Photo</a>
<br /><a href="http://www.binoculars.com"  target="_blank" rel="nofollow">Binoculars.com</a>
<br /><a href="http://www.bttechnologies.com"  target="_blank" rel="nofollow">BT Technologies</a>
<br /><a href="http://www.cnmfg.com" target="_blank" rel="nofollow">C&N Footlockers</a>
<br />
	<a href="http://carbon12astro.com/" target="_blank" title="Losmandy and Southern Stars dealers">Carbon 12 AstroSystems</a><br /><a href="https://www.cablewholesale.com/index.htm" target="_blank" rel="nofollow">Cables Wholesale - all kinds of cables</a>
<br /><a href="http://www.catseyecollimation.com" target="_blank" rel="nofollow">CATSPERCH</a>
<br /><a href="http://www.clementfocuser.com/pages/1/index.htm"  target="_blank" rel="nofollow">Clement Focuser</a>&nbsp;
<br />
	<a href="https://cnc-specialty-store.com/rs232-cables/rs232-optical-isolation-transceiver-protect-pc-isolator?gclid=CNaSqorI2dACFdgMgQod65QAXw" target="_blank">
	CNC Specialty Store</a> RS232 Optical Isolation
<!--<br />	<a href="http://www.cordsplus.com/" target="_blank" rel="nofollow">Cords Plus</a>-->
<br /><a href="http://www.company7.com/losmandy/index.html" target="_blank" rel="nofollow">Company Seven</a>

<br /><a href="http://www.dew-not.com/" target="_blank" rel="nofollow">Dew-Not</a>
<br /><a href="http://www.deepspaceproducts.com" target="_blank" rel="nofollow">Deep Space Products - Mount Accessories</a>
<br /><a href="http://www.edmundoptics.com/" target="_blank" >Edmund Optics</a>
<br /><a href="http://www.explorescientific.com/" target="_blank" rel="nofollow">Explore Scientific Telescopes</a>
<br /><a href="http://www.handsonoptics.com"  target="_blank" rel="nofollow">Hands on Optics</a>
<br />
<a href="http://www.hobbyking.com/hobbyking/store/__467__408__Battery_Chargers_Acc_-Power_Supply.html" target="_blank" rel="nofollow">HobbyKing - Power Supplies</a>
<br /><a href="http://www.highpointscientific.com/" target="_blank">High Point Scientific</a>
<br /><a href="http://www.iankingimaging.com" target="_blank" rel="nofollow">Ian King Imaging</a>
<br />
<a href="http://www.mallincamusa.com" target="_blank" rel="nofollow" title="Dealer for MellinCam Video camera in USA">Jack's Astro Acc. MallinCam USA</a>
<br /><a href="http://www.jmitelescopes.com/" target="_blank" >JMI Telescopes</a>
<br /><a href="http://www.kendrickastro.com" target="_blank" >Kendrick Astro Instruments</a>
<br /><a href="http://www.khanscope.com" target="_blank" rel="nofollow">KHAN Scope Centre</a>
<br />
<a href="http://www.microfasteners.com/" target="_blank" rel="nofollow">Micro Fasteners - 
Hobbyists Source</a><br /><a href="http://www.focuser.com" target="_blank" >MoonLite Telescope Accessories</a>
<br />
<a href="http://www.suppliesoutlet.com" target="_blank" rel="nofollow" title="Good prices on remanufactured Ink and Laser cartridges">Office printer supplies</a>
<br /><a href="http://www.oneilphoto.on.ca" target="_blank" >O'Neil Optical</a>
<br /><a href="http://www.optcorp.com"  target="_blank" rel="nofollow">Oceanside Photo & Telescope</a>
<br /><a href="http://www.mars-cam.com/optical.html"  target="_blank" rel="nofollow">Optical Division of Marshall Electronics</a>
<br /><a href="http://www.telescope.com" target="_blank" >Orion Telescopes and Binoculars</a>
<br /><a href="https://powerwerx.com/anderson-power-powerpole-sb-connectors" target="_blank">Powerwerx</a> supplier of Anderson PowerPole Connectors<br />
	<a href="http://scopecity.com"  target="_blank" rel="nofollow">Scope City</a>
<br /><a href="http://www.scopestuff.com"  target="_blank" rel="nofollow">ScopeStuff</a>
<br /><a href="http://www.scopetronics.com" target="_blank" >ScopeTronix</a>
<br />
	<a href="http://store.smartastronomy.com" target="_blank" title="Observing Tents, Chairs, StarParty Accessories">Smart Astronomy Accessories</a>
<br /><a href="http://starizona.com"  target="_blank" rel="nofollow">Starizona</a>
<br /><a href="http://www.serialgear.com/"  target="_blank" rel="nofollow">Serial Gear USB adapters</a>
<br />
<a href="http://www.usbgear.com" target="_blank" title="search for: &quot;2.0 Over IP Network&quot; to see USB over Network devices">USBGear.com - IP to USB</a>
<br /><a href="http://takahashiamerica.com" target="_blank" >Takahashi America</a>
<br /><a href="http://www.telescopeadapters.com/" target="_blank" rel="nofollow">Telescope to camera adapters</a>
<br /><a href="http://www.telescopebluebook.com" target="_blank" >Telescope Bluebook</a>
<br /><a href="http://www.telescope-service.com" target="_blank" >Telescope-Service and accessories</a>
<br /><a href="http://www.telescopes-astronomy.com.au" target="_blank" >Telescopes and Astronomy</a>
<br /><a href="http://www.thomasnet.com/products/telescopes-84092204-1.html" target="_blank" rel="nofollow">Telescope suppliers listed on ThomasNet</a>
<br /><a href="https://www.teleskop-express.de/shop/index.php" target="_blank" rel="nofollow">Teleskop-Service</a>
<br /><a href="http://www.usb-cable.com/" target="_blank" >usb cables - All kinds</a>

<!--<br /><a href="http://www.tetontelescope.com/" target="_blank" rel="nofollow">Teton Telescope</a>-->
<br /><a href="http://www.universalastronomics.com/"  target="_blank" rel="nofollow">Universal Astronomics</a>
<br /><a href="http://store.xtremegadget.com/"  target="_blank" rel="nofollow">Xtreme Gadget.com.</a>
<br />
<a href="http://www.zantechdirect.com.au/index.php/" target="_blank" rel="nofollow" title="Web based Power and Wifi Wireless USB">ZanTecn Network Products</a><br />
<br /></div>
</td>
</tr>
</table>

<table class="style9" cellpadding="2" style="height: 2px; width: 950px" align="center">
	<tr>
		<td style="width: 475px" class="style6wborder">
		<div class="h2">Software Commercial</div>
<div align="left" class="style6">

<!-- Software Commerical 14 Links -->
<a href="http://www.dposoft.net/" target="_blank" rel="nofollow">Abstradome -HHD repair software</a>
<br /><a href="http://noeld.com/programs.asp?cat=video" target="_blank" rel="nofollow" title="Microsoft compatible Video Capture and preview application">AmCap Video 
Capture and preview</a>
<br /><a href="http://backyardeos.com/" target="_blank">Backyard EOS Astrophotography software</a>
<br /><a href="http://www.cloudynights.com/item.php?item_id=2464" target="_blank" rel="nofollow">CN Writeup about mallincan VSS</a>
<br /><a href="http://www.nchsoftware.com/capture/index.html" target="_blank" rel="nofollow">Debut Video Capture Software</a>
<br /><a href="http://www.dc3.com" target="_blank" rel="nofollow">DC-3 Dreams ACP Control Program</a>
<br /><a href="http://pinpoint.dc3.com/" target="_blank" rel="nofollow">DC-3 Dreams - PinPoint</a>
<br /><a href="http://ccdcommander.com/" target="_blank" rel="nofollow">CCD Commander</a>
<br /><a href="http://www.nchsoftware.com/capture/index.html" target="_blank" rel="nofollow" >Debut Video Capture Software</a>
<br /><a href="http://www.deepsky2000.com/buyit.htm" target="_blank">DeepSky 
	Astronomy Software</a>
<br /><a href="http://www.deepskyimaging.net/" target="_blank" rel="nofollow" title="Capture Software for use with MallinCam Video Software">DeepSky Imaging</a>
<br /><a href="http://www.deepskyimaging.net/" target="_blank" rel="nofollow" title="New Version now available">DeepSky Software and DeepSkyImaging</a>
<br /><a href="http://www.cyanogen.com" target="_blank" rel="nofollow">Diffraction Limited - MaximDL</a>
<br /><a href="http://www.nova-astro.com" target="_blank" rel="nofollow">Earth Centered Universe</a>
<br /><a href="http://gpsgate.com/products/gpsgate_client" target="_blank" rel="nofollow" title="Share GPS between applications">GPS Gate - Share GPS</a>
<br /><a 
<br /><a href="http://www.ccdware.com/" target="_blank" rel="nofollow">CCDWare CCD AutoPilot, Inspector, Navigator</a>
<br /><a href="http://www.ccdware.com/" target="_blank" rel="nofollow">CCDWare CCD Stack</a>
<br /><a href="http://www.cyanogen.com/" target="_blank" rel="nofollow">Diffraction Limited - MaximDL</a>
<br /><a href="http://astroshed.com/fitsplug/fitsplug.htm" target="_blank" rel="nofollow">FitsPlug Plugin for CS4</a>
<br /><a href="http://www.mlunsold.com/" target="_blank" rel="nofollow">Images Plus</a>
<br />
	<a href="http://www.mainsequencesoftware.com/Products/SGPro" rel="nofollow" target="_blank">Main Sequence - Sequence Generator Pro</a>
<br /><a href="http://www.cyanogen.com/point_main.php" target="_blank" rel="nofollow">Max Point by Cyanogen</a>
<br /><a href="http://www.moxa.com/"  target="_blank" rel="nofollow">MOXA--Solutions for Device Networking</a>
<br /><a href="http://www.stark-labs.com/nebulosity.html" target="_blank">Nebulosity by Stark Labs</a>
<br />
	<a href="http://www.mainsequencesoftware.com/" rel="nofollow" target="_blank">Sequence Generator Pro</a>
<br /><a href="http://www.southernstars.com/" target="_blank" rel="nofollow">SkySafari for Iphone and Android devices</a>
<br />
	<a href="http://www.mainsequencesoftware.com/Products/WiFiScope" rel="nofollow" target="_blank">WiFi Scope for SkySafari</a>
<br /><a href="http://spyder.datacolor.com/" target="_blank" rel="nofollow">Spyder3Elite Monitor Calibration</a>
<br /><a href="http://www.stark-labs.com/nebulosity.html" target="_blank" rel="nofollow">Stark Labs Nebulosity</a>
<br /><a href="http://pixinsight.com" target="_blank" rel="nofollow">PixInsight</a>
<br /><a href="http://www.focusmm.co.uk/shop/RedShift-6-Premium-Edition-pr-1147.html" target="_blank" rel="nofollow">RedShigt 6</a>
<br /><a href="http://www.ccdware.com/products/pempro/index.cfm" target="_blank" rel="nofollow">PEMpro Software</a>
<br /><a href="http://www.aurigaimaging.com/" target="_blank" rel="nofollow" title="Align your astronomical images">RegiStar Image Registration</a>
<br /><a href="https://www.stellarmate.com/products/stellarmate-os.html">
	Stellarmate</a> For local control with Raspberry Pi3
<br /><a href="http://www.skymap.com/" target="_blank" rel="nofollow">SkyMap Planetarium Software</a>
<br /><a href="http://www.skyhound.com/index.html">SkyTools 3 Observing program</a>
<br /><a href="http://www.bisque.com/sc/pages/TheSkyX-Professional-Edition.aspx" target="_blank" rel="nofollow">Software Bisque -TheSkyX</a>
<br /><a href="http://starrynight.com/" target="_blank" rel="nofollow">Starry Night Products</a>
<br /><a href="http://www.carinasoft.com" target="_blank" rel="nofollow">Voyager by Carinda Software</a>
<br /><br /><br />
</div>
<hr class="style2" />

<div class="h2">Using the MallinCam Video Camera</div>
<div align="left" class="style6">

<br /><a href="http://www.mallincam.net/" rel="nofollow" target="_blank">Mallincam Astronomical Video CCD camera</a>
<br /><a href="http://www.mallincamusa.com" rel="nofollow" target="_blank">Jack's Astro Acc. MallinCam USA</a>
<br /><a href="http://www.celestron.com/c2/images/files/downloads/1126218454_AmCap.zip" target="_blank" rel="nofollow">AMCAP (free version)</a>
<!-- **************************************************

<br /><a href="http://www.pk3.org/K3CCDTools/" target="_blank" rel="nofollow">K3CCDTools/</a>
<br /><a href="downloads/Band%20Pass%20Filters%20For%20Visual%20&%20Video%20Astronomy.pdf" target="_blank" rel="nofollow" title="A find document discribing the use of band pass filters for both visual and Video Astronomy by Jim Thompson">Band-Pass Filters by Jim Thompson</a>
<br /><a href="http://www.jaycar.com.au" target="_blank" rel="nofollow">DVE Source, search for video enhancer</a>
<br /><a href="http://www.avermedia-usa.com/AVerTV/product/ProductDetail.aspx?Id=188">DVD EZMaker USB Gold</a>
<br /><a href="http://www.nchsoftware.com/capture/index.html" target="_blank" rel="nofollow">Debut Video Capture Software</a>
<br /><a href="http://splitcamera.com/" target="_blank">SplitCam Video Capture</a> free
<br /><a href="http://manycam.com/" target="_blank">Manycam Video Capture</a> free
<br /><a href="http://www.mallincamusa.com/Files/Control%20Software/MallinCam_ControlX%20V28.msi" target="_blank" rel="nofollow">Mallincam Extreme Software</a>
<br /><a href="http://veiks.com/mallincam/" target="_blank" rel="nofollow" title="Must be loaded from IE, will not load correctly from Mozella Firefox">
Malincam Extreme Control by Tom Veik</a>
<br /><a href="http://www.adgsoftware.com/mcx/" target="_blank" rel="nofollow">Mallincam Control by Andy Galasso</a>
<br /><a href="http://www.miloslick.com/MallinCam.html" target="_blank" rel="nofollow" >Mallincam Control from Miloslick.com</a>
<br /><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank" rel="nofollow">Metaguide Video guiding </a>- Free
<br /><a href="http://www.gerdneumann.net/english/home" target="_blank" rel="nofollow" >Gerg Neumann Jr.</a>
<br /><a href="http://www.gerdneumann.net/english/filterzubehoer-filter-accessories/filter-drawer-system-filter-schubladen-system.html" target="_blank" rel="nofollow">Neumann Filters 
and Filter Drawers</a>
<br /><a href="http://www.supercircuits.com/Wireless-Security/Wireless-Video-Links/MVL10" target="_blank" rel="nofollow">Wireless Video transmitter 2.4Ghz</a>
<br /><a href="http://www.shoptronics.com/5wiauvisetrb.html" target="_blank" rel="nofollow">Wireless Video transmitter 5.8Ghz</a>
<br /><a href="http://www.deepskyimaging.net/" target="_blank" rel="nofollow" title="New Version">DeepSkyImaging 2011</a>
<br /><a href="http://www.blackmagic-design.com/products/ultrastudiosdi/" target="_blank" rel="nofollow">UltraStudio SDI for&nbsp; Mallincam Signature</a>
<br /><a href="http://WebCamMax.com" target="_blank" rel="nofollow">WebCamMax</a>
<br /><a href="http://www.sharpcap.co.uk/">SharpCap</a> Webcam/Camera Capture SW
<br /><a href="http://www.startech.com/AV/Converters/Video/USB-S-Video-and-Composite-Audio-Video-Capture-Cable-with-TWAIN-Support~SVID2USB23" target="_blank" rel="nofollow">Startech Svideo to USB capture device</a>
<br /><a href="http://www.vpi.us/svideo-landing.html" target="_blank" rel="nofollow" title="They make a 2 and 8 way S-Bideo splitter that is very reasonable">Video Splitters from VPI</a>
<br /><a href="http://www.bhphotovideo.com/c/search?phd=4291379781&amp;atclk=Video+Output_S-Video&amp;ci=16663&amp;N=4263708761+4276734414" target="_blank" rel="nofollow" title="Kramer S-Video Distribution amplifiers">S-Video D/A Kramer from B 
	&amp;  H</a>
<br /><a href="http://wcs.ruthner.at/index-en.php" target="_blank" rel="nofollow">WebCamScheinern Drift alignment software</a>
<br /><a href="http://www.protectiondepot.com/500mW-Transmitter-Receiver.html" target="_blank" rel="nofollow">Video Transmitter 9000MHZ</a>
<br /><a href="http://www.nightskiesnetwork.com/" target="_blank" rel="nofollow">Watch Night Skies Network</a>
<br /><a href="http://code.google.com/p/zscreen/" target="_blank" rel="nofollow">ZScreen Screen capture software</a><br />

	************************************************ -->
<br /><a href="http://www.zengineering.us" target="_blank" rel="nofollow">ZEngineering Cables for Mallincam</a>
<br /><a href="https://groups.io/g/MallinCam/files/Fast%20and%20Filthy%203-page%20guide" target="_blank">Fast and Fithy 3 page guide</a><br />

</td>
<td class="style6wborder">

<div class="h2">Software Free/Shareware*</div>
<div align="left" class="style6">
<a href="http://www.aagware.eu/" target="_blank" rel="nofollow">AAGware Weather monitoring</a> 
<span class="auto-style1">Requires hardware </span>
<br /><a href="http://aberrator.astronomy.net/" target="_blank" rel="nofollow">Aberrator Startesting Freeware</a>
<br /><a href="http://www.alignmaster.de/" target="_blank" rel="nofollow" title="Simple way to do polar alignment">AlignMaster-Help Do Polar alignment</a> 
<span class="auto-style1">Shareware</span>
<br /><a href="http://www.sharpcap.co.uk/sharpcap" target="_blank">SharpCap</a> WebCam to use with Alignmaster
<br /><a href="http://aladin.u-strasbg.fr/" target="_blank" rel="nofollow">Aladin Sky Atlas</a> 
<br /><a href="http://www.celestron.com/c2/images/files/downloads/1126218454_AmCap.zip" target="_blank" rel="nofollow">AMCAP Free Version</a>
<br /><a href="http://www.analogx.com" target="_blank" rel="nofollow">AnalogX Software utilities</a>
<br />ASCOM
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.ascom-standards.org/" target="_blank" rel="nofollow">Current Version 6.0</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.ascom-standards.org" target="_blank" rel="nofollow">Ascom Standards Org.</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://groups.yahoo.com/neo/groups/ASCOM-Talk/" target="_blank" rel="nofollow" >ASCOM Talk Users Group</a>
<br /> &nbsp;&nbsp;&nbsp;<a href="https://groups.io/g/Gemini_ASCOM_Driver/" target="_blank" rel="nofollow" title="Use this site to report bugs directily to the writers of this driver">Gemini Ascom 
Driver User site</a>
<br />
&nbsp;&nbsp;
	<a href="http://ascom-standards.org/Developer/AppStart.htm" target="_blank">
	Scripting with ASCOM</a><br /><a href="http://sourceforge.net/p/astrotortilla/home/Home/" target="_blank" rel="nofollow">AstroTortilla Astrophotography Assistant </a>
	<a href="http://astrometry.net/" target="_blank">astrometry.net for use with AstroTorilla</a>
	<br />
	<a href="http://www.ideiki.com/astro/Download.aspx" target="_blank" title="Full Version is only 12.70 EUR - Works with AstroTorilla">Astro Photography Tool APT</a>
	<br />
	<a href="http://www.cygwin.com/" target="_blank">Cygwin - build Linux 
	distribution in Windows</a><br /><a href="http://www.astrosurf.com/c2a/english/index.htm" target="_blank" rel="nofollow">C2A Planetarium Software</a><span class="auto-style1"> Donation Requested</span>
<br /><a href="http://www.ap-i.net/skychart/" target="_blank" rel="nofollow">Cartes du 
Ciel</a>
<br /><a href="http://www.newastro.com/book_new/camera_app.php" target="_blank" rel="nofollow" title="CCD Calc is a free download from this web page">CCD Calculator from New CCD Astronomy</a>
<br /><a href="http://converter.telerik.com/" target="_blank" rel="nofollow" title="Convert Visual basic to C+ or C+ to Visual Basic">Convert VB to C+ or C+ to VB</a>
<br /><a href="http://www.cutepdf.com/Products/CutePDF/writer.asp" target="_blank" rel="nofollow">CutePDF Printer Driver - PDF from any document</a>
<br />
	<a href="http://technet.microsoft.com/en-us/sysinternals/default" target="_blank" title="Neat utilities by Microsoft employees">
	Microsoft Sysinternals</a> - Software by MS employees
<br /><a href="http://deepskystacker.free.fr" target="_blank" rel="nofollow">Deep Sky Stacker</a>
<br /><a href="http://www.thinkman.com/dimension4/" target="_blank" rel="nofollow">Dimension 4 Internet Clock</a>
<br /><a href="http://groups.yahoo.com/neo/groups/StarLocatorElbrus/" target="_blank" rel="nofollow">ELBRUS Telescope Pointing Program on Yahoo groups </a>
<br /><a href="http://astrosurf.com/pulgar/elbrus/elbrusin.htm#iniin" target="_blank" rel="nofollow">ELBRUS Web page home in English</a>
<br /><a href="http://www.spacetelescope.org/projects/fits_liberator" target="_blank" rel="nofollow" title="Fits Liberator for CS4 from Nasa">Fits_Liberator 
3 now stand-alone</a>
<br /><a href="http://eqalign.net/e_index.html" target="_blank" rel="nofollow">EQAlign Polar Alignment software</a>
<br />
	<a href="downloads/focusmax/focusmax-PoleAlignMaz.zip" rel="nofollow" target="_blank">FocusMax-PoleAlignMax
	</a>Unsuported Use at your own risk.<br /><a href="http://www.spacetelescope.org/projects/fits_liberator" target="_blank" rel="nofollow" title="Fits Liberator for CS4 from Nasa">Fits_Liberator Stand Alone Program</a>
<br /><a href="http://pk.darkhorizons.org/GMB/gmb.htm"target="_blank" rel="nofollow">Gemini Model Builder</a>
<br /><a href="http://www.docgoerlich.de/utcdate.php" target="_blank" rel="nofollow" title="Get UTC in Gemini format from your local time">Get UTC in Gemini 
Mount format</a>
<br /><a href="http://www.pk.darkhorizons.org/GRS.htm" target="_blank" rel="nofollow">GRS- Gemini Rate Setter Utility</a>
<br /><a href="http://www.guidemaster.de/" target="_blank" rel="nofollow" title="Click the British flag for English on the lower left">GuideMaster for guiding with webcams</a>
<br /><a href="http://www.hnsky.org/software.htm" target="_blank" rel="nofollow">Hallo Planetarium Software</a>
<br /><a href="http://iraf.noao.edu/" target="_blank" rel="nofollow">Image Reduction and Analysis Facility</a>
<br /><a href="http://www.pk3.org/Astro/index.htm?k3ccdtools.htm" target="_blank" rel="nofollow">K3CCDTools Webcam Capture</a>
<br />	<a href="downloads/KVYCam/SetupKVYcam.zip" target="_blank">KVYCam V11.4.4.0 zip</a>&nbsp; Streaming software
<br /><a href="http://edu.kde.org/kstars/" target="_blank" rel="nofollow">Kstars for KDE</a>
<br /><a href="http://www.astrogeeks.com/Bliss/MetaGuide/" target="_blank" rel="nofollow">MetaGuide Web Cam Guider Software</a>
<br /><a href="http://en.wikipedia.org/wiki/NASA_World_Wind#Extraterrestrial_datasets" target="_blank" rel="nofollow">NASA World Wind</a>
<br /><a href="http://darkhorizons.emissionline.com/NISTSync.htm" target="_blank" rel="nofollow" title="Set you PC clock to several of the Internet time servers">NISTSYNC - set your PC Clock</a>
<br /><a href="http://www.remoteutilities.com/" target="_blank">Remote Utilities</a> Remote 
	Control Administration
<br /><a href="http://www.stark-labs.com/phdguiding.html" target="_blank" rel="nofollow">Phd Guiding </a>
<br /><a href="http://countingoldphotons.com/phdlab-intro/" target="_blank">PHDLab - a PHD Log Analyzer
	</a>
<br /><a href="http://www.astronomie.be/registax/">RegiStax Image processing software</a>
	<a href="http://www.remoteutilities.com/index.php?src=app" target="_blank">Remote 
	Utilities Free up to 10 computers</a>
<br /><a href="http://www.dd-wrt.com/" target="_blank" rel="nofollow">Replace your router firmware with dd-wrt</a>
<br /> 
	<a href="https://sites.google.com/site/astropipp/ser-player" target="_blank">SER File Player - For Windows, Mac and Linux
	</a>
<br /><a href="http://www.sharpcap.co.uk/">SharpCap</a> Webcam/Camera Capture SW<br />
	<a href="http://www.projectpluto.com/a2_pass.htm#signup" target="_blank" rel="nofollow">Star Catalogs from Project Pluto</a> 
<br /><a href="http://soundstepper.sourceforge.net/" target="_blank" rel="nofollow">Soundstepper Telescope controller</a>
<br /><a href="http://www.stellarium.org/" target="_blank" rel="nofollow">Stellarium Planetarium</a>
<br /><a href="http://www.welshdragoncomputing.ca/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=31&amp;Itemid=39" target="_blank" rel="nofollow" title="Use this with Stellarium to allow telescope control through ASCOM">StellariumScope Use with Stellarium</a> 
<br /><a href="http://www.welshdragoncomputing.ca/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=31&amp;Itemid=44" target="_blank" rel="nofollow" title="Ascom Plugin for Stellarium by www.welshdragoncomputing.ca">&nbsp;&nbsp; Stellarium ASCOM plugin</a>&nbsp;
<br /><a href="http://www.gralak.com/Sigma/" target="_blank" rel="nofollow">Sigma Combine Fitts Images</a>
<br /><a href="http://www.softperfect.com/products/networkscanner" target="_blank" rel="nofollow" title="A nice network scanner that show active IP devices">SoftPerfect Network Scanner</a>
<br /><a href="http://www.skyviewcafe.com/skyview.php" target="_blank" rel="nofollow">Sky View cafe Planing software</a>
<br /><a href="http://larryo.org/astronomy/software/unimap/" target="_blank">uniMap including Plate Solving</a>
<br /><a href="http://www.nofs.navy.mil/" target="_blank" rel="nofollow">United States Naval Observator -Flagstaff</a>
<br /><a href="http://www.nirsoft.net/utils/usb_devices_view.html" target="_blank" rel="nofollow">USBDeview - Display all USB devices</a>
<br /><a href="http://www.eterlogic.com/Products.VSPE.html" target="_blank" rel="nofollow">Virtual Serial Port Emulator</a>
<br /><a href="http://www.virtualbox.org/" target="_blank" rel="nofollow">VirtualBox Virtualization Software</a>
<br /><a href="http://www.worldwidetelescope.org/Home.aspx" target="_blank" rel="nofollow">World Wide Telescope</a>
</div>
<div>
WebCam Freeware<ul>
		<li>		<a href="http://aberrator.astronomy.net/" target="_blank">Aberrator</a> - program that generates star testing images showing the 
		effects of aberrations and distortions</li>
		<li>		
		<a href="http://www.daansystems.com/freestuff/" target="_blank">AVI2BMP</a> 
		- Allow the manual selection of frames in a video sequence.</li>
		<li>		<a href="http://www.irfanview.com/" target="_blank">
		Irfanview</a> - basic image capture and video image processing</li>
		<li>		
		<a href="http://www.pk3.org/Astro/index.htm?k3ccdtools.htm" target="_blank">
		K3CCD</a> - Popular, but not free, webcam control program</li>
		<li>		<a href="http://pixinsight.com/">PixInsight</a> - Powerful 
		Image processing</li>
	</ul>
	<p>&nbsp;</p>
</div>
<br />
<hr class="style2" />

<p align="center"><span class="h2" > Suggestions from our young Astronomers</span> </p>

<a href="http://www.orlandofuntickets.com/kids-space-center-telescopes-and-astronomy/" 
target="_blank" rel="nofollow" title="Suggested by Cori L. at Goodwin Community Center teen center!">Kids Space Center - Telescopes and Astronomy</a>
<br />
<a href="http://www.affordablelamps.com/the-hubble-telescope-shedding-light-on-the-universe.html" 
title="Suggested by Teacher Deborah Ward Class and Student Rachel">Hubble Telescope: Shedding Light on the Universe</a>
<br />
<a href="http://www.blindschalet.com/kba-be-an-astronomer-right-from-your-%20window-240.html" rel="nofollow"  target="_blank">Be an Astronomer Right from Your</a>&nbsp; 
and<br />
<a href="http://www.americanvisionwindows.com/telescopes-the-windows-to-solar-space.php"  rel="nofollow" target="_blank">Telescopes,the Windows to Solar Space</a> as
suggest by students at Colonial Academy.
</a>
<br /> 
<a href="https://householdquotes.co.uk/guide-to-backyard-astronomy/" target="_blank">Guide to Backyard Astronomy</a> as suggested by James.<br />
<p align="left" class="style6">
&nbsp;<p align="left" class="style6">
&nbsp;<p align="left" class="style6">
&nbsp;<p align="left" class="style6">
&nbsp;<p align="left" class="style6">
&nbsp;<p align="left" class="style6">


</td>
	</tr>
	<tr>
		<td style="width: 475px" class="style6wborder">
</td>
<td class="style6wborder">
&nbsp;</td>
	</tr>
	</table>

<table class="style9" cellpadding="2" style="height: 2px; width: 950px" align="center">
	<tr>
		<td style="width: 475px" class="style6wborder"><p class="h2">Web Site Links</p>
<p align="left" class="style6">


<a href="http://www.docgoerlich.de/Gemini.html" target="_blank" rel="nofollow">Ren&eacute; G&ouml;rlich's Gemini Tel. Positioning Sys.Site</a>
<br />
<a href="http://www.mi250.com" target="_blank" rel="nofollow" title="Rehosted to provide support by users">MI-250 Telescope Mount</a><br />

<a href="http://www.astrophotoinsight.com/content/automation-budget-part-2-software" target="_blank" rel="nofollow">Audomation on a Budget 
- Software</a>
<br />
<a href="http://www.docgoerlich.de/utcdate.php" target="_blank" rel="nofollow" title="Get UTC in Gemini format from your local time">Get UTC in Gemini 
Mount format</a>
<br />	<a href="http://astroshed.com/observatory/g11saga/g11saga.htm" target="_blank">
		Solving G11 problems from Astroshed</a>
<br /><a href="http://www.docgoerlich.de/L3Features.html" target="_blank" rel="nofollow">Gemini Servo System Features</a>
<br /><a href="http://www.docgoerlich.de/L4V1serial.html" target="_blank" rel="nofollow">Gemini L4, V1.0 Serial Interface Command Description</a>
<br /><a href="http://obs.nineplanets.org/obs/obslist.html" target="_blank" rel="nofollow">Amateur 
observatories Links-Many links dead</a>
<br /> 
<a href="http://www.stargazing.net/David/astrophoto/AstroPDF.html" target="_blank" rel="nofollow">Astrophotograohy links</a>
<br /><a href="http://www.amsky.com/yellowpages"  target="_blank" rel="nofollow">Astronomy Yellow Pages</a>
<!--<br />
<a href="http://www.backyardskies.com/BackyardSkies/Welcome.html" target="_blank" rel="nofollow">Backyard Skys by 
Emanuele Colognato</a>-->
<br /><a href="http://www.perezmedia.net/beltofvenus/" target="_blank" rel="nofollow">Belts of Venus site by Jeremy Perez</a>
<br /><a href="http://www.astronomy-pictures.com/Imaging-Tips.htm" target="_blank" rel="nofollow">Bob 
Austin&#39;s Imaging-Tips</a>
<br /><a href="http://www.californiastars.net" target="_blank" rel="nofollow">Californiastars<a>
<br />
<a href="http://www.datasheets360.com/" target="_blank" title="Datasheets360 has thousands of data sheets for electronic parts">Data Sheets for Electronic parts Free</a><a>
<br /><a href="http://www.dl-digital.com/Astronomy_main.html" target="_blank" rel="nofollow">Dick Locke's Astrophotography Gateway page</a>
<br /><a href="http://www.mapug-astronomy.net/ragreiner/index.html#Index" target="_blank" rel="nofollow">Doc G&#39;s Info Site</a>
<!--<br /><a href="http://www.fairobs.org/" target="_blank" rel="nofollow">Fairborn Observatory</a>-->
<br /><a href="http://eoni.com/~garlitzj/observ.htm" target="_blank" rel="nofollow">Foam Dome - 
Homebuilt Plans</a>
<br /><a href="http://www.theketelsens.blogspot.com/" target="_blank" rel="nofollow">Ketelsens&#39;s Blog 
Astronomy</a>
<br /><a href="http://www.heavensgloryobservatory.com/" target="_blank" rel="nofollow">Heaven&#39;s Glory 
Observatory</a>
<br /><a href="http://www.imagingtheheavens.co.uk" target="_blank" rel="nofollow">Imaging the Heavens</a>
<br /><a href="http://schmidling.com/astro.htm" target="_blank" >Jack Schmidling Astronomy</a>
<br /><a href="http://homepage.ntlworld.com/john.moore88/" target="_blank" rel="nofollow">John Moores Astronomy pages and designs</a>
<br />
<a href="http://mallincamproject.astrocpo.com/" target="_blank" rel="nofollow" title="MallinCam Camera Images. Proposed 15000 images">MallinCam Project Official Site</a><br />
<a href="http://www.bbastrodesigns.com/index.html#About_Mel" target="_blank" rel="nofollow">Mel Bartels Telescope Making</a>
<br /> <a href="http://www.michaelherman.net/#!losmandy-g11-mount" target="_blank" rel="nofollow">Michael Herman's G11 Improvements</a>
<br /><a href="http://www.mapug-astronomy.net/" target="_blank" rel="nofollow">MUPAG Meade Adv Products User GP</a>
<br />
<a href="http://rainerehlert.com/OR14html/" target="_blank" rel="nofollow">Rainers Observatory</a>
<br />
<a href="http://sky-lights.org/" target="_blank" rel="nofollow">Sky Lights BLog by Dan 
Heim</a><br /><a href="http://www.skybadger.net/equipment/wireless.shtml"  target="_blank" rel="nofollow">SkyBadger - Remoting the observatory</A>
<br /><a href="http://uncle-rods.blogspot.com/">Uncle Rod's Astro Blog</a>
<br />
<a href="http://www.sergepetiot.com/" target="_blank" title="Many nice tips and helpful information">Serge Petiot Very Nice Website</a>
<br /><a href="http://www.wilmslowastro.com/index.htm" target="_blank" rel="nofollow">Wilmslow Astro - lots of info obout G11</a><br /><br />

</td>
		<td class="style6wborder"><p class="h2" >Books, Magazines, Web Magazines and Reviews</p>
<p align="left" class="style6">

<a href="http://www.newastro.com" target="_blank" rel="nofollow">New CCD Astronomy</a><br />
<a href="http://www.astronomytechnologytoday.com/" target="_blank" rel="nofollow">Astronomy Technology Today</a><br />
<a href="http://telescope.direktorie.com/" target="_blank" rel="nofollow">Telescope Reviews</a> <br />
<a href="http://www.fotosearch.com/photos-images/astronomy.html" rel="nofollow" target="_blank">Fotosearch Astronomy Image Gallery</a>
</p>
<hr class="style2" />
<p class="h2">Clubs, Ascom, Weather & Users Groups</p>
<p align="left" class="style6">

<a href="http://www.ascom-standards.org" target="_blank" rel="nofollow">Ascom Standards Org.</a>
<br />
<a href="http://www.astrophotogallery.org" target="_blank" rel="nofollow">Astrophoto Gallery 
for posting photos</a>

<!--<br /><a href="http://www.astroclassifieds.com/" target="_blank" rel="nofollow">AstroClassified buy and sell.- FREE</a>-->
<br /><a href="http://cloudynights.com/" target="_blank" rel="nofollow">Cloudy Nights Telescope 
Reviews</a>
<br /><a href="https://groups.io/g/Gemini-II/" rel="nofollow" target="_blank">Gemini 2 Users Group</a>
<br />
<a href="https://groups.io/g/Gemini_users/topics" rel="nofollow" target="_blank">Gemini Users Group</a>
<br /><a href="http://groups.yahoo.com/neo/group/Titan_Mount/" target="_blank" rel="nofollow">Losmandy Titan  Users Group</a>
<br /><a href="https://groups.io/g/Losmandy_users/" target="_blank" rel="nofollow">Losmandy Users Group</a>
<br /><a href="https://groups.io/g/MI-250/" rel="nofollow" target="_blank">MI-250 
Users Group</a>
<br />
<a href="http://www.saguaroastro.org/" target="_blank" rel="nofollow" title="Phoenix AZ Astronomy Club normally Refered to as SAC">Saguaro Astronomy Club</a><br />
<a href="http://maps.google.com/maps/ms?ie=UTF&amp;msa=0&amp;msid=102983467099648817705.000485cdc1b6ea3c3d579" target="_blank" rel="nofollow" title="These use Google Maps">Astronomy Sites in Arizona</a>
<br />
<a href="http://www.qcuiag.org.uk/" target="_blank" rel="nofollow" title="QuickCam and Unconventional  Imaging Astronomy Group">QuickCam 
and Unconventional Imaging</a><br />Weather Related:
<br />&nbsp;&nbsp;&nbsp; <a href="http://www.accuweather.com" target="_blank" rel="nofollow">Accuweather across the US</a> 
<br />&nbsp;&nbsp;&nbsp; <a href="http://cleardarksky.com/csk/" target="_blank" rel="nofollow">Clear Sky Clock home page</a>
<br />&nbsp;&nbsp;&nbsp; <a href="http://cleardarksky.com/c/Phoenixkey.html?1" target="_blank" rel="nofollow">Clear Sky Clock for Phoenix AZ</a>
<br />&nbsp;&nbsp;&nbsp;
<a href="http://www.wrh.noaa.gov/zoa/mwmap3.php?map=usa" target="_blank" rel="nofollow">Nasa 
weather map - National</a>
<br />&nbsp;&nbsp;&nbsp; <a href="http://www.weatherimages.org/data/imag192.html" target="_blank" rel="nofollow">Jet Stream 4 day forcast</a>
<br />&nbsp;&nbsp;&nbsp; <a href="http://adds.aviationweather.gov/satellite/" target="_blank" rel="nofollow">Aviationweather</a>
<br />&nbsp;&nbsp;&nbsp; <a href="http://www.ssec.wisc.edu/data/geo/index.php?" target="_blank" rel="nofollow">SSET Datellite Images</a>
<br />&nbsp;&nbsp; <a href="http://www.skippysky.com.au/">SkippySky Astro-Weather Forcast
</a> 
<br />
</td>
	</tr>
<!--	<tr>
		<td style="width: 450px" class="style11">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>-->
</table>


<table class="style9" cellpadding="2" style="height: 2px; width: 950px" align="center">
	<tr>
		<td style="width: 475px" class="style6wborder"><p class="h2">How Too<p align="left" class="style6">


<a href="http://andysshotglass.com/DriftAlignment.html" target="_blank" rel="nofollow" title="A short movie explaining how to do Drift alignment">Andy Shots Drift Alignment method</a>
<br /><a href="http://www.mapug-astronomy.net/ragreiner/adapters.html" target="_blank" rel="nofollow">Attaching Camera Lense to CCD Imagers</a>
<br />
<a href="http://astrojargon.net/MaskGen.aspx" target="_blank" rel="nofollow">Bahtinov Focusing Mask Generator</a>
<br /><a href="http://www.wilmslowastro.com/tips/g11gemini.htm#balancing" target="_blank" rel="nofollow">Balancing a side-by-side setup</a>
<!--<br /><a href="http://www.backyardskies.com/BackyardSkies/Welcome.html" target="_blank" rel="nofollow">Bicolor Technique for combining Ha and OIII images</a>
-->
<br /><a href="http://www.blackviper.com/" target="_blank" rel="nofollow">Black Vipers Windows Tweek Windows site</a>
<br /><a href="http://www.stellarjourney.com/index.php?r=site/equipment_onstep" target="_blank">Build you own onStep Servo controller</a>
<br /><a href="http://sctscopes.net/SCT_Tips/Maintenance/Collimation/collimation.html" target="_blank" rel="nofollow">Collimating Your SCT</a>
<br /><a href="http://canburytech.net/DriftAlign/" target="_blank" rel="nofollow" title="Tips on drift aligning - Nice write up.">Drift Aligning by Edward Siminson</a><br />
<a href="http://astronomy.qteaser.com/diffspike.html" target="_blank" rel="nofollow">Diffraction Spike Focusing - How Too
</a>
<br />
<a href="http://www.starrywonders.com/bicolortechniquenew.html" target="_blank" rel="nofollow">Cannistra Bicolor Narrowband Technique</a>
<br />
<a href="http://astronomy.mdodd.com/files/Calculating_Observatory_Wall_Height.pdf" target="_blank" rel="nofollow" title="Mike Dodds example on how to calculate observatory wall height">Calculate Observatory Wall Height</a>
<br />
<a href="http://www.wilmslowastro.com/tips/g11gemini.htm#boot_codes" target="_blank" rel="nofollow">Gemini Bootup codes</a>
<br />
<a href="http://www.incentre.net/content/view/75/2/" target="_blank" rel="nofollow" title="How to make you own ethernet cables">Ethernet Cable Color codes</a>
<br /><a href="http://www.nexstarsite.com/OddsNEnds/ManualHC.htm" target="_blank" rel="nofollow" title="This was designed for the Celestron but also works on the Gemini hand controller input.">
Four button hand-controller-Works w/Gemini</a>
<br />
<a href="http://www.ip4ap.com/" target="_blank" rel="nofollow" title="Tutorials on using Photoshop">Image Processing for Astrophoto 
Tutorials</a>
<br /><a href="http://www.ostgate.com/MIL-HDBK-419A.PDF">Military Manual- Grounding Electronic Equip.</a>
<!--<br /><a href="Open%20Focuser%20Autofocus%20DIY" target="_blank" rel="nofollow">Open Focuser Autofocus DIY</a>-->
<br /><a href="http://www.kellys-korner-xp.com/xp_tweaks.htm" target="_blank" rel="nofollow">Registry Edits for WIN XP "Tweaks and Tips"</a>
<br /><a href="http://windowssecrets.com/" target="_blank" rel="nofollow">Search Windowssecrets.com</a>
<br /><a href="http://www.astronomy-pictures.com/Imaging-Tips.htm#ccdalign" target="_blank" rel="nofollow">Polar Alignment - with CCD camera by Bob Austin</a>
<br />
<a href="http://www.celestialwonders.com/articles/polaralignment/" target="_blank" rel="nofollow" title="Polar alignment by Frank Barrent ">Polar Alignment-Star offset method</a>
<br><a href="http://www.petesastrophotography.com/" target="_blank" rel="nofollow" title="You will find the link on the left side under Techniques, then Polar Alignment">
		Polar Alignment by Peter Kennett</a>
<br /><a href="http://rainerehlert.com/astro/G11-Handcontrol.pdf" target="_blank" rel="nofollow">Rainers 4 button Hand Controller</a>
<br /><a href="http://www.arksky.org/surge.htm" target="_blank" rel="nofollow">Protect your Telescope from a Lightning Surge</a>
<br /><a href="vista_mods.php#Add_Remotedesktop" target="_blank" rel="nofollow">Remote Desktop for Vista Home Premium</a>

<br /><a href="downloads/VBScript_Examples.pdf" target="_blank" rel="nofollow" title="This Tutorial is at the permission of Jeff Lunglhofer">
Scripting Examples and Tutorial</a>
<br />
<a href="http://www.ruland.com/pdf/Servo%20Couplings%20Article_web.pdf" target="_blank" rel="nofollow" title="A good article on Servo Coupling">Servo Coupling - What to look for</a>
<br /><a href="http://www.practicallynetworked.com/networking/convert_old_pc_to_new_router.htm" target="_blank">Transform a old Computer into a powerful router</a>
<br /><a href="http://cooledpix.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank" rel="nofollow">Using 
ASCOM/Stellarium with the Gemini2</a><a>
<br /><a href="http://www.csgnetwork.com/voltagedropcalc.html" target="_blank" rel="nofollow">Voltage Drop Calculator</a>
<br /><a href="http://www.phidgets.com/products.php?category=11" target="_blank" rel="nofollow" title="Servo control and and much more">Phiggets - Servo control</a><br />
<br /><br /><br /><br /><br /><br /><br />
</td>
		<td class="style6wborder"><p class="h2">Misc </p>
<p align="left" class="style6">
ASCOM Related
<br /></a>&nbsp;&nbsp;&nbsp; <a href="http://cooledpix.com/2012/05/09/g11-gemini-ii-ascom/" target="_blank" rel="nofollow">Using ASCOM/Stellarium with the Gemini2</a>
Astronomy Calculators<br />
&nbsp;&nbsp;
<a href="http://www.astro.wisc.edu/~dolan/constants/calc.html" target="_blank" rel="nofollow">Astro-Physical Calculator</a><br />

Observatory Control<br />
  &nbsp;
<a href="http://www.dppobservatory.net/DomeAutomation/DomeDriver.php/tags.cfm" target="_blank" rel="nofollow">LesveDome Driver</a>
<br />MaximDL related:
<br />&nbsp;&nbsp;
<a href="http://www.cyanogen.com/help/maximdl/" target="_blank" rel="nofollow">MaximDL Index of Help</a>
<br />&nbsp;&nbsp;
<a href="http://www.cyanogen.com/help/maximdl/Telescope_Tab.htm" target="_blank" rel="nofollow">MaximDL telescope Tab instructions</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.rc-astro.com/resources/rc_console.html" target="_blank" rel="nofollow">RC-Astro 
Processing Console</a>
<br />&nbsp;&nbsp;&nbsp;<a href="http://www.cyanogen.com/maxim_extras.php" target="_blank" rel="nofollow">MaximDL 
Extras</a>
<br />&nbsp; 
<a href="http://www.cyanogen.com/help/maximdl/TheSky_Controlled_Telescope.htm" target="_blank" rel="nofollow" title="How to get MaximDL and TheSky6 to work together">Connecting MaximDL and TheSky</a>
<!-- <br />&nbsp;&nbsp;&nbsp;<a href="http://winfij.homeip.net/maximdl/index.html" target="_blank" rel="nofollow">John 
Winfield Maxin DL Plugins</a>
<br />&nbsp;&nbsp;
<a href="http://winfij.homeip.net/development/SkySolve/index.html" target="_blank" rel="nofollow">SkySolve Plugin for MaximDL</a> -->
<br />&nbsp;&nbsp;
<a href="http://www.cyanogen.com/help/maximdl/TheSky_Controlled_Telescope.htm" target="_blank" rel="nofollow">Using TheSky and MaximDL together</a>
<br />&nbsp;&nbsp; <a href="http://www.cyanogen.com/maxim_tut.php" target="_blank" rel="nofollow">MaxIm DL Video Tutorials</a>
<br />Autoguiding
<br />&nbsp;&nbsp;&nbsp;
<a href="http://www.stark-labs.com/craig/articles/assets/AutoGuiding%20Craig%20Stark.pdf" target="_blank" rel="nofollow">As simple as"Push Here Dummy"?</a>
<!--<br />
&nbsp;&nbsp;&nbsp;
<a href="http://acp4.dc3.com/McMillanAutoguiding11-2005.pdf" target="_blank" rel="nofollow">Autoguiding by McMillian</a> -->
<!-- <br />Comet Hunting<br />&nbsp;&nbsp;&nbsp;
<a href="http://explorescientific.com/sharingthesky/index.html">David H. Levy 
Comet Hunter Telescope</a> -->
<br />Programming Help
<br />&nbsp;&nbsp;&nbsp;
<a href="http://www.hyperstarimaging.com/video.php" target="_blank" rel="nofollow" title="Hyperstar,MaximDL5/4,Photoshop Tutorials">Tutorials from Starizona</a><br />&nbsp;&nbsp;&nbsp; <a href="http://www.learnvisualstudio.net/" target="_blank" rel="nofollow">Learn C+,VB or ASP.net Videos&nbsp; (Paid)</a>
<br />Imaging
<br />&nbsp;&nbsp;&nbsp; 
<a href="http://www.hyperstarimaging.com/video.php" target="_blank" rel="nofollow" title="Hyperstar, MaximDL 4 &amp; 5, Photoshop Tutorials">Tutorials from Starizona</a>
<br />&nbsp;&nbsp;&nbsp; <a href="http://starizona.com/acb/ccd/advimnarrow.aspx" target="_blank" rel="nofollow">Narrowband 
Imaging</a> 
<br />&nbsp;&nbsp;&nbsp;
<a href="http://www.stargazing.net/David/QSI/ccdperfflats.html" target="_blank" rel="nofollow">Using a computer screen for Flats</a>
<!-- <br />&nbsp;&nbsp;
<a href="http://www.harrysastroshed.com/AA4flat.html" target="_blank" rel="nofollow">Creating Flats for Starlight color camera with AA4
</a>-->
<br />&nbsp;&nbsp;
<a href="http://www.astroden.com/c14fix/c14_corrector_alignment.htm" target="_blank" rel="nofollow">Aligning the corrector plate on a C14</a>
<br /> &nbsp;&nbsp;
<a href="http://www.rocketmime.com/astronomy/Telescope/telescope_eqn.html" target="_blank" rel="nofollow">Telescope Equations</a><br />&nbsp;&nbsp;
<br />&nbsp;&nbsp; <a href="http://www.photographytips.com/" target="_blank" rel="nofollow" title="Suggested by the Kids in Lana Decer's class at Pinewood Elementary School">Photography Tips</a>
<br />Photoshop<br />&nbsp;&nbsp;
<a href="http://www.spacetelescope.org/projects/fits_liberator" target="_blank" rel="nofollow" title="Fits Liberator for CS4 from Nasa">Fits_Liberator 
3 now stand-alone</a>
<br />&nbsp;&nbsp;
<a href="http://astroshed.com/fitsplug/fitsplug.htm" target="_blank" rel="nofollow" title="Not a free version">FitsPlug for CS4</a>
<br />&nbsp;&nbsp;
<a href="https://www.skyandtelescope.com/astronomy-resources/astrophotography-tips/remove-light-pollution-astro-images/" target="_blank">How to Remove Light Pollution</a>
<br />&nbsp;&nbsp; <a href="http://www.rocketroberts.com/astro/calibration.htm" target="_blank" rel="nofollow" title="Stacking images in photo shop">Stacking images is Photoshop</a>
<br />&nbsp; <a href="http://www.waid-observatory.com/" target="_blank" rel="nofollow">Don Waids tutorials for photoshop</a>
<br /><br />
</td>
	</tr>
	</table>
<table  align="center" style="width:900px">
	<tr>
		<td class="style7">
		Page last updated on OCT 05, 2018
		</td>
	</tr>
</table>


</body>




<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
      "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en-US">
<head profile="http://www.w3.org/2005/10/profile">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>


<head>
<title>Bottom page</title>
<link href="/gemini-2.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/ajxmenu_bottom.css" type="text/css">


</head>

<body style="color: #FFFFFF; background-color: #000000" >
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">This site is not for profit 
		and sells nothing and asks for no money for any help it provides.&nbsp; This 
		site is 
		here to help fellow Gemini-2 and Gemini-1 owners. This Web Site is not 
		associated with Losmandy-Hollywood General Machining Inc. or any of 
		their employees and never has been. There is no guarantee that all the 
		information is correct, but strives to provide the best information 
		possible. The use of any information is at your own risk.&nbsp; The webmaster 
		is an unpaid beta tester, and tries to work with other beta testers, and 
		René the writer of the firmware.&nbsp;
		If you would like to help keep this web site going send your gift to <a href="http://paypal.me/geminitwo">paypal.me/geminitwo</a> 
		Your gift will be used to defray the cost of keeping this web site up, unless you specify otherwise.</span></td>
	</tr>
</table>
<table align="center" style="width: 900px">
	<tr>
		<td class="tableborder1"> <span class="style6" style="font-size:small">
		I have tried many times to make a PDF of this site with no luck. Every program
		to do this screws up the links and images. I am not going to write a manual either.
		I developed this web site for my own use in the beginning, but it soon went public.</span></td>
	</tr>
</table>

	<table align="center" style="width: 900px">
		<tr>
			<td>
<div class="AJXMenuSPDSMNA"><!-- AJXFILE:ajxmenu_bottom.css -->
 <div class="ajxmw1">
  <div class="ajxmw2">
<ul>
 <li class="tfirst tlast"><a href="https://www.gemini-2.com/" target="_self">HOME</a></li>
</ul>
  </div>
 </div>
 <br >
</div>
</td>
</tr>
</table>

<!--
<table align="center"style="width: 50px">
	<tr>
	<td class="style6">Hit counter by<a href="http://digits.net"> http://digits.net</a></td>
	
	
	<td class="style6R" width="45%">
  <a href="http://www.digits.net" target="_blank">
    <img src="https://counter.digits.net/?counter={921ba194-f2d6-95c4-2981-2437d185efba}&template=simple" 
     alt="Hit Counter by Digits" border="0"  />
  </a>
  </td>
  </tr>
</table>
-->
&nbsp;<table align="center" cellpadding="4" cellspacing="4" style="width: 70%">
	<tr class="style6">
		<td class="style1">Your Privacy Policy
<br>No Information is collected by this site.&nbsp; Cookies are set in your browser, 
but only for visited<br/>links to change color.
</td>
	</tr>
	<tr class="style6">
		<td class="style13"><b>Your use of any information on this site is at your own risk.</b></td>
	</tr>
</table>
		
	<p class="style7" align="center"><!--webbot bot="HTMLMarkup" startspan --><script language=javascript>

	  <!--
	  var contact = "Thomas Hilton"
	  var email = "tomh"
	  var emailHost = "gemini-2.com"
	  document.write("copyright&copy; - 2017-2011 -<a href=" + "mail" + "to:" + email + "@" + emailHost+ ">" + contact + "</a>" )
	 //-->
	</script><!--webbot bot="HTMLMarkup" endspan -->
	and <a href="Https://www.Gemini-2.com">https://www.gemini-2.com</a>
	<br />Gemini-2 and Gemini is a registered trade names of Hollywood General Machining Inc.</p>

	
</body>




