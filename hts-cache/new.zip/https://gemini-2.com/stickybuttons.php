<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Stickybuttons</title>
<style type="text/css">
a {
	color: #FFFF00;
}
a:visited {
	color: #00FF00;

</style>

<link href="http://www.gemini-2.com/gemini-2.css" rel="stylesheet" type="text/css" />

</head>

<body style="color: #FFFFFF; background-color: #000000">

<table align="center" style="width: 700px; height: 750px">
	<tr>
		<td class="style6">Most of the buttons work as follows:<br />
&nbsp;- If a button is pressed, it is displayed highlighted and an indicator is set.
		<br />
		- If the button is released, the requested action is executed.
<br />
		- If the touch is not released within the active area of the button (finger or stylus slid away, intentionally or not intentionally), the button stays highlighted, but the action is not executed. This is convenient if you decide better not to press it, if you pressed the wrong button and don't want  the action executed or if the screen is not well calibrated.

		<br />
		<br />
		The Diamond directional buttons at the main screen have to act different:
		<br />
		- If a directional  button is pressed, a serial command "Move" is sent immediately and the axis starts moving.<br />
		<br />
		- If the button is released, a serial command "Stop" is sent and the movement stops or ramps down.
		<br />
		<br />
		- Now what's to do if the touch point is slid away, outside the active area of the button (this area is bigger as the button, a square with the directional button in the middle)?
Two possibilities: Send the Stop command once the touch left the active area or not?

The way it is now (and what we called "sticky" or Persistent.):  The button pressed stays active (no Stop command is sent) and the movement proceeds. Since the screen is single-touch only this is the only way to move both axes simultaneously.  
		<br />
		<br />
		This is now selectable via the button menu of the HC screen.  Select "Persistent Diamonds" if you want to keep the action this way.  
		<br />
		This menu is at 
Menu-->HC-->Buttons

The alternative: Send a Stop command as soon as a the touch leaves the active area of the directional button. 
		<br />
		This can't be standard behavior, because it degrades the usability of the hand controller, so it will be a feature that people that do not like the sticky/persistent behavior can switch 
		off. 
Again you can select this behavior by unchecking "Persistent Diamonds" at  Menu-->HC--><a href="hc/En-hcbuttons.php" target="_blank">Buttons</a> </td>
	</tr>
</table>
</body>

</html>
